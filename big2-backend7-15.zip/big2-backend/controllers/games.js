'user strict';
var _              = require('lodash');
var Promise        = require('bluebird');
var mongoose       = require('mongoose');
var customErrors   = require('n-custom-errors');
var consts         = require('../consts');
var gamesSrvc      = require('../data-services/games');
var validationUtil = require('../util/validations');
var log            = require('../util/logger').logger;              
var config         = require('../config/environment');

var timerId; 

exports.createGame = function(req, res, next) {
  function parseParams(req) {
    var body = req.body;
    var allowedFields = ['gameName', 'bettingMoney', 'gameCreator'];
    var gameData = _.pick(body, allowedFields);
    
    return Promise.resolve(gameData);
  }

  function validateParams(gameData) {
    return Promise.resolve(gameData);
  }

  function doEdits(gameData) {
    var game = _.assign({}, gameData);
    return game;
  }
  parseParams(req)
    .then(validateParams)
    .then(doEdits)
    .then(game => gamesSrvc.createGame(game))
    .then(game => res.send(game))
    .catch(next);
};

exports.getGames = function(req, res, next) {
  gamesSrvc
    .getGames({}, 'gameName bettingMoney status gameCreator')
    .then(games => res.send(games))
    .catch(next);
};

exports.getGameById = function(req, res, next) {
  var gameId = req.params._id;

  function validateParams() {
    if (!validationUtil.isValidObjectId(gameId)) {
      return customErrors.rejectWithUnprocessableRequestError({ paramName: 'id', errMsg: 'must be a valid id'});
    }
    return Promise.resolve();
  }

  validateParams()
    .then(() => gamesSrvc.getGame({ _id: gameId }, 'gameName bettingMoney status gameCreator gamePlayers'))
    .then(game => res.send(game))
    .catch(next);
};




exports.deleteGame = function(req,res,next) {
	function parseParams(req){
		var body = req.body;
		var allowedFields = ['gameName', 'status', 'gameCreator'];
		var gameData = _.pick(body, allowedFields);
		return Promise.resolve(gameData);
	}

	function validateParams(gameData) {
		return Promise.resolve(gameData);
	}

	function doEdits(gameData) {
		 var game = _.assign({} , gameData);
		 return game;
	}
	
	paramParams(req)
		.then(validateParams)
		.then(doEdits)
		.then(game => gamesSrvc.deleteGame(game))
		.catch(next);
};



exports.removePlayer = function(req, res, next) {
  function parseParams(body) {
    var allowedFields = ['userId', 'gameId'];
    var data = _.pick(body, allowedFields);
    return Promise.resolve(data);
  }

  function validateParams(data) {
    if (!validationUtil.isValidObjectId(data.gameId)) {
      return customErrors.rejectWithUnprocessableRequestError({ paramName: 'gameId', errMsg: 'must be a valid id'});
    }

    if (!validationUtil.isValidObjectId(data.userId)) {
      return customErrors.rejectWithUnprocessableRequestError({ paramName: 'userId', errMsg: 'must be a valid id'});
    }
    return Promise.resolve(data);
  }
  function removeFromPlayers(data){
     return gamesSrvc.removePlayer(data)
              .then(gameData=> Promise.resolve(data));
  }

   parseParams(req.body)
    .then(validateParams)
    .then(removeFromPlayers)
    .then(data => res.send(data))
    .catch(next);
};


exports.getGamesForUser = function(req, res, next){
    function parseParams(body) {
      var allowedFields = ['userId'];
      var userData = _.pick(body, allowedFields);
      return Promise.resolve(userData);
    }
    function validateParams(data) {
      if (!validationUtil.isValidObjectId(data.userId)) {
        return customErrors.rejectWithUnprocessableRequestError({ paramName: 'userId', errMsg: 'must be a valid id'});
      }
      return Promise.resolve(data);
    }
   parseParams(req.body)
    .then(validateParams)
    .then(data => gamesSrvc.getGamesForUser(data.userId))
    .then(data => res.send(data))
    .catch(next);


}
exports.startGame = function(req,res,next) {
	  function parseParams(body) {
		    var allowedFields = ['gameName', 'status', 'gameWinner', 'gamePlayers'];
		    var gameData = _.pick(body, allowedFields);
		    gameData._id = req.params._id;
		    return Promise.resolve(gameData);
		  }

	  function validateParams(gameData) {
	    return Promise.resolve(gameData);
	  }

	  function doEdits(data) {
	    _.extend(data.game, data.gameData);
	    return data.game;
	  }

  parseParams(req.body)
    .then(validateParams)
    .then(gameData => gamesSrvc
      .getGame({ _id: gameData._id })
      .then(game => {
        return { game, gameData };
      })
    )
    .then(doEdits)
    .then(game => gamesSrvc.startGame(game))
    .then(game => timerId = setInterval(nextTurn,game.turnInterval, req.TurnId))
    .then(game => res.send(game))
    .catch(next);
}

exports.pauseGame = function(req,res,next) {
	  function parseParams(body) {
		    var allowedFields = ['gameName', 'status', 'gameWinner', 'gamePlayers'];
		    var gameData = _.pick(body, allowedFields);
		    gameData._id = req.params._id;
		    return Promise.resolve(gameData);
		  }

	  function validateParams(gameData) {
	    return Promise.resolve(gameData);
	  }

	  function doEdits(data) {
	    _.extend(data.game, data.gameData);
	    return data.game;
	  }

  parseParams(req.body)
    .then(validateParams)
    .then(gameData => gamesSrvc
      .getGame({ _id: gameData._id })
      .then(game => {
        return { game, gameData };
      })
    )
    .then(doEdits)
    .then(game => gamesSrvc.pauseGame(game))
    .then(game => clearInterval(timerId))
    .then(game => res.send(game))
    .catch(next);
}


function nextTurn(){
	//BroadCast Turn information

	
}

exports.updateGame = function(req, res, next) {
  function parseParams(body) {
    var allowedFields = ['gameName', 'status', 'gameWinner', 'gamePlayers'];
    var gameData = _.pick(body, allowedFields);
    gameData._id = req.params._id;
    return Promise.resolve(gameData);
  }

  function validateParams(gameData) {
    return Promise.resolve(gameData);
  }

  function doEdits(data) {
    _.extend(data.game, data.gameData);
    return data.game;
  }

  parseParams(req.body)
    .then(validateParams)
    .then(gameData => gamesSrvc
      .getGame({ _id: gameData._id })
      .then(game => {
        return { game, gameData };
      })
    )
    .then(doEdits)
    .then(game => gamesSrvc.saveGame(game))
    .then(game => res.send(game))
    .catch(next);
};


exports.deleteGame = (req, res, next) => {
  var gameId = req.params._id;

  function validateParams() {
    if (!validationUtil.isValidObjectId(gameId)) {
      return customErrors.rejectWithUnprocessableRequestError({ paramName: 'id', errMsg: 'must be a valid id' });
    }
    return Promise.resolve();
  }

  validateParams()
    .then(() => gamesSrvc.getGame({ _id: gameId }))
    .then(badge => gamesSrvc.deleteGame(badge))
    .then(badges => res.send(true))
    .catch(next);
};
