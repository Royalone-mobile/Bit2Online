'use strict';

var _              = require('lodash');
var Promise        = require('bluebird');
var mongoose       = require('mongoose');
var customErrors   = require('n-custom-errors');
var consts         = require('../consts');
var usersSrvc      = require('../data-services/users');
//var gamesSrvc      = require('../data-services/games');
var validationUtil = require('../util/validations');
var log            = require('../util/logger').logger;              
var config         = require('../config/environment');
var crypto = require('crypto');

//var apn            = require('apn');
//var options = config.get("apn-option");
//var apnProvider = new apn.Provider(options);

exports.getMyUser = function(req, res, next) {
  console.log('getMyUser');
}
exports.getUsers = function(req, res, next) {
console.log('getUsers');
  usersSrvc
    .getUsers({}, 'email name role status gamePlayed ')
    .then(users => res.send(users))
    .catch(next);
};

exports.getUserById = function(req, res, next) {
  var userId = req.params._id;
console.log('getUserById');
  function validateParams() {
    if (!validationUtil.isValidObjectId(userId)) {
      return customErrors.rejectWithObjectNotFoundError('user not found');
    }
    return Promise.resolve();
  }

  validateParams()
    .then(() => usersSrvc.getUser({ _id: userId }, 'email name role status gamesPlayed point friends'))
    .then(user => res.send(user))
    .catch(next);
};


exports.getUserByEmail = function(req, res, next) {
  var emailAddress = req.params.email;
  var password = req.params.password;
  //console.log('getUserByEmail');
  //console.log(JSON.stringify(req.params));
  //console.log(usersSrvc.encryptPassword('password'));
  function validateParams() {
    if (!validationUtil.isValidEmail(emailAddress)) {
      return customErrors.rejectWithUnprocessableRequestError({ paramName: 'email', errMsg: 'must be a valid email'});
    }
    return Promise.resolve();
  }
  function authenticatePassword(user){
     //console.log('authenticatePassword');
     console.log(JSON.stringify(user));
      if (!password || !user.salt) {
         return customErrors.rejectWithObjectNotFoundError('user not found');
      }
      var salt = new Buffer(user.salt, 'base64');
      var hashedPassword = crypto.pbkdf2Sync(password, salt, 10000, 64).toString('base64');
      console.log('user.salt='+user.salt);
      console.log(salt);
      console.log(hashedPassword);
      console.log(user.hashedPassword);
      if(hashedPassword === user.hashedPassword)
        return true;
      else
        return false; 
  }

  validateParams()
    .then(() => usersSrvc.getUser({ email: emailAddress}, 'name role salt status gamesPlayed point friends hashedPassword'))
    .then(user => 
    {
      if(authenticatePassword(user))
        res.send(user);
      else
        return customErrors.rejectWithObjectNotFoundError('user not found');
    })
    .catch(next);
};


exports.createUser = function(req, res, next) {
  console.log("body : " + JSON.stringify(req.body));

  function parseParams(body) {
    var allowedFields = ['email', 'name','password', 'role'];
    var userData = _.pick(body, allowedFields);
    return Promise.resolve(userData);
  }

  function validateParams(userData) {
    return _validateUserData(userData);
  }

  function doEdits(userData) {
     console.log('doEdits');
    var user = _.assign({}, userData);
    user.status = 'active';
    return user;
  }
  
  parseParams(req.body)
    .then(validateParams)
    .then(doEdits)
    .then(user => usersSrvc.createUser(user))
    .then(user => res.send(user))
    .catch(next);
};

exports.updateUser = function(req, res, next) {
  function parseParams(body) {
    var allowedFields = ['email', 'name', 'role', 'status'];
    var userData = _.pick(body, allowedFields);
    userData._id = req.params._id;
    return Promise.resolve(userData);
  }

  function validateParams(userData) {
    if (!validationUtil.isValidObjectId(userData._id)) {
      return customErrors.rejectWithUnprocessableRequestError({ paramName: 'id', errMsg: 'must be a valid id' });
    }
    var allowedStatuses = consts.USER.STATUSES;
    if (!_.includes(allowedStatuses, userData.status)) {
      return customErrors.rejectWithUnprocessableRequestError({ paramName: 'status', errMsg: 'must be a valid value'});
    }
    return _validateUserData(userData);
  }

  function doEdits(data) {
    _.extend(data.user, data.userData);
    return data.user;
  }

  parseParams(req.body)
    .then(validateParams)
    .then(userData => usersSrvc
      .getUser({ _id: userData._id })
      .then(user => {
        return { user, userData };
      })
    )
    .then(doEdits)
    .then(user => usersSrvc.saveUser(user))
    .then(user => res.send(user))
    .catch(next);
};


exports.updatePassword = function(req, res, next){
  function parseParams(body) {
    var allowedFields = ['oldPassword', 'newPassword'];
    var userData = _.pick(body, allowedFields);
    userData._id = req.params._id;
    return Promise.resolve(userData);
  }

  function validateParams(userData) {
    if (!validationUtil.isValidObjectId(userData._id)) {
      return customErrors.rejectWithUnprocessableRequestError({ paramName: 'id', errMsg: 'must be a valid id' });
    }
    return Promise.resolve(userData);
  }

  function doEdits(data) {
    _.extend(data.user, data.userData);
    return data.user;
  }

   parseParams(req.body)
    .then(validateParams)
    .then(userData => usersSrvc
      .getUser({ _id: userData._id })
      .then(user => {
        if(user.authenticate(userData.oldPassword)){
          user.set("password", userData.newPassword);
          return user;   
        }else {
          return customErrors.rejectWithUnprocessableRequestError({ paramName: 'oldPassword', errMsg: 'must be same as original password' });
        }
        
      })
    )
    .then(user => usersSrvc.saveUser(user))
    .then(user => res.send(user))
    .catch(next);

};
exports.acceptInvite = function(req, res, next) {
   function parseParams(body) {
    var allowedFields = ['userId', 'gameId', 'isAccept'];
    var data = _.pick(body, allowedFields);
    log.info(data);
    return Promise.resolve(data);
  }

  function validateParams(data) {
    if (!validationUtil.isValidObjectId(data.userId)) {
      return customErrors.rejectWithUnprocessableRequestError({ paramName: 'userId', errMsg: 'must be a valid id' });
    }
    if (!validationUtil.isValidObjectId(data.gameId)) {
      return customErrors.rejectWithUnprocessableRequestError({ paramName: 'gameId', errMsg: 'must be a valid id' });
    }
    return Promise.resolve(data);
  }

  function doEdits(data) {
    _.extend(data.user, data);
    return data.user;
  }
  function removeFromInvite(data){
     //return gamesSrvc.removeInvite(data)
       //       .then(gameData=> Promise.resolve(data));
  }
  function addToPlayers(data){
    // if(data.isAccept === '1'){
    //   log.info("Accept invite: add Player");
    //    return gamesSrvc.addPlayer(data)
    //           .then(gameData=> Promise.resolve(data));
    // }else{
    //    return Promise.resolve(data); 
    // }
  }

   parseParams(req.body)
    .then(validateParams)
    .then(removeFromInvite)
    .then(addToPlayers)
    .then(user => res.send(user))
    .catch(next);

}


exports.invitePlayer = function(req, res, next){
  function safelyParseJSON (json) {
    var parsed;
    try {
      parsed = JSON.parse(json)
    } catch (e) {
      console.error("Invalid json");
    }
    return parsed;  // Could be undefined!
  }


  function parseParams(data) {
    var jsonData;
    if(data instanceof String){
        jsonData = safelyParseJSON(data);
    }else{
        jsonData = data;
    }
    //  console.log(jsonData);
    return Promise.resolve(jsonData);
  }

  function validateParams(userData) {
    var inviteList = userData.inviteList;
    var jsonData = safelyParseJSON(inviteList);
    var data= {};
    data.gameId = userData.gameId;
    data.inviteList = jsonData;
    return Promise.resolve(data);
  }

  function addInvites(userData) {
     // return gamesSrvc.addInvites(userData)
     //          .then(gameData=> Promise.resolve(userData));
  }
  function populateUserData(userData){
    var ids = [];
     for(var i=0; i<userData.inviteList.length; i++){
        var user = userData.inviteList[i];

        ids.push(mongoose.Types.ObjectId(user.userId));
     }
    var filter = {
      '_id': { $in: ids}
    };
    return usersSrvc.getUsers(filter," _id APNSToken ")
            .then(users => doEdit(userData, users));
  }

  function doEdit(userData, users){
    var data = {};
    data.gameId = userData.gameId;
    data.inviteList = users;
    return Promise.resolve(data);
  }

  function sendNotifications(userData){
    // var note = new apn.Notification();
    // note.expiry = Math.floor(Date.now() / 1000) + 3600; // Expires 1 hour from now.
    // note.sound = "ping.aiff";
    // note.payload = {'type': 100, 'data': {'gameId': userData.gameId} };
    // note.topic = "com.kgom.spotted";
    // var inviteList = userData.inviteList;
    // for(var i=0; i<inviteList.length; i++){
    //   var inviter = inviteList[i];
    //   //console.log(inviter);
    //   if(inviter.APNSToken !== undefined){
    //     //console.log(inviter.APNSToken);
    //     apnProvider.send(note, inviter.APNSToken)
    //      .then( (result) => {
    //         log.info('APNS','result=',result);
    //      });  
    //   }
        
    // }
  
    // return userData;   
  }


  parseParams(req.body)
    .then(userData => validateParams(userData))
    .then(userData => addInvites(userData))
    .then(userData => populateUserData(userData))
    .then(userData => sendNotifications(userData))
    .then(user => res.send(user))
    .catch(next);
};

exports.updateToken = function(req, res, next) {
  function parseParams(req) {
    var body = req.body;
    var allowedFields = ['APNSToken'];
    var userData = _.pick(body, allowedFields);
    userData._id = req.params._id;
    userData.role = 'user';
    userData.status = 'active';
    return Promise.resolve(userData);
  }

  function validateParams(userData) {
    if (!validationUtil.isValidObjectId(userData._id)) {
      return customErrors.rejectWithUnprocessableRequestError({ paramName: 'id', errMsg: 'must be a valid id' });
    }
    return Promise.resolve(userData);
  }

  function doEdits(data) {
    _.extend(data.user, data.userData);
    return data.user;
  }

  parseParams(req)
    .then(validateParams)
    .then(userData => usersSrvc
      .getUser({ _id: userData._id })
      .then(user => {

        return { user, userData };
      })
    )
    .then(doEdits)
    .then(user => usersSrvc.saveUser(user))
    .then(user => res.send(user))
    .catch(next);
};

exports.createPlayer = function(req, res, next){
  function parseParams(body) {
    var allowedFields = ['email', 'name', 'APNSToken', 'password'];
    var userData = _.pick(body, allowedFields);
    userData.role = 'user';
    userData.status = 'active';
    return Promise.resolve(userData);
  }

  function validateParams(userData) {
    return _validateUserData(userData);
  }

  function doEdits(userData) {
    var user = _.assign({}, userData);
    user.status = 'active';

    return user;
  }

  parseParams(req.body)
    .then(validateParams)
    .then(doEdits)
    .then(userData => usersSrvc
      .createUser(userData)
      .then(user => {
        user.set("password", userData.password);
        return user;
      })
      )
    .then(user => usersSrvc.saveUser(user))
    .then(user => res.send(user))
    .catch(next);
};
exports.updatePlayer = function(req, res, next){
  function parseParams(req) {
    var body = req.body;
    var allowedFields = ['email', 'name', 'gamesPlayed', 'gamesWon', 'point'];
    var userData = _.pick(body, allowedFields);
    userData._id = req.params._id;
    userData.role = 'user';
    userData.status = 'active';
    if(req.files.image){
      var image =req.files.image;
      userData.imageUrl = image.path.replace(/^.*[\\\/]/, '');
    }
    return Promise.resolve(userData);
  }

  function validateParams(userData) {
    if (!validationUtil.isValidObjectId(userData._id)) {
      return customErrors.rejectWithUnprocessableRequestError({ paramName: 'id', errMsg: 'must be a valid id' });
    }
    var allowedStatuses = consts.USER.STATUSES;
    if (!_.includes(allowedStatuses, userData.status)) {
      return customErrors.rejectWithUnprocessableRequestError({ paramName: 'status', errMsg: 'must be a valid value'});
    }
    return _validateUserData(userData);
  }

  function doEdits(data) {
    _.extend(data.user, data.userData);
    return data.user;
  }

  parseParams(req)
    .then(validateParams)
    .then(userData => usersSrvc
      .getUser({ _id: userData._id })
      .then(user => {
        return { user, userData };
      })
    )
    .then(doEdits)
    .then(user => usersSrvc.saveUser(user))
    .then(user => res.send(user))
    .catch(next);
};

exports.getPlayers = function(req, res, next){
  usersSrvc
    .getUsers({role:'user'}, 'email name role status gamesPlayed gamesWon point badges friends')
    .then(users => res.send(users))
    .catch(next);
};

exports.getFriends = function(req, res, next){
  usersSrvc
    .getUsers({role:'user'}, 'email name role status gamesPlayed gamesWon point')
    .then(users => res.send(users))
    .catch(next);
};

exports.addFriends = function(req, res, next){
  usersSrvc
    .getUsers({role:'user'}, 'email name role status gamesPlayed gamesWon point')
    .then(users => res.send(users))
    .catch(next);
};

exports.updateFriend = function(req, res, next){
   usersSrvc
    .getUsers({role:'user'}, 'email name role status gamesPlayed gamesWon point')
    .then(users => res.send(users))
    .catch(next);
};

exports.deleteFriend = function(req, res, next){
  usersSrvc
    .getUsers({role:'user'}, 'email name role status gamesPlayed gamesWon point')
    .then(users => res.send(users))
    .catch(next);
};

exports.clearFriends = function(req, res, next){
  usersSrvc
    .getUsers({role:'user'}, 'email name role status gamesPlayed gamesWon point')
    .then(users => res.send(users))
    .catch(next);
};

exports.getBadges = function(req, res, next){
  usersSrvc
    .getUsers({role:'user'}, 'badges')
    .then(users => res.send(users))
    .catch(next);
};

exports.addBadge = function(req, res, next){
  function parseParams(req) {
    var body = req.body;
    var allowedFields = ['_id'];
    var badge = _.pick(body, allowedFields);
    var _userId = req.params._id;
    var badgeData = {_userId, badge};

    return Promise.resolve(badgeData);
  }

  function validateParams(badgeData) {
    if (!validationUtil.isValidObjectId(badgeData._userId)) {
      return customErrors.rejectWithUnprocessableRequestError({ paramName: 'user id', errMsg: 'must be a valid id' });
    }
    if (!validationUtil.isValidObjectId(badgeData.badge._id)) {
      return customErrors.rejectWithUnprocessableRequestError({ paramName: 'badge id', errMsg: 'must be a valid id' });
    }
    return Promise.resolve(badgeData);
  }

  function doEdits(badgeData) {
    var badge = _.assign({}, badgeData);
    return badge;
  }

  parseParams(req)
    .then(validateParams)
    .then(doEdits)
    .then(badge => usersSrvc.addBadge(badge))
    .then(user => res.send(user))
    .catch(next);
};


function _validateUserData(userData) {
  if (!validationUtil.isValidEmail(userData.email)) {
    return customErrors.rejectWithUnprocessableRequestError({
      paramName: 'email:'+userData.email,
      errMsg: 'is required and must be a valid email'
    });
  }

  return Promise.resolve(userData);
}
