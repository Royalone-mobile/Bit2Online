'use strict';


var auth   = require('../middleware/auth');
var config = require('../config/environment');
var apiVer = config.get('api:version');
var users  = require('../controllers/users.js');
/* GET users listing. */


module.exports = app => {
  app.get(`/api/${apiVer}/users/getUserById/:_id`, users.getUserById);
  app.get(`/api/${apiVer}/users/getUserByEmail/:email/:password`, users.getUserByEmail);
  app.get(`/api/${apiVer}/users`,  users.getUsers);
  app.post(`/api/${apiVer}/users/createUser`, users.createUser);
  app.put(`/api/${apiVer}/users/:_id`, auth.requireRolesWrapper('admin'), users.updateUser);

  app.get('/api/test', function(){
  	var err = new Error('Invalid API end point');
    err.statusCode = 404;
    next(err);
  });

  app.use('/api', function(req, res, next) {
	  res.render('users', { title: 'Big2Online' });
  });

  //app.use('/api/${apiVer}/users', function(req, res, next) {
   // res.render('users', { title: users.getUsers()});
  //});
  app.use('/api/${apiVer}/users/:_id', function(req, res, next) {
    res.render('users', { title: qwerqwrwqe});
  });

  app.use('/api/${apiVer}/users', function(req, res, next) {
    res.render('users', { title: users.getUserByEmail()});
  });

  app.post(`/api/${apiVer}/player_invite`, users.invitePlayer);
  app.get(`/api/${apiVer}/players/:_id`, users.getUserById);
  app.get(`/api/${apiVer}/players`, users.getPlayers);
  app.post(`/api/${apiVer}/players`, users.createPlayer);
  app.put(`/api/${apiVer}/players/:_id`, users.updatePlayer);
  app.post(`/api/${apiVer}/update_token/:_id`, users.updateToken);
  app.post(`/api/${apiVer}/player_invite_accept`, users.acceptInvite);
  /*app.get(`/api/${apiVer}/player_friends/:_id`, users.getFriends);
  app.post(`/api/${apiVer}/player_friends/:_id`, users.addFriends);
  app.put(`/api/${apiVer}/player_friends/:_id/:_friendId`, users.updateFriend);
  app.delete(`/api/${apiVer}/player_friends/:_id/:_friendId`, users.deleteFriend);
  app.delete(`/api/${apiVer}/player_friends/:_id`, users.clearFriends);*/

 // app.get(`/api/${apiVer}/player_badges/:_id`, users.getBadges);
  app.post(`/api/${apiVer}/player_badges/:_id`, users.addBadge);
};

