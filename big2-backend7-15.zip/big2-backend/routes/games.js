'use strict';

var config = require('../config/environment');
var auth   = require('../middleware/auth');
var games  = require('../controllers/games');
var users  = require('../controllers/users.js');
var apiVer = config.get('api:version');

module.exports = app => {

  //app.get(`/api/${apiVer}/games/:_id`, games.getGameById);
  app.get(`/api/${apiVer}/games`, games.getGames);
  app.post(`/api/${apiVer}/games/createGame`, games.createGame);
  app.get(`/api/${apiVer}/games/getGame`, games.createGame);

  app.get(`/api/${apiVer}/getMyUser`,  users.getMyUser);

	console.log(`/api/${apiVer}/games`);
	
  //app.put(`/api/${apiVer}/games/:_id`, games.updateGame);
  //app.post(`/api/${apiVer}/game_remove_player`, games.removePlayer);
  // app.post(`/api/${apiVer}/game_write_task`, games.writeTask);
  // app.delete(`/api/${apiVer}/games/:_id`, games.deleteGame);
  // app.post(`/api/${apiVer}/game_create`, games.createGameAndFirstRound );
  // app.post(`/api/${apiVer}/my_games`, games.getGamesForUser);
};
