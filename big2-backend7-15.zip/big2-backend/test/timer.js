setInterval(() => {
  console.log('timeout');
}, 2000);

setImmediate(() => {
  console.log('immediate');
});