var consts = require('./config');
var io = consts.getSocket();
io.on('connection', function(socket){
	console.log('socketio connected');
});