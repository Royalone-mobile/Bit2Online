 'use strict';
var customErrors = require('n-custom-errors');
var Game         = require('mongoose').model('game');


exports.getGames = (filter,keys) => {
	return Game.find(filter,keys)
		.populate('gamePlayers')
		.populate('gameInvites')
		.populate('gameCreator')
		.exec();
}

exports.getGame  = (filter, keys) => {
	return Game.findOne(filter,keys)
		.populate('gamePlayers')
		.populate('gameInvites')
		.populate('gameCreator')
		.select(keys)
		.exec()
		.then( game => {
			if(!game) {
				return customErrors.rejectWithObjectNotFoundError('game is not found');
			}
			return game;
		});
};

exports.createGame = gameData => {

  console.log('userServ.createGame');
	var filter = {
		gameName: (gameData.gameName || '').toLowerCase()
	};
	return Game
			.count(filter)
			.then(cnt => {
				return Game.create(gameData);
	});
}

exports.startGame = gameData => {
  var filter = {
    gameName: (gameData.gameName || '').toLowerCase(),
    gameCreator: (gameData.gameCreator ||'').toLowerCase(),
  }
  return Game
          .findOne(filter)
          .exec()
          .then(game => {
            if(!game){
              return customErrors.rejectWithObjectNotFoundError('game is not found');
            }
            return game;
          })
          .then(game => {
             game.status = 'open';
          });
}

exports.pauseGame = gameData => {
  var filter = {
    gameName: (gameData.gameName || '').toLowerCase(),
    gameCreator: (gameData.gameCreator ||'').toLowerCase(),
  }
  return Game
          .findOne(filter)
          .exec()
          .then(game => {
            if(!game){
              return customErrors.rejectWithObjectNotFoundError('game is not found');
            }
            return game;
          })
          .then(game => {
             game.status = 'paused';
          });
}


exports.resumeGame = gameData => {
  var filter = {
    gameName: (gameData.gameName || '').toLowerCase(),
    gameCreator: (gameData.gameCreator ||'').toLowerCase(),
  }
  return Game
          .findOne(filter)
          .exec()
          .then(game => {
            if(!game){
              return customErrors.rejectWithObjectNotFoundError('game is not found');
            }
            return game;
          })
          .then(game => {
             game.status = 'playing';
          });
}


exports.saveGame = game => {
	return game.save();
}


exports.getPlayers = gameId => {
	var filters = {_id: gameId};
	return Game
		.findOne(filter)
		.populate('gamePlayers', 'name email')
		.exec()
		.then(game => {
			if(!game){
				return customErrors.rejectWithObjectNotFoundError('game is not found');
			}
			return game;
		});
}


exports.addInvites = data => {
  var filter = {
    _id: data.gameId
  }

  var inviteList  = data.inviteList;
  var userArr = [];

  for(var i=0; i<inviteList.length; i++){
    var user = inviteList[i];
    userArr.push(user.userId);
  }
  return Game
    .findOne(filter)
    .then(game => {
      if (!game){
        return customErrors.rejectWithObjectNotFoundError('game is not found');
      }
      return game;  
    })
    .then(game => {
      game.gameInvites = game.gameInvites.concat(userArr); 
      console.log(game);
      return game.save();  
    });
  
}

exports.getGamesForUser = userId =>{
  var filter = {
    gamePlayers: {$eq: userId}
  };
  return exports.getGames(filter, "gameName status startTime endTime gameCreator gameWinner gamePlayers gameRounds currentRound");
}

exports.removeInvite = data => {
  var filter = {
    _id : data.gameId

  };
  var subfilter = {
    $pull: {gameInvites : data.userId}
  };
  return Game
    .update(filter, subfilter)
    .exec();
}

exports.removePlayer = data => {
  var filter = {
    _id : data.gameId

  };
  var subfilter = {
    $pull: {gamePlayers : data.userId}
  };
  return Game
    .update(filter, subfilter)
    .exec();
}



exports.addPlayer = data => {
  var filter = {
    _id : data.gameId
  }

  var subfilter = {
    $push: {gamePlayers : data.userId}
  };
  return Game
    .update(filter, subfilter)
    .exec();
}

exports.deleteGame = game => {
  return game.remove();

  var filter = {
    gameName: (gameData.gameName || '').toLowerCase(), 
    gameCreator: (gameData.gameCreator|| '').toLowerCase(),
  };

  return Game
    .findOne(filter)
    .then(game => {
      if (!game){
        return customErrors.rejectWithObjectNotFoundError('game is not found');
      }
      return game;  
    })
    .then(game => {
      return game.remove();  
    });
};

