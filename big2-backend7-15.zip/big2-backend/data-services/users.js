'use strict';

var customErrors = require('n-custom-errors');
var User         = require('mongoose').model('user');


exports.getUsers = (filter, keys) => {
  return User
    .find(filter, keys)
    .populate('friends', 'name email' )
    .sort('email')
    .exec();
};

exports.getUser = (filter, keys) => {
  return User
    .findOne(filter)
    .populate('friends' , 'name email')
    .select(keys)
    .exec()
    .then(user => {
      if (!user) {
        return customErrors.rejectWithObjectNotFoundError('user is not found');
      }
      return user;
    });
};

exports.handleFacebookAuth = (accessToken, refreshToken, profile) => {

    var user = {
        'email': profile.emails[0].value,
        'firstName' : profile.name.givenName,
        'lastName' : profile.name.familyName,
        'facebookId'   : profile.id,
        'role' : 'user',
        'provider' : 'facebook'
    }
    var filter = {
      facebookId: user.id,
      email: (user.email || '').toLowerCase(),
      provider: 'facebook',
    };
  return User
    .findOne(filter)
    .exec()
    .then(userData => {
        if(!!userData){
          console.log('data exists');
          return userData;
        }
        else{
          Promise.resolve(userData);
        }
      })
    .then(userData => {

        if(!!userData){
          return userData
        } else {
              console.log('user Created');
          return User.create(user);
        }
    });
  /* User.findOrCreate(filter, user, (err, result) => {
      if (!user){
         return customErrors.rejectWithObjectNotFoundError('user is not created');
      }
      return user; 
    });*/
};

exports.createUser = userData => {

  var filter = {
    email: (userData.email || '').toLowerCase()
  };
  
  return User
    .count(filter)
    .then(cnt => {
      if (cnt > 0) {
        return customErrors.rejectWithDuplicateObjectError('This email is already in use');
      }
      console.log("userService.createUser");
      return User.create(userData);
    });
};

exports.saveUser = user => {
  return user.save();
};

exports.addBadge = badgeData => {
  var badge = badgeData.badge;
  var filter = {
    _id: badgeData._userId,
    badges : { $ne : badge._id}
  }

  return User
    .findOne(filter)
    .then(user => {
      if (!user){
        return customErrors.rejectWithObjectNotFoundError('user is not found /or badge is already exist');
      }
      return user;  
    })
    .then(user => {
      user.badges.push(badge._id); 
      return user.save();  
    });
  
};
