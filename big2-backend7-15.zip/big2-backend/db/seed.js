'use strict';

/* jshint maxlen: false */
/* jshint quotmark: false */
/* jshint newcap: false */

var _                    = require('lodash');
var mongoose             = require('mongoose');
var db                   = require('./');
var log                  = require('../util/logger').logger;
var User                 = mongoose.model('user');
var ObjectId             = mongoose.Types.ObjectId;

function clearDb() {
  var ops = _(mongoose.models)
    .keys()
    .map(modelName => mongoose.model(modelName).remove())
    .value();

  return Promise.all(ops);
}

function insertUsers() {
  var users = [
    { "_id" : ObjectId("57fa20920cb5ff30ec857430"), "name" : "user1", "email" : "user1@mail.com", "hashedPassword" : "xKd3xarlKs8fn0iINhD5k0ex5hm4z3ctq1Q6tgsSV8Urogr/qAukddTmN9Pxjrsvfk4DQxAncSbKAFz/k/8GbA==", "salt" : "+zP2BiBaskkh9hXKzh5L5w==", "status" : "active", "invited" : false,  "role" : "user" },
    { "_id" : ObjectId("57fa20920cb5ff30ec85742f"), "name" : "admin", "email" : "admin@mail.com", "hashedPassword" : "6nvd0F9sEW7yEvjeqT1XC2HO14Knw2Ow2OEJMKhCaSDjtnVftwFohGQ48PSVX5Tl8gFiX4J3HhCzuOkb+iS1Xg==", "salt" : "eTxOoNgYA4kBTQb0Z3JJKQ==", "status" : "active", "invited" : false,  "role" : "admin" },
    { "_id" : ObjectId("57fa20920cb5ff30ec857431"), "name" : "user2", "email" : "user2@mail.com", "hashedPassword" : "Tp8ipKT2vyk3n+P3lzat5+HF62JAg2Uf/CkwQgUA2SV9Sn0unts1r/1WpXSxuWgsVOC3x7YdxQrGGDfh+n1HIg==",  "status" : "active", "invited" : false,  "role" : "user" }
  ];
  return User.create(users);
}


db
  .connect()
  .then(clearDb)
  .then(insertUsers)
  .then(() => log.info('All scripts applied succesfully'))
  .catch(err => log.error('The scripts are not applied', err))
  .finally(db.disconnect);
