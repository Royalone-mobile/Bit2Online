'use strict';
'user strict';
var mongoose = require('mongoose');
var consts = require('../../consts');
var findOrCreate = require('findorcreate-promise');


var gameSchema = new mongoose.Schema({
	gameName: String,
	bettingMoney: Number,
	turnInterval: Number,
	status: {
		type: String,
		required: true,
		enum: consts.GAME.STATUSES,
		default:'init'
	},
	gameCreator:
	{
		type: mongoose.Schema.ObjectId,
		ref: 'user'
	},
	gamePlayers: [{
		type:mongoose.Schema.ObjectId,
		ref:'user',
	}],

	gameInvites: [{
    type: mongoose.Schema.ObjectId,
    ref: 'user',
  }],
});

module.exports=mongoose.model('game', gameSchema);
