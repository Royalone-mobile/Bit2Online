'use strict';
var mongoose     = require('mongoose');
var consts       = require('../../consts');

var findOrCreate = require('findorcreate-promise');

var userSchema = new mongoose.Schema({
	email:{
		type:String,
		required:true
	},
	name: String,
	avatarUrl: {
		type:String,
		required:true,
		default:"user_default.png"
	},
	role: {
		type: String,
		required:true,
		default: 'user_default.png'	
	},
	hashedPassword: String,
	salt: {
		type:String,
		default: '20tfkVec7bQymdcpecBLDg=='
	},
	status:{
		type: String
		//enum: consts.USERS.STATUSES
	},
	invited:{
		type:Boolean,
		default:false	
	},
	forgotKey:String,
	forgotKeyExpiryDate:Date,
	lastLogin:Date,
	lastSeen:Date,

	friends: [{
    type: mongoose.Schema.ObjectId,
    ref: 'user',
  }],

  games: [{
    type: mongoose.Schema.ObjectId,
    ref: 'game',
  }],

  gamesPlayed: {
    type: Number,
    required: true,
    default : 0
  },
  gamesWon: {
    type: Number,
    required: true,
    default : 0
  },
  point: {
    type: Number,
    required: true,
    default : 0
  }
});

userSchema.plugin(findOrCreate);

require('./user-middleware')(userSchema);

module.exports = mongoose.model('user', userSchema);
