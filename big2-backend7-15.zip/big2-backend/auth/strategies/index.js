'use strict';

module.exports = () => {
  require('./local')();
  require('./facebook-token')();
};
