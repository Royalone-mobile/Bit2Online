#ifndef __SELTABLE_SCENE_H__
#define __SELTABLE_SCENE_H__

#include "cocos2d.h"
#include "Global.h"
#include "AppDelegate.h"
using namespace cocos2d;

class UIBlindBar;
class SelTableScene : public cocos2d::Layer

{
public:
    static cocos2d::Scene* createScene();

    virtual bool init();
   
	Sprite *			pSpriteBack;
	Sprite *			_title;
	UIBlindBar*					m_pBlindBar;
	CCLabelTTF *m_pUserNameLabel;
	CCLabelTTF *m_pCurBalanceLabel;

	void menuCallbackHandler(Ref * pSender);

	void drawImages();
	void drawButtons();
	void drawLabels();

    // implement the "static create()" method manually
    CREATE_FUNC(SelTableScene);
};

#endif //__SELTABLE_SCENE_H__
