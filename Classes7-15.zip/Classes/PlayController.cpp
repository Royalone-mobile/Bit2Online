#include "PlayController.h"
#include "SimpleAudioEngine.h"
#include "Global.h"
#include "ViewSetting.h"
#include "TableScene.h"
#include "base/GameTable.h"
#include "base/NetLogic.h"
USING_NS_CC;
using namespace CocosDenshion;

extern GE::GameTable	m_GameTable;

static CCString* strName_Background = new CCString("board_back.png");

Scene* PlayController::createScene()
{
	// 'scene' is an autorelease object
	Scene* scene = NULL;
	do {

	scene = Scene::create();

	// 'layer' is an autorelease object
	auto layer = PlayController::create();

	scene->addChild(layer);
	} while (0);
	return scene;
}

// on "init" you need to initialize your instance
bool PlayController::init()
{
    //////////////////////////////
	do {
		if (!Layer::init())
		{
			return false;
		}
		
	} while (0);
    return true;
}

void PlayController::onEnter()
{
    Layer::onEnter();
    scheduleUpdate();
}

void PlayController::onExit()
{
    Layer::onExit();
}

void PlayController::sitAutoAIPlayer()
{
    for(int i =0 ; i< SEAT_COUNT; i++)
    {
        GE::Player player;
        CCString *chIDURL = new CCString("image/iPhone/common/"+ strName_Background->_string);
        
        player.setPlayerID(i);
        player.setPlayerName("");
        player.setCharID(i);
        player.setEmployedMoney(0);
        player.setPlaying(true);
        player.setPlayerCHIDURL(chIDURL->getCString());
        m_GameTable.sit(i, player);
    }
}
bool	PlayController::setPlayerAction(int nPlayerID, char* cards, unsigned long nCardCount)
{
    CCLOG("setPlayerAction");
    schedule(CC_SCHEDULE_SELECTOR(PlayController::playAICards),1);

    m_GameTable.setAction(nPlayerID, cards, nCardCount);
    //m_GameTable.setCurPlayerSeatID((nPlayerID+1)%4);
    return true;
}

void PlayController::playAICards(float dt)
{
    CCLOG("PlayAICArds");
    CCLOG("PlayAICards %f", dt);
    TableScene *tableScene = (TableScene*)this->getParent();
    
    int nCurPlayerSeatID = m_GameTable.getCurPlayerSeatID();
    int nPlayerID = m_GameTable.getPlayerfromSeatID(nCurPlayerSeatID)->getPlayerID();
    
    GE::Actions actions = m_GameTable.getAvailableActions(nPlayerID);
    

    GE::Action action;

	int mySeatID = NetLogic_GetSeatID();

    if(nCurPlayerSeatID == mySeatID)
    {
		unschedule(CC_SCHEDULE_SELECTOR(PlayController::playAICards));
		//tableScene->showActionButtons(true);
        return;
    }

	int nActionCount = actions.size();

	bool isGameFinished = false;
	if (nActionCount == 0)
	{
		char selectedCards[MAX_CARD_COUNT] = { 0 , };
		unsigned long nSelectedCount = 0;

		isGameFinished = m_GameTable.setAction(nPlayerID, selectedCards, nSelectedCount);
		tableScene->setAction(nPlayerID, selectedCards, nSelectedCount, true);
	}
	else
	{
		int id = rand() % actions.size();
		action = actions[id];
		isGameFinished = m_GameTable.setAction(nPlayerID, action.Cards, action.nCardCount);
		tableScene->setAction(nPlayerID, action.Cards, action.nCardCount, true);
	}

	if (isGameFinished)
	{
		CCLOG("Game is Round Over");
		unschedule(CC_SCHEDULE_SELECTOR(PlayController::playAICards));
		tableScene->finishGame(nPlayerID, true);
	}
}
