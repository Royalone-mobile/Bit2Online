#include "TableScene.h"
#include "SimpleAudioEngine.h"
#include "Global.h"
#include "UITableCards.h"
#include "base/NetLogic.h"
#include "ResultScene.h"
#include "ViewMenu.h"
USING_NS_CC_EXT;
using namespace CocosDenshion;
extern GE::GameTable	m_GameTable;

extern CGameSetting				g_GameSetting;

enum {
	kTagMenuLayer,
	kTagFriendLayer,
	kTagInviteLayer,
	kTagRegisterLayer,
	kTagLayerCount,
	kTagResultLayer,
};

#define TOP_LAYER_ZORDER		1001
#define RESULT_LAYER_ZORDER		900

#define CHAT_PAN_WIDTH				200
#define CHAT_PAN_PAD_WIDTH			400
extern CGameSetting g_GameSetting;
extern TextureManager g_TextureManager;

static const CCPoint ptSeatPos[] = {
	{ 97, 238 },
	{ 376, 105 },
	{ 203, 8 },
	{ 26, 105 },
};

static const CCPoint ptWaittingPos[] = {
	{ 97, 238 },
	{ 356, 113 },
	{ 203, -30 },
	{ 46, 113 },
};

static const CCPoint ptPadWaittingPos[] = {
	{ 97, 227 },
	{ 377, 118 },
	{ 203, -30 },
	{ 29, 118 },
};

static const CCPoint ptEmptyPos[] = {
	{ 97, 238 },
	{ 360, 93 },
	{ 203, -55 },
	{ 43, 93 },
};

static const CCPoint ptPadEmptyPos[] = {
	{ 97, 238 },
	{ 377, 98 },
	{ 203, -55 },
	{ 29, 98 },
};

static const CCPoint ptTableCardPos[] = {
	{ 213, 177 },
	{ 264, 143 },
	{ 213, 119 },
	{ 162, 143 },
};

static CCString* strName_Background = new CCString("board_back.png");
static CCString* strName_chat_Background = new CCString("chat_background.png");
static CCString* strName_edit_Chat = new CCString("chat_input_pan.png");
static CCString* strTableRes = new CCString("table_res.png");

static const CCRect rt_All = CCRectMake(0, 0, IPHONE_WIDTH, IPHONE_HEIGHT);
static const CCRect rt_Self_Char = CCRectMake(408, 269, 39, 43);

static const CCRect rt_Btn_Menu = CCRectMake(395, 4, 80, 19);
static const CCRect rt_Btn_Friend = CCRectMake(312, 4, 80, 19);
static const CCRect rt_Btn_OK = CCRectMake(5, 240, 76, 23);
static const CCRect rt_Btn_Pass = CCRectMake(5, 288, 76, 23);
static const CCRect rt_Chat_Content = CCRectMake(5, 10, 480, 20);
static const int nInterval_Chat_Content = 15;
static const CCRect rt_Chat_Label = CCRectMake(12, 295, 150, 9);
static const int nInterval_Chat_Label = 10;
static const CCRect rt_Btn_Chat_Input = CCRectMake(416, 238, 42, 28);
static const CCRect rt_Edit_Chat_Input = CCRectMake(4, 130, 472, 20);
static const CCRect rt_Label_Stack = CCRectMake(136, 7, 48, 12);
static const CCRect rt_Label_TableName = CCRectMake(1, 7, 74, 10);

static const CCPoint ptTimerCtrlPos = CCPointMake(394, 228);

static const CCRect rtFriendLayer = CCRectMake(312, 30, 162, 145);
static const CCRect rtPadFriendLayer = CCRectMake(670, 58, 323, 290);

static const CCPoint pt_Pad_Btn_OK = CCPointMake(85, 160);
static const CCPoint pt_Pad_Btn_Pass = CCPointMake(85, 80);
static const CCPoint pt_Pad_Btn_Chat = CCPointMake(490, 30);

static const CCPoint pt_Pad_Lbl_Name = CCPointMake(103, 745);
static const CCPoint pt_Pad_Lbl_Stake = CCPointMake(334, 745);

static const CCPoint pt_Pad_Self_Char = CCPointMake(923, 107);
static const CCRect rt_Pad_Self_Char = CCRectMake(884, 618, 78, 86);

static const CCRect rt_Pad_Edit_Chat_Input = CCRectMake(42, 321, 960, 36);

static const CCPoint ptPadTimerCtrlPos = CCPointMake(920, 194);

static const CCPoint ptPadChatLabel1 = CCPointMake(512, 33);
static const CCPoint ptPadChatLabel2 = CCPointMake(512, 12);

static const CCSize padChatlabelsize = CCSizeMake(980, 48);


Scene* TableScene::createScene()
{

	Scene* scene = NULL;
	do {

	scene = Scene::create();
	auto layer = TableScene::create();

	scene->addChild(layer);
	} while (0);
	return scene;
}


bool TableScene::init()
{
    
	do {
		if (!Layer::init())
		{
			return false;
		}
        m_pCardManager = CardManager::create();
        m_pCardManager->initCardManager(this);
        
        m_playController = PlayController::create();
        this->addChild(m_playController);
        
        drawImages();
        this->addChild(m_pCardManager,1000);
        
		drawButtons();
		drawLabels();
		drawChatCtrls();
		initTextField();

		drawTimerCtrl();
		m_fClearCardsDelayTime = 0;


        m_pCardManager->setParent(this);
        
        
        m_playController->sitAutoAIPlayer();
        sit(0, 0, true);
		NetLogic_SetSeatID(0);
        NetLogic_SetUserState(stateTableSeat);
        
        NetLogic_StartGame();
        startGame(true);
        
    } while (0);
    return true;
}

void TableScene::drawImages()
{
	Size size = Director::getInstance()->getWinSize();
	
	pSpriteBack = Sprite::create("image/iPhone/common/"+ strName_Background->_string);
    pSpriteBack->setScale(CGameSetting::getInstance()->g_scaleFactor);
	pSpriteBack->setPosition(Vec2(size.width * 0.5f, size.height * 0.5f ));
	this->addChild(pSpriteBack);
	m_pPlayers = new UIPlayer[SEAT_COUNT];
	for (int i = 0; i < SEAT_COUNT; i++)
	{
		CCPoint pt = this->getPlayerPos(i);
		m_pPlayers[i].initView(pt, this, i);
		pSpriteBack->addChild(&m_pPlayers[i], 1);
	}
	m_pPlayers[0].setMainPlayer(true);

	for (int i = 0; i < SEAT_COUNT; i++) {
        updateUIPlayer(i, false);
    }
}


void TableScene::sit(int nSeatID, int nPlayerID, bool bFromServer)
{
	int nPos = getPosfromSeatID(nSeatID);
	updateUIPlayer(nSeatID, true);
	CCPoint pt = this->getPlayerPos(nPos);
	m_pPlayers[nPos].refreshView(pt, this, nPos);
	m_pPlayers[nPos].setSeatState(TGAME_SEAT_SIT);
	m_pPlayers[nPos].drawRect();
}
void TableScene::startGame(bool bFromServer)
{
    if(bFromServer)
    {
        GE::GameTable & objGameTable = NetLogic_GetGameTable();
        if(NetLogic_GetUserState() == stateTableSeat)
        {
            int nCurPlayerSeatID = objGameTable.getCurPlayerSeatID();
            if(NetLogic_GetSeatID() == nCurPlayerSeatID)
            {
                this->showActionButtons(true);
            }
            else
            {
                this->showActionButtons(false);
            }
        }
        m_pCardManager->clearCardManager();
        for(int i = 0; i<SEAT_COUNT; i++)
            this->updateUIPlayer(i,false);

		
    }
}

void TableScene::changeTableState()
{
	Size size = Director::getInstance()->getWinSize();

	GE::GameTable &objGameTable = NetLogic_GetGameTable();
	m_pStackLabel->setString(getMoneyString(objGameTable.getStackMoney())->_string);
	m_pTableNameLabel->setString(CCString::createWithFormat("%s", objGameTable.getTableName())->_string);
	m_pTimerCtrl->setVisible(false);
	m_pChatBack->setVisible(false);
	m_pChatBackground->setVisible(false);
	
	
	for (int i = 0; i < MAX_CHAT_COUNT; i++) {
		m_pChatContent[i]->setVisible(false);
	}

	//CCDirector::getInstance()->getInstance()->getOpenGLView()->end();
				
	if (NetLogic_GetUserState() == stateTableSeat) {
			m_pChatBtn->setVisible(true);
			m_pChatBtn->setEnabled(true);
			
	}
	else {
		m_pOKBtn->setVisible(true);
		m_pOKBtn->setEnabled(true);
		m_pPassBtn->setVisible(true);
		m_pPassBtn->setEnabled(true);
		m_pChatBtn->setVisible(true);
		m_pChatBtn->setEnabled(true);
	}

	for (int i = 0; i < SEAT_COUNT; i++)
		{
			CCPoint pt = this->getPlayerPos(i);
			m_pPlayers[i].refreshView(pt, this, i);
		}
		m_pPlayers[0].setMainPlayer(true);
		if (m_pCardManager) {
			m_pCardManager->clearCardManager();
		}

	for (int i = 0; i < SEAT_COUNT; i++) {
		this->updateUIPlayer(i, false);
	}
}
void TableScene::updateUIPlayer(int nSeatID, bool bWhenSit)
{
	GE::GameTable& objGameTable = NetLogic_GetGameTable();
	const GE::Player* player = objGameTable.getPlayerfromSeatID(nSeatID);
	int nPos = getPosfromSeatID(nSeatID);
	m_pPlayers[nPos].drawRect();
	if (player == NULL) {
        m_pPlayers[nPos].setSeatState(TGAME_SEAT_EMPTY);
        return;
    }
    m_pPlayers[nPos].setSeatState(TGAME_SEAT_SIT);
    
    m_pPlayers[nPos].setPlayerInfo(player->getPlayerID(), player->getCharID(), player->getPlayerCHIDURL(), player->getPlayerName());
    
    m_pPlayers[nPos].drawRect();
    m_pPlayers[nPos].setWinner(false);
   
	// Set CardCount Label String.

    m_pPlayers[nPos].setCardCount(player->getCurCardCount());
    m_pCardManager->setCards(nPos, player->getCards());

}

void TableScene::initTextField()
{
	textChatMessage = EditBox::create(CCSize(rt_Edit_Chat_Input.size.width, rt_Edit_Chat_Input.size.height), Scale9Sprite::create());
	textChatMessage->setPosition(getPointFrom3GRect(rt_Edit_Chat_Input));
	textChatMessage->setReturnType(ui::EditBox::KeyboardReturnType::DONE);
	textChatMessage->setFontSize(12);
	textChatMessage->setColor(Color3B::WHITE);
	textChatMessage->setInputMode(ui::EditBox::InputMode::ANY);
	textChatMessage->setPlaceHolder("chattingbox");
	textChatMessage->setDelegate(this);//Open client
	textChatMessage->setColor(Color3B(0.65*255,0.65*255,0.65*255));
	textChatMessage->setFontColor(Color3B::WHITE);//Sets the text color
	pSpriteBack->addChild(textChatMessage);
}
void TableScene::drawButtons()
{
	Vector<MenuItem*> items;
	Size size = Director::getInstance()->getWinSize();
	CCTexture2D * texture = CCTextureCache::getInstance()->addImage("image/iPhone/common/" + strTableRes->_string);
	CCRect rt;
	CCSprite * btnSprite0 = Sprite::createWithTexture(texture);
	rt = g_TextureManager.getTextureRect(Pic_Table_Btn_Menu0);
	btnSprite0->setTextureRect(rt);
	
	CCSprite * btnSprite1 = Sprite::createWithTexture(texture);
	rt = g_TextureManager.getTextureRect(Pic_Table_Btn_Menu1);
	btnSprite1->setTextureRect(rt);

	m_pMenuBtn = MenuItemImage::create("image/iPhone/common/" + strName_chat_Background->_string, "image/iPhone/common/" + strName_chat_Background->_string);
	m_pMenuBtn->setNormalImage(btnSprite0);
	m_pMenuBtn->setSelectedImage(btnSprite1);
	m_pMenuBtn->setCallback(std::bind(menu_selector(TableScene::menuCallbackHandler), this, std::placeholders::_1));
	m_pMenuBtn->setPosition(Vec2(getPointFrom3GRect(rt_Btn_Menu, size.height)));
	m_pMenuBtn->setTag(kMenuMenu);
	items.pushBack(m_pMenuBtn);

	btnSprite0 = Sprite::createWithTexture(texture);
	rt = g_TextureManager.getTextureRect(Pic_Table_Btn_Friend0);
	btnSprite0->setTextureRect(rt);

	btnSprite1 = Sprite::createWithTexture(texture);
	rt = g_TextureManager.getTextureRect(Pic_Table_Btn_Friend1);
	btnSprite1->setTextureRect(rt);
	
	m_pFriendBtn = MenuItemImage::create("image/iPhone/common/" + strName_chat_Background->_string, "image/iPhone/common/" + strName_chat_Background->_string);
	m_pFriendBtn->setNormalImage(btnSprite0);
	m_pFriendBtn->setSelectedImage(btnSprite1);
	m_pFriendBtn->setPosition(getCenterPoint(rt_Btn_Friend, size.height));
	m_pFriendBtn->setCallback(std::bind(menu_selector(TableScene::menuCallbackHandler), this, std::placeholders::_1));
	m_pFriendBtn->setTag(kMenuMenu);
	items.pushBack(m_pFriendBtn);

	btnSprite0 = Sprite::createWithTexture(texture);
	rt = g_TextureManager.getTextureRect(Pic_Table_Btn_Chat0);
	btnSprite0->setTextureRect(rt);

	btnSprite1 = Sprite::createWithTexture(texture);
	rt = g_TextureManager.getTextureRect(Pic_Table_Btn_Chat1);
	btnSprite1->setTextureRect(rt);


	m_pChatBtn = MenuItemImage::create("image/iPhone/common/" + strName_chat_Background->_string, "image/iPhone/common/" + strName_chat_Background->_string);
	m_pChatBtn->setNormalImage(btnSprite0);
	m_pChatBtn->setSelectedImage(btnSprite1);
	m_pChatBtn->setCallback(std::bind(menu_selector(TableScene::menuCallbackHandler), this, std::placeholders::_1));
	m_pChatBtn->setPosition(getCenterPoint(rt_Btn_Chat_Input, size.height));
	m_pChatBtn->setTag(kMenuMenu);
	items.pushBack(m_pChatBtn);



	btnSprite0 = Sprite::createWithTexture(texture);
	rt = g_TextureManager.getTextureRect(Pic_Table_Btn_Ok0);
	btnSprite0->setTextureRect(rt);

	btnSprite1 = Sprite::createWithTexture(texture);
	rt = g_TextureManager.getTextureRect(Pic_Table_Btn_Ok1);
	btnSprite1->setTextureRect(rt);


	CCSprite * btnSprite2 = Sprite::createWithTexture(texture);
	rt = g_TextureManager.getTextureRect(Pic_Table_Btn_Ok2);
	btnSprite2->setTextureRect(rt);

	m_pOKBtn = MenuItemImage::create("image/iPhone/common/" + strName_chat_Background->_string, "image/iPhone/common/" + strName_chat_Background->_string);
	m_pOKBtn->setNormalImage(btnSprite0);
	m_pOKBtn->setSelectedImage(btnSprite1);
	m_pOKBtn->setDisabledImage(btnSprite2);
	m_pOKBtn->setCallback(std::bind(menu_selector(TableScene::menuCallbackHandler), this, std::placeholders::_1));
	m_pOKBtn->setPosition(getCenterPoint(rt_Btn_OK, size.height));
	m_pOKBtn->setTag(kMenuOk);
	items.pushBack(m_pOKBtn);

	btnSprite0 = Sprite::createWithTexture(texture);
	rt = g_TextureManager.getTextureRect(Pic_Table_Btn_Pass0);
	btnSprite0->setTextureRect(rt);

	btnSprite1 = Sprite::createWithTexture(texture);
	rt = g_TextureManager.getTextureRect(Pic_Table_Btn_Pass1);
	btnSprite1->setTextureRect(rt);


	btnSprite2 = Sprite::createWithTexture(texture);
	rt = g_TextureManager.getTextureRect(Pic_Table_Btn_Pass2);
	btnSprite2->setTextureRect(rt);

	m_pPassBtn = MenuItemImage::create("image/iPhone/common/" + strName_chat_Background->_string, "image/iPhone/common/" + strName_chat_Background->_string);
	m_pPassBtn->setNormalImage(btnSprite0);
	m_pPassBtn->setSelectedImage(btnSprite1);
	m_pPassBtn->setDisabledImage(btnSprite2);
	m_pPassBtn->setCallback(std::bind(menu_selector(TableScene::menuCallbackHandler), this, std::placeholders::_1));
	m_pPassBtn->setPosition(getCenterPoint(rt_Btn_Pass, size.height));
	m_pPassBtn->setTag(kMenuPass);
	items.pushBack(m_pPassBtn);


	auto pMenu = Menu::createWithArray(items);
	pMenu->setPosition(Vec2::ZERO);
	pSpriteBack->addChild(pMenu);
}



void TableScene::drawLabels()
{
	Size size = Director::getInstance()->getWinSize();

	m_pStackLabel = CCLabelTTF::create("", "Arial", 12);
	m_pStackLabel->setPosition(getPointFrom3GRect(rt_Label_Stack));
	m_pStackLabel->setColor(ccc3(106, 68, 25));
	pSpriteBack->addChild(m_pStackLabel, 1);

	m_pTableNameLabel = CCLabelTTF::create("", "Arial", 12);
	m_pTableNameLabel->setPosition(getPointFrom3GRect(rt_Label_TableName));
	m_pTableNameLabel->setColor(ccc3(106, 68, 25));
	pSpriteBack->addChild(m_pTableNameLabel,1);

}

void TableScene::drawChatCtrls()
{
	Size size = Director::getInstance()->getWinSize();
	m_pChatBackground = Sprite::create("image/iPhone/common/" + strName_chat_Background->_string);
	m_pChatBackground->setPosition(Vec2(size.width * 0.5f, size.height * 0.5f));
	m_pChatBackground->setVisible(false);
	pSpriteBack->addChild(m_pChatBackground, 1002);

	for (int i = 0; i < MAX_CHAT_COUNT; i++) {
		CCRect rt = rt_Chat_Content;
		rt.origin.y += nInterval_Chat_Content * i;
		rt = getRectFrom3GRect(rt);

		m_pChatContent[i] = CCLabelTTF::create("", g_FontName->_string, 13);
		m_pChatContent[i]->setPosition(getCenterPoint(rt, size.height));
		m_pChatContent[i]->setColor(ccc3(255, 255, 255));
		m_pChatContent[i]->setVisible(false);
		pSpriteBack->addChild(m_pChatContent[i], 1003);
	}

	m_pChatHistory[0] =  CCLabelTTF::create("", g_FontName->_string, 13, padChatlabelsize);
	m_pChatHistory[0]->setPosition(ptPadChatLabel1);
	m_pChatHistory[0]->setColor(ccc3(255, 255, 255));
	m_pChatHistory[0]->setVisible(false);
	pSpriteBack->addChild(m_pChatHistory[0], 1002);

	m_pChatHistory[1] = CCLabelTTF::create("", g_FontName->_string, 13, padChatlabelsize);
	m_pChatHistory[1]->setPosition(ptPadChatLabel2);
	m_pChatHistory[1]->setColor(ccc3(255, 255, 255));
	m_pChatHistory[1]->setVisible(false);
	pSpriteBack->addChild(m_pChatHistory[1], 1002);

	m_pChatBack = Sprite::create("image/iPhone/common/" + strName_edit_Chat->_string);
	m_pChatBack->setPosition(getPointFrom3GRect(rt_Edit_Chat_Input, size.height));
	m_pChatBack->setVisible(false);
	pSpriteBack->addChild(m_pChatBack, 1002);
}


void TableScene::onBtnOK()
{
    GE::GameTable & objGameTable = NetLogic_GetGameTable();
    if(NetLogic_GetSeatID() == objGameTable.getCurPlayerSeatID())
    {
        int nPos = getPosfromSeatID(NetLogic_GetSeatID());
        PlayerCard *playerCard = m_pCardManager->getPlayer(nPos);
        char selectedCards[MAX_CARD_COUNT] = {0 , };
        unsigned long nSelectedCount = 0;
        for(int i =0 ; i<CARD_COUNT_PER_PLAYER; i++)
        {
            if(playerCard->selected[i])
            {
                int nCardID = m_pCardManager->getCardID(nPos,i);
                selectedCards[nSelectedCount] = playerCard->playerCards[nCardID];
                nSelectedCount++;
            }
        }
        if(nSelectedCount > 0) {
			//PlayerController setAction should start first.
			m_playController->setPlayerAction(nPos, selectedCards, nSelectedCount);
			setAction(nPos, selectedCards, nSelectedCount, true);
        }
    }

	App->playSE(soundCardOk);
}

void TableScene::onBtnPass()
{
	char cards[5] = { 0,0,0,0,0 };
	GE::GameTable & objGameTable = NetLogic_GetGameTable();
	if (NetLogic_GetSeatID() == objGameTable.getCurPlayerSeatID())
	{
		int nPos = getPosfromSeatID(NetLogic_GetSeatID());
		PlayerCard *playerCard = m_pCardManager->getPlayer(nPos);
		char selectedCards[MAX_CARD_COUNT] = { 0 , };
		unsigned long nSelectedCount = 0;
		m_playController->setPlayerAction(nPos, selectedCards, nSelectedCount);
		setAction(nPos, selectedCards, nSelectedCount, true);
	}

	App->playSE(soundCardPass);
}

void TableScene::menuCallbackHandler(Ref * pSender)
{
	CallFunc * callFunc = NULL;
	int tag = ((MenuItem*)pSender)->getTag();
	
	switch (tag)
	{
		case kMenuOk:
            onBtnOK();
			break;
		case kMenuLogOut:
			App->changeSceneWithState(TGAME_LOGIN);
			break;
		case kMenuPass:
			onBtnPass();
			break;
		case kMenuFindUser:
			break;
		case kMenuFriend:
			break;
		case kMenuLobby:
			App->changeSceneWithState(TGAME_SELTABLE);
			break;
		case kMenuBack:
			App->changeSceneWithState(TGAME_WELCOME);
			break;
		case kMenuMenu:
			onMenu();
			break;
	}
}

void TableScene::onMenu()
{
	CCNode *node = this->getChildByTag(kTagFriendLayer);
	if(node)
		this->removeChild(node, true);
		
	
	MenuLayer* menunode = (MenuLayer*)this->getChildByTag(kTagMenuLayer);
	if (menunode)
	{
		menunode->closeAllSubWindows();
		this->removeChild(menunode, true);
	}
	else
	{
		MenuLayer * pMenu = MenuLayer::create();
		pMenu->setStandUp((NetLogic_GetUserState() == stateTableSeat) ? true : false);
		this->addChild(pMenu, TOP_LAYER_ZORDER, kTagMenuLayer);
		pMenu->setParent(this);
	}

}
CCPoint TableScene::getPlayerPos(int nPos)
{
	CCPoint ptPos = CCPointMake(0, 0);
	int nSeatID = getSeatIDfromPos(nPos);
	ptPos = ptSeatPos[nPos];
	return ptPos;
}

void TableScene::editBoxEditingDidBegin(cocos2d::ui::EditBox* editBox)
{
}

void TableScene::editBoxEditingDidEnd(cocos2d::ui::EditBox* editBox)
{

}

void TableScene::editBoxTextChanged(cocos2d::ui::EditBox* editBox, const std::string& text)
{

}

void TableScene::editBoxReturn(ui::EditBox* editBox)
{

}

void TableScene::setAction(int nPlayerID, char*cards, int nCardCount, bool bFromServer)
{
    GE::GameTable&objGameTable = NetLogic_GetGameTable();
    int nSeatID = objGameTable.getSeatIDfromPlayerID(nPlayerID);
    if (nSeatID == -1)
    {
        return;
    }
    int nPos = getPosfromSeatID(nSeatID);
    if(bFromServer)
    {
        const GE::Player* player = objGameTable.getPlayer(nPlayerID);
        if(!player)
            return;
        if(nCardCount == 0)
        {
            char szChar[16] = "Pass";
            m_pPlayers[nPos].chatBalloonAnimation(szChar);

			if (nPlayerID != (int)NetLogic_GetPlayerID()) {
				App->playSE(soundCardPass);
			}

        }
        else{
            if(player->getCurCardCount() == 1)
            {
                char szChar[16] = "Last Card";
                m_pPlayers[nPos].chatBalloonAnimation(szChar);
            }
			if (nPlayerID != (int)NetLogic_GetPlayerID()) {
				App->playSE(soundCardOk);
			}

        }
        m_pPlayers[nPos].setCardCount(player->getCurCardCount());

		GE::Action action = objGameTable.getLastAction();
		m_pCardManager->setCards(nPos, player->getCards());
        if(objGameTable.getCurPlayerSeatID() == objGameTable.getLastAction().nSeatID)
        {
            for(int i = 0; i< SEAT_COUNT; i++)
                m_pCardManager->setTableCards(i, NULL, 0);
        }
        else{
            if(nCardCount != 0 )
                m_pCardManager->setTableCards(nPos, cards, nCardCount);
        }

		// OK, PASS button display
        if(objGameTable.getCurPlayerSeatID() == NetLogic_GetSeatID()
               && NetLogic_GetUserState() == stateTableSeat)
            {
                this->showActionButtons(true);
            }
            else
                this->showActionButtons(false);

		//Refresh the Cards Selection
		m_pCardManager->refreshSelect();
    }
}
void TableScene::showActionButtons(bool bShow)
{
	if (!bShow) {
		m_pOKBtn->setVisible(false);
		m_pOKBtn->setEnabled(false);
		m_pPassBtn->setVisible(false);
		m_pPassBtn->setEnabled(false);
		m_pCardManager->setSelectable(false);
	}
	else {
		m_pOKBtn->setVisible(true);
		m_pOKBtn->setEnabled(true);
		m_pPassBtn->setVisible(true);
		m_pPassBtn->setEnabled(true);

		GE::GameTable& objGameTable = NetLogic_GetGameTable();
		if (NetLogic_GetSeatID() == objGameTable.getCurPlayerSeatID())
		{
			int nPos = getPosfromSeatID(NetLogic_GetSeatID());
			PlayerCard* playerCard = m_pCardManager->getPlayer(nPos);
			char selectedCards[MAX_CARD_COUNT] = { 0, };
			unsigned long nSelectedCount = 0;

			/* if Selected Card count is bigger than 5 , disables ok, pass button.*/
			if (getSelectedCardsCount(nPos) >= 5)
			{
				m_pOKBtn->setEnabled(false);
				m_pPassBtn->setEnabled(false);
				return;
			}
			else
				m_pPassBtn->setEnabled(false);
			for (int i = 0; i < CARD_COUNT_PER_PLAYER; i++) {
				if (playerCard->selected[i])
				{
					int nCardID = m_pCardManager->getCardID(nPos, i);
					selectedCards[nSelectedCount] = playerCard->playerCards[nCardID];
					nSelectedCount++;
				}
			}
			bool bOKAvailable = objGameTable.isAvailableAction(NetLogic_GetPlayerID(), selectedCards, nSelectedCount);

			m_pOKBtn->setEnabled(bOKAvailable);
			if (NetLogic_GetSeatID() == objGameTable.getLastAction().nSeatID)
                m_pPassBtn->setEnabled(false);
			else
                m_pPassBtn->setEnabled(true);
		}
		m_pCardManager->setSelectable(true);
	}
}

int TableScene::getSelectedCardsCount(int nPos)
{
	PlayerCard* playerCard = m_pCardManager->getPlayer(nPos);

	unsigned long nSelectedCount = 0;

	for (int i = 0; i < CARD_COUNT_PER_PLAYER; i++) {
		if (playerCard->selected[i])
			nSelectedCount++;
	}
	return nSelectedCount;
}
bool TableScene::sitAuto()
{
	if (NetLogic_GetUserState() == stateTableView) {
		GE::GameTable &objGameTable = NetLogic_GetGameTable();
		int nSeatID = -1;
		for (int i = 0; i < SEAT_COUNT; i++)
		{
			if (objGameTable.isAvailableSitFromSeatID(i))
				nSeatID = i;
		}
		if (nSeatID == -1) {

		}
		return true;
	}
	return false;
}

void TableScene::onEnter()
{
    Layer::onEnter();
}

void TableScene::onExit()
{
    Layer::onExit();
}


void TableScene::finishGame(TID nWinnerID, bool bFromServer)
{
	if (bFromServer) {
		GE::GameTable &objGameTable = NetLogic_GetGameTable();

		int nSeatID = objGameTable.getSeatIDfromPlayerID(nWinnerID);
		int nPos = getPosfromSeatID(nSeatID);

		if (nWinnerID == NetLogic_GetPlayerID()) {
			App->playSE(soundWin);
		}
		else {
			App->playSE(soundLose);
		}

		m_pTimerCtrl->setVisible(false);
		this->showActionButtons(false);

		m_pCardManager->clearCardManager();

		CCNode *node = this->getChildByTag(kTagResultLayer);

		if (node == NULL)
			pSpriteBack->addChild(ResultScene::create(), RESULT_LAYER_ZORDER, kTagResultLayer);
		else
			pSpriteBack->removeChild(node, true);
	}

}


void TableScene::showTimerCtrl(bool bShow)
{

	if (bShow) {

		GE::GameTable &objGameTable = NetLogic_GetGameTable();
		TID nSeatID = objGameTable.getCurPlayerSeatID();
		int nPos = getPosfromSeatID(nSeatID);

		CCPoint pos = CCPointMake(0, 0);
		if (nPos == 0)
		{
			pos = ptTimerCtrlPos;
		}
		else
		{
			pos = ptSeatPos[nPos];
			pos.y -= 6;
		}

		m_pTimerCtrl->refreshTimerCtrl(TIME_ACTION_DELAY, pos);

	}
	else
		m_pTimerCtrl->closeTimerCtrl();
		
}

void TableScene::drawTimerCtrl()
{
	//draw Timer Ctrl
	m_pTimerCtrl = TimerCtrl::create();
	m_pTimerCtrl ->initTimerCtrl(this, 20);
	this->addChild(m_pTimerCtrl);
	m_pTimerCtrl->setVisible(false);
}

