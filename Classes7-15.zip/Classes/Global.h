#ifndef _GLOBAL_H_
#define _GLOBAL_H_

#include <string>
#include "cocos2d.h"
#include "base/Common.h"
#include "base/NetLogic.h"
#include "base/GameTable.h"
#include "lib/json/json.h"

USING_NS_CC;


#define COCOS2D_DEBUG 1

#define MAX_GROUP_COUNT 10

#define CARD_COUNT 52
#define CARD_NUMBER_COUNT 13
#define CARD_COUNT_PER_PLAYER 13
#define SEAT_COUNT 4

#define SUIT_COUNT	4

#define MAX_USERNAME_LEN	256
#define MAX_USERPWD_LEN		16
#define MAX_USERCHIDURL_LEN	256	
#define MAX_PLAYER_COUNT	4
#define MAX_CARD_COUNT		5

#define TIME_ACTION_DELAY	20
#define MAX_PLAYERS			4
#define MAX_TABLE_COUNT		500

#define MAX_GROUPNAME_LEN	16
#define MAX_TABLENAME_LEN	16
#define MAX_CHAT_LEN		128

#define TIME_START_GAME_DELAY	9

#define TIME_CHECK_ALIVE_INTERVAL	2	//seconds
#define TIME_CHECK_ALIVE_LIMIT		15	//seconds

#define MAX_LOG_BUF 512
#define LOG_LEVEL 2
#define SEAT_COUNT 4 
#define MAX_CHAT_COUNT	6

enum TGAME_SEAT_STATE {
	TGAME_SEAT_EMPTY,
	TGAME_SEAT_SIT,
	TGAME_SEAT_PLAYING,
};

#define GAME_SETTING_VER	3
//API Endpoints

#define REGISTER_URL "https://big2onlinegame.herokuapp.com/api/v1/users/createUser"
#define LOGIN_URL "https://big2onlinegame.herokuapp.com/api/v1/users/getUserByEmail"
#define CREATE_GAME_URL "https://big2onlinegame.herokuapp.com/api/v1/games/createGame"
using namespace std;
enum {
    kMenuOk,
	kMenuBetDec,
	kMenuBetInc,
	kMenuCreateTable,
	kMenuCancel,
	kMenuMusic,
	kMenuSound,
	kMenuBack,
	kMenuLogin,
	kMenuRanking,
	kMenuCreateRoom,
	kMenuMain,
	kMenuShowAll,
	kMenuHideAll,
	kMenuBuyChips,
	kMenuTutorial,
	kMenuHelp,
	kMenuFindUser,
	kMenuFriend,
	kMenuSetting,
	kMenuLobby,
	kMenuLogOut,
	kMenuSignUp,
	kMenuVibration,
	kMenuBlockChat,
	kMenuFriendState,
	kMenuRemember,
	kMenuNext,
	kMenuPrev,
	kMenuCreate,
	kMenuPass,
	kMenuClose,
	kMenuTopRanking,
	kMenuMenu,
    kMenuForgot,
	kMenuPlay,
    kMenuSit,
	kMenuSitOut,
	kMenuStandUp,
	kMenuMainMenu
};


#define MAX_USERPWD_LEN		16
#define MAX_EMAILADDR_LEN	256

#define TIME_CHECK_IMAGE_UPDATE 1.5
#define CHARACTER_WIDTH		45
#define CHARACTER_HEIGHT	45

#define MAX_CARD_COUNT		5

#define MAX_CHIPKIND_COUNT	6

#define MAX_TABLE_COUNT		500


#define MAX_CHA_IMAGE_COUNT	10

#define MAX_GROUP_COUNT 10

#define MAX_NAME_LETTERS	32
#define MAX_USERPWD_LEN		16
#define MAX_SERVERADDR_LEN	32
#define MAX_EMAILADDR_LEN	256
#define MAX_USERNAME_LEN	256
#define MAX_FRIENDNAME_LEN	128
#define MAX_FRIENDID_LEN	128
#define MAX_FRIENDPHOTO_LEN	256
#define MAX_CHIPNAME_LEN	256
#define MAX_CHIPPHOTO_LEN	256

#define MAX_CHIPKIND_COUNT	6

#define MAX_PLAYERS			4

#define MAX_CHIPKIND_COUNT	6

#define MAX_CHA_IMAGE_COUNT	10

#define MIN_BET_COUNT	10

#define IPHONE_WIDTH	480
#define IPHONE_HEIGHT	320

#define IPAD_WIDTH		1024
#define IPAD_HEIGHT		768

static float g_scaleFactor;


CCRect getRectFrom3GRect(CCRect rt3G);
CCPoint getPointFrom3GRect(CCRect rt3G, float fParentHeight = 0);
CCPoint getCenterPoint(CCRect rt, float fParentHeight = 0);
CCPoint getPointWithBackFrom3GRect(CCRect rt3G, CCRect rt3GBack, float fParentHeight = 0);
int getPosfromSeatID(int nSeatID);
int getSeatIDfromPos(int nPos);
CCSize getSizeFrom3GSize(CCSize Size3G);
CCRect operator+(const CCRect& param1, const CCRect& param2);
CCSprite* getCharacterImage(unsigned long nPlayerId, int nCharacterID, const char * szImageUrl, bool&bLoaded);
CCRect getRectWithBackFrom3GRect(CCRect rt3G, CCRect rtBack3G);

CCString* removeSuffixZero(CCString* str);
CCString * insertComma(CCString * str);
CCString* getMoneyString(TCASH fCash, bool bFlag = false);

CCSize sizeWithFont(const char *string, const char* fontName, float fontSize);
static CCString* g_FontName = new CCString("Thonburi");

enum TDeviceType {
	DEVICE_IPHONE = 0,
	DEVICE_IPAD,
	DEVICE_IPHONE4,
};


class CGameSetting
{
	bool m_bRemember;
	char m_szUserEmail[MAX_EMAILADDR_LEN];
	char m_szUserName[MAX_USERNAME_LEN];
	char m_szUserID[MAX_USERNAME_LEN];
	char m_szPassword[MAX_USERPWD_LEN];
	bool m_bSafeLogout;
	bool m_bChatBlock;
	bool m_bFriendState;
	bool m_bVibration;
	bool m_bSound;
    bool m_bFirstLaunch;
    static CGameSetting * _instance;
	double m_dCash;
public:
	CGameSetting();
	~CGameSetting();
    static CGameSetting* getInstance();
    float g_scaleFactor;
	void setSettings(bool bRemember,
		char* szUserID,
		char* szUserName,
		char *szUserEmail,
		char* szPassword,
		bool bSafeLogout,
		bool bChatBlock,
		bool bFriendState,
		bool bVibration,
		bool bSound);
    
    bool IsFirstLaunch();
    void setFirstLaunch(bool bFirstLaunch);
    
	bool IsRemember();
	void setRemember(bool bRemember);

	void getUserID(char * szUserID);
	void setUserID(char*);

	void getUserName(char * szUserName);
	void setUserName(char*);

	void getUserEmail(char * szUserEmail);
	void setUserEmail(char*);

	void getPassword(char * szPassword);
	void setPassword(char* szPassword);

	bool IsSafeLogout();
	void setSafeLogout(bool bSafeLogout);

	bool IsChatBlock();
	void setChatBlock(bool bChatBlock);

	bool IsFriendState();
	void setFriendState(bool bFriendState);

	bool IsVibration();
	void setVibration(bool bVibration);

	bool IsSoundOn();
	void setSound(bool bSound);

	TCASH getCash();
	void setCash(TCASH dCash);

	void saveGameSetting();
	void loadGameSetting();
};


// label text color
const ccColor3B colorLabelText = ccc3(0, 0, 0);


#endif
