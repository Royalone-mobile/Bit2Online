#include "WelcomeScene.h"
#include "SimpleAudioEngine.h"
#include "Global.h"
#include "ViewSetting.h"
USING_NS_CC;
using namespace CocosDenshion;

enum {
	kTagFriendLayer,
	kTagBuyChipLayer,
	kTagSettingLayer,
	kTagHelpLayer,
	kTagInviteLayer,
	kTagTutorialLayer,
	//kTagRegisterLayer,
	kTagChangeAvaterLayer,
	kTagFindUserLayer,
	kTagLayerCount,
};

#define TOP_LAYER_ZORDER		1001
#define NAME_WIDTH				164

extern int nCurLang;
extern bool						g_bUserImageLoaded;
//extern

static CCString* strTilte = new CCString("WELCOME TO BIG2 POKER ONLINE!!!");



// image name
static CCString* strBackground = new CCString("signup_back.png");
static CCString* strCharacterBack = new CCString("pan_signup_1.png");

// button name
static CCString* strSettingsBtn1 = new CCString("btn_setting_0_e.png");
static CCString* strSettingsBtn2 = new CCString("btn_setting_1_e.png");
static CCString* strFriendsBtn1 = new CCString("btn_friend_0_e.png");
static CCString* strFriendsBtn2 = new CCString("btn_friend_1_e.png");
static CCString* strBuyChipsBtn1 = new CCString("btn_buychip_0_e.png");
static CCString* strBuyChipsBtn2 = new CCString("btn_buychip_1_e.png");
static CCString* strLobbyBtn1 = new CCString("btn_lobby_0_e.png");
static CCString* strLobbyBtn2 = new CCString("btn_lobby_1_e.png");
static CCString* strPlayNowBtn1 = new CCString("btn_playnow_0_e.png");
static CCString* strPlayNowBtn2 = new CCString("btn_playnow_1_e.png");
static CCString* strTutorialBtn1 = new CCString("btn_tutorial_0_e.png");
static CCString* strTutorialBtn2 = new CCString("btn_tutorial_1_e.png");
static CCString* strHelpBtn1 = new CCString("btn_help_0_e.png");
static CCString* strHelpBtn2 = new CCString("btn_help_1_e.png");
static CCString* strLogOutBtn1 = new CCString("btn_exit_0_e.png");
static CCString* strLogOutBtn2 = new CCString("btn_exit_1_e.png");
static CCString* strFindUserBtn1 = new CCString("btn_finduser_0.png");
static CCString* strFindUserBtn2 = new CCString("btn_finduser_1.png");

//iPad Position
static const Point ptSettingsBtn = CCPointMake(196, 146);
static const Point ptFriendsBtn = CCPointMake(376, 146);
static const Point ptBuyChipsBtn = CCPointMake(556, 146);
static const Point ptChaImage = CCPointMake(232, 264);


// image rect
static const Rect rtCharacterBack = CCRectMake(39, 164, 274, 130);
static const Rect rtCharacter = CCRectMake(82, 184, 45, 45);

// button rect
static const Rect rtSettingsBtn = CCRectMake(44, 255, 86, 33);
static const Rect rtFriendsBtn = CCRectMake(133, 255, 86, 33);
static const Rect rtBuyChipsBtn = CCRectMake(222, 255, 86, 33);

static const Rect rtLobbyBtn = CCRectMake(345, 128, 115, 27);
static const Rect rtPlayNowBtn = CCRectMake(345, 161, 115, 27);
static const Rect rtFindUserBtn = CCRectMake(345, 194, 115, 27);
static const Rect rtHelpBtn = CCRectMake(345, 227, 115, 27);
static const Rect rtTutorialBtn = CCRectMake(345, 260, 115, 27);

static const Rect rtLogOutBtn = CCRectMake(426, 13, 38, 18);

// label rect
static const Rect rtUserNameLabel = CCRectMake(144, 183, 160, 24);
static const Rect rtTilteLabel = CCRectMake(25, 127, 300, 24);
static const Rect rtCurBalanceLabel = CCRectMake(145, 200, 200, 24);
static const Rect rtRankingLabel = CCRectMake(144, 217, 180, 24);

// friendlayer rect
static const Rect rtFriendLayer = CCRectMake(133, 107, 162, 145);
static const Rect rtPadFriendLayer = CCRectMake(290, 300, 323, 290);

// BuyChip rect
static const Rect rtBuyChipLayer = CCRectMake(154, 30, 189, 254);
static const Rect rtPadBuyChipLayer = CCRectMake(308, 60, 378, 507);

//FindUser rect
static const Rect rtFindUserLayer = CCRectMake(154, 30, 189, 254);
static const Rect rtPadFindUserLayer = CCRectMake(308, 60, 378, 507);



Scene* WelcomeScene::createScene()
{
	// 'scene' is an autorelease object
	Scene* scene = NULL;
	do {

	scene = Scene::create();

	// 'layer' is an autorelease object
	auto layer = WelcomeScene::create();

	scene->addChild(layer);
	} while (0);
	return scene;
}

// on "init" you need to initialize your instance
bool WelcomeScene::init()
{
    //////////////////////////////
	do {
		if (!Layer::init())
		{
			return false;
		}
        
		drawImages();
		drawButtons();
		drawLabels();
	} while (0);
    return true;
}

void WelcomeScene::drawImages()
{
	Size size = Director::getInstance()->getWinSize();
	
	pSpriteBack = Sprite::create("image/iPhone/common/"+strBackground->_string);
    pSpriteBack->setScale(CGameSetting::getInstance()->g_scaleFactor);
	pSpriteBack->setPosition(Vec2(size.width * 0.5f, size.height * 0.5f ));
	this->addChild(pSpriteBack);

	Sprite * characterback = Sprite::create("image/iPhone/common/" + strCharacterBack->_string);
	Point ptChBack = getPointFrom3GRect(rtCharacterBack, size.height);
	characterback->setPosition(ptChBack.x , ptChBack.y );
	pSpriteBack->addChild(characterback);
	
}



void WelcomeScene::drawButtons() 
{
	Size size = Director::getInstance()->getWinSize();

	// Setting Button
	MenuItemImage* settingMenuItem = MenuItemImage::create("image/iPhone/eng/" + strSettingsBtn1->_string, "image/iPhone/eng/"+ strSettingsBtn2->_string);
	settingMenuItem->setCallback(std::bind(menu_selector(WelcomeScene::menuCallbackHandler), this, std::placeholders::_1));
	settingMenuItem->setPosition(Vec2(getPointFrom3GRect(rtSettingsBtn, size.height)));
	settingMenuItem->setTag(kMenuSetting);
	// Friends Button
	MenuItemImage* friendsMenuItem = MenuItemImage::create("image/iPhone/eng/" + strFriendsBtn1->_string, "image/iPhone/eng/" + strFriendsBtn2->_string);
	friendsMenuItem->setCallback(std::bind(menu_selector(WelcomeScene::menuCallbackHandler), this, std::placeholders::_1));
	friendsMenuItem->setPosition(Vec2(getPointFrom3GRect(rtFriendsBtn, size.height)));
	friendsMenuItem->setTag(kMenuFriend);
	// Buy Chips Button

	MenuItemImage* buyChipsItem = MenuItemImage::create("image/iPhone/eng/" + strBuyChipsBtn1->_string, "image/iPhone/eng/" + strBuyChipsBtn2->_string);
	buyChipsItem->setCallback(std::bind(menu_selector(WelcomeScene::menuCallbackHandler), this, std::placeholders::_1));
	buyChipsItem->setPosition(Vec2(getPointFrom3GRect(rtBuyChipsBtn, size.height)));
	buyChipsItem->setTag(kMenuBuyChips);
	// Lobby Button

	MenuItemImage* lobbyItem = MenuItemImage::create("image/iPhone/eng/" + strLobbyBtn1->_string, "image/iPhone/eng/" + strLobbyBtn2->_string);
	lobbyItem->setCallback(std::bind(menu_selector(WelcomeScene::menuCallbackHandler), this, std::placeholders::_1));
	lobbyItem->setPosition(Vec2(getPointFrom3GRect(rtLobbyBtn, size.height)));
	lobbyItem->setTag(kMenuLobby);
	// Play Button

	MenuItemImage* playItem = MenuItemImage::create("image/iPhone/eng/" + strPlayNowBtn1->_string, "image/iPhone/eng/" + strPlayNowBtn2->_string);
	playItem->setCallback(std::bind(menu_selector(WelcomeScene::menuCallbackHandler), this, std::placeholders::_1));
	playItem->setPosition(Vec2(getPointFrom3GRect(rtPlayNowBtn, size.height)));
	playItem->setTag(kMenuPlay);
	// Tutorial Button

	MenuItemImage* tutorialItem = MenuItemImage::create("image/iPhone/eng/" + strTutorialBtn1->_string, "image/iPhone/eng/" + strTutorialBtn2->_string);
	tutorialItem->setCallback(std::bind(menu_selector(WelcomeScene::menuCallbackHandler), this, std::placeholders::_1));
	tutorialItem->setPosition(Vec2(getPointFrom3GRect(rtTutorialBtn, size.height)));
	tutorialItem->setTag(kMenuTutorial);
	// Help Button

	MenuItemImage* helpItem = MenuItemImage::create("image/iPhone/eng/" + strHelpBtn1->_string, "image/iPhone/eng/" + strHelpBtn2->_string);
	helpItem->setCallback(std::bind(menu_selector(WelcomeScene::menuCallbackHandler), this, std::placeholders::_1));
	helpItem->setPosition(Vec2(getPointFrom3GRect(rtHelpBtn, size.height)));
	helpItem->setTag(kMenuHelp);
	// LogOut Button

	MenuItemImage* logoutItem = MenuItemImage::create("image/iPhone/eng/" + strLogOutBtn1->_string, "image/iPhone/eng/" + strLogOutBtn2->_string);
	logoutItem->setCallback(std::bind(menu_selector(WelcomeScene::menuCallbackHandler), this, std::placeholders::_1));
	logoutItem->setPosition(Vec2(getPointFrom3GRect(rtLogOutBtn, size.height)));
	logoutItem->setTag(kMenuLogOut);
	// Find User Button

	MenuItemImage* findUserItem = MenuItemImage::create("image/iPhone/eng/" + strFindUserBtn1->_string, "image/iPhone/eng/" + strFindUserBtn2->_string);
	findUserItem->setCallback(std::bind(menu_selector(WelcomeScene::menuCallbackHandler), this, std::placeholders::_1));
	findUserItem->setPosition(Vec2(getPointFrom3GRect(rtFindUserBtn, size.height)));
	findUserItem->setTag(kMenuFindUser);

	Vector<MenuItem*> items;
	items.pushBack(settingMenuItem);
	items.pushBack(friendsMenuItem);
	items.pushBack(buyChipsItem);
	items.pushBack(lobbyItem);
	items.pushBack(playItem);
	items.pushBack(tutorialItem);
	items.pushBack(helpItem);
	items.pushBack(logoutItem);
	items.pushBack(findUserItem);

	auto pMenu = Menu::createWithArray(items);
	pMenu->setPosition(Vec2::ZERO);
	this->addChild(pMenu);
}



void WelcomeScene::drawLabels()
{
	Size size = Director::getInstance()->getWinSize();

	// User Name Label
	m_pUserNameLabel = CCLabelTTF::create("", g_FontName->_string, 16, getRectFrom3GRect(rtUserNameLabel).size);
	m_pUserNameLabel->setPosition(Vec2(getPointFrom3GRect(rtUserNameLabel, size.height)));
	m_pUserNameLabel->setColor(ccc3(0,0,0));
	pSpriteBack->addChild(m_pUserNameLabel);

	// Title Label

	CCLabelTTF *m_pTilteLabel = CCLabelTTF::create("", g_FontName->_string, 16, getRectFrom3GRect(rtTilteLabel).size);
	m_pTilteLabel->setPosition(Vec2(getPointFrom3GRect(rtTilteLabel, size.height)));
	m_pTilteLabel->setColor(ccc3(0,0,0));
	pSpriteBack->addChild(m_pTilteLabel);

	m_pCurBalanceLabel = CCLabelTTF::create("", g_FontName->_string, 14, getRectFrom3GRect(rtCurBalanceLabel).size);
	m_pCurBalanceLabel->setPosition(Vec2(getPointFrom3GRect(rtCurBalanceLabel, size.height)));
	m_pCurBalanceLabel->setColor(ccc3(0,0,0));
	pSpriteBack->addChild(m_pCurBalanceLabel);


	CCLabelTTF* pRankingLabel = CCLabelTTF::create("", g_FontName->_string, 14, getRectFrom3GRect(rtRankingLabel).size);
	pRankingLabel->setPosition(Vec2(getPointFrom3GRect(rtRankingLabel, size.height)));
	pSpriteBack->addChild(pRankingLabel);
	m_pTilteLabel->setString(strTilte->_string);
}

void WelcomeScene::menuCallbackHandler(Ref * pSender)
{
	CallFunc * callFunc = NULL;
	int tag = ((MenuItem*)pSender)->getTag();
	switch (tag)
	{
		case kMenuPlay:
			MessageBox("Congrats on completing the game!", "Victory");
			break;
		case kMenuLogOut:
			CGameSetting::getInstance()->setSafeLogout(true);
			CGameSetting::getInstance()->saveGameSetting();
			App->changeSceneWithState(TGAME_LOGIN);
			break;
		case kMenuBuyChips:
			
			break;
		case kMenuFindUser:
			break;
		case kMenuFriend:
			break;
		case kMenuLobby:
			App->changeSceneWithState(TGAME_SELTABLE);
			break;
		case kMenuHelp:
			Application::getInstance()->openURL("http://www.vweeter.com");
			break;
		case kMenuTutorial:
			Application::getInstance()->openURL("http://www.vweeter.com");
			break;
		case kMenuSetting:
			CCNode *node = this->getChildByTag(kTagSettingLayer);
			if (node == NULL) 
				this->addChild(ViewSetting::create(), TOP_LAYER_ZORDER, kTagSettingLayer);
			else 
				this->removeChild(node,true);
			break;
	}

}

