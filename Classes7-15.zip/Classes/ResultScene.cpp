#include "ResultScene.h"
#include "SimpleAudioEngine.h"
#include "Global.h"
#include "ViewSetting.h"
USING_NS_CC;
using namespace CocosDenshion;

#define NAME_WIDTH	110

static const CCSize sizeLabel = CCSizeMake(140, 24);

static const CCRect rtInvitedLayer = CCRectMake(128, 85, 225, 149);
static const CCPoint ptTitleLabel = CCPointMake(240, 213);

static const CCPoint ptNameLabel = CCPointMake(230, 185);
static const CCPoint ptEarnLabel = CCPointMake(360, 185);
static const float fLblInterval = 25;

// button name
static CCString* strBKImageName = new CCString("pan_lobbyinvited.png");

//iPad Position
static const CCPoint ptPadBackground = CCPointMake(512, 396);
static const CCPoint ptPadTitleLabel = CCPointMake(512, 498);
static const CCPoint ptPadNameLabel = CCPointMake(480, 450);
static const CCPoint ptPadEarnLabel = CCPointMake(740, 450);
static const float fPadLblInterval = 50;



Scene* ResultScene::createScene()
{
	// 'scene' is an autorelease object
	Scene* scene = NULL;
	do {

	scene = Scene::create();

	// 'layer' is an autorelease object
	auto layer = ResultScene::create();

	scene->addChild(layer);
	} while (0);
	return scene;
}

// on "init" you need to initialize your instance
bool ResultScene::init()
{
    //////////////////////////////
	do {
		if (!Layer::init())
		{
			return false;
		}

		drawImages();
		drawLabels();
	} while (0);
    return true;
}

void ResultScene::drawImages()
{
	Size size = Director::getInstance()->getWinSize();
    
	pSpriteBack = Sprite::create("image/iPhone/common/"+ strBKImageName->_string);
	pSpriteBack->setPosition(getPointFrom3GRect(rtInvitedLayer));
	this->addChild(pSpriteBack);
}


void ResultScene::drawLabels()
{
	auto pTitleLabel = CCLabelTTF::create("RESULT", g_FontName->_string, 18);
	pTitleLabel->setPosition(ptTitleLabel);
	pTitleLabel->setColor(Color3B::BLACK);
	pSpriteBack->addChild(pTitleLabel);

	CCLabelTTF* pNameLabel[SEAT_COUNT];
	CCLabelTTF* pEarnLabel[SEAT_COUNT];


	for (int i = 0; i < SEAT_COUNT; i++) {
		pNameLabel[i] = CCLabelTTF::create("", g_FontName->_string, 14, getSizeFrom3GSize(sizeLabel));
		pNameLabel[i]->setColor(Color3B::BLACK);
		pSpriteBack->addChild(pNameLabel[i]);
		CCPoint pt = CCPointMake(ptNameLabel.x, ptNameLabel.y - fLblInterval * i);
		pNameLabel[i]->setPosition(pt);

		pEarnLabel[i] = CCLabelTTF::create("", g_FontName->_string, 14, getSizeFrom3GSize(sizeLabel));
		pEarnLabel[i]->setColor(Color3B::BLACK);
		pSpriteBack->addChild(pEarnLabel[i]);
		pt = CCPointMake(ptEarnLabel.x, ptEarnLabel.y - fLblInterval * i);
		pEarnLabel[i]->setPosition(pt);
	}
}
