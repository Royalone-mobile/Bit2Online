#ifndef __UIPLAYER_H__
#define __UIPLAYER_H__

#include "cocos2d.h"


using namespace cocos2d;
class UIPlayer;

class UICard : public cocos2d::Sprite
{
	UIPlayer* m_pParent;
	int m_nCardID;
	void initCardView(int nCardID, UIPlayer* pParent);
};
class UIPlayer : public cocos2d::Layer
{
public:
	UIPlayer(void) {};
	virtual ~UIPlayer(void) {};

    static cocos2d::Scene* createScene();

    virtual bool init();
	void initView(CCPoint ptViewPos, CCLayer *pParent, int nPos);
	void refreshView(CCPoint ptViewPos, CCLayer *pParent, int nPos);
	void chatBalloonAnimation(char *szChat);
	void drawRect();
	void setMainPlayer(bool bMainPlayer);
	bool isMainPlayer();
	void setPlayerInfo(int nPlayerID, int nCharID, const char * szURl, const char * szName);
	int getCharID();
	void setSeatState(int nstate);
	void setWinner(bool bWin);
	void createCharacter(int nCharID, const char *szUrl);
	void setCardCount(int nCardCount);
	int getPosInTable();
	void setPosInTable(int nPos);
	bool isImageLoaded();


private:	
	CCMenuItemImage*		m_pBackImage;
	CCSprite*		m_UICharacterBackground;
	CCSprite*		m_UICharacter;

	CCSprite*		m_UIActionImage;
	
	CCLabelTTF*		m_pNameLabel;
	CCLabelTTF*		m_pActionLabel;
	CCLabelTTF*		m_pCardsCountLable;

	CCSprite*		m_UIWinImage;

	CCLayer*		m_pParent;
	CCRect			m_rtChaRect;
	CCRect			m_rtMainWindow;
	CCPoint			m_ptPos;
	
	bool			m_bMainPlayer;
	
	int				m_nPlayerID;
	int				m_nCharID;

	int				m_nCardCount;
	
	int				m_nSeatState;
	
	CCLabelTTF*		m_pChatLabel;
	CCSprite*		m_pChatBalloon;
	
	CCMenuItemImage*		m_pSitBtn;
	int				m_nPosInTable;
	
	CCSprite*		m_pWaittingImage;
	
	bool			m_bImageLoaded;


	void menuCallbackHandler(Ref * pSender);

    // implement the "static create()" method manually
    CREATE_FUNC(UIPlayer);
};

#endif // __UIPLAYER_H__
