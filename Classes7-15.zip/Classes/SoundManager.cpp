#include "SoundManager.h"
#include "SimpleAudioEngine.h"
USING_NS_CC;
using namespace CocosDenshion;

SoundManager::~SoundManager()
{
	SimpleAudioEngine::getInstance()->unloadEffect(m_strSoundFileName);
}

void SoundManager::play()
{
	SimpleAudioEngine::getInstance()->playEffect(m_strSoundFileName);
}

void SoundManager::setVolume(float value)
{
	SimpleAudioEngine::getInstance()->setEffectsVolume(value);
}

void SoundManager::initWithResource(CCString *path)
{
	strcpy(m_strSoundFileName, path->getCString());
	SimpleAudioEngine::getInstance()->preloadEffect(m_strSoundFileName);
}