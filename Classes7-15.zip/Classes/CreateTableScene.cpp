#include "CreateTableScene.h"
#include "SimpleAudioEngine.h"
#include "Global.h"
#include "ViewSetting.h"
USING_NS_CC_EXT;


using namespace CocosDenshion;
using namespace network;

extern int nCurLang;


static const CCRect rtCreateTable = CCRectMake(149, 60, 301, 160);
static const CCRect rtBetDecBtn = CCRectMake(135, 86, 22, 26);
static const CCRect rtBetIncBtn = CCRectMake(243, 86, 22, 26);
static const CCRect rtCreateBtn = CCRectMake(66, 120, 68, 21);
static const CCRect rtCancelBtn = CCRectMake(166, 120, 68, 21);
static const CCRect rtTableNameText = CCRectMake(132, 61, 136, 18);
static const CCRect rtTableStakeText = CCRectMake(161, 89, 77, 18);

static CCString* strBKImageName = new CCString("pan_createtable.png");
static CCString* strArrowLeftNml = new CCString("arrow_left_0.png");
static CCString* strArrowLeftAct = new CCString("arrow_left_1.png");
static CCString* strArrowRightNml = new CCString("arrow_right_0.png");
static CCString* strArrowRightAct = new CCString("arrow_right_1.png");
static CCString* strCreateNml = new CCString("btn_createtable_00_e.png");
static CCString* strCreateAct = new CCString("btn_createtable_01_e.png");
static CCString* strCancelNml = new CCString("btn_cancel_0_e.png");
static CCString* strCancelAct = new CCString("btn_cancel_1_e.png");

//iPad Position616 315
static const CCPoint ptPadBackground = CCPointMake(518, 441);
static const CCPoint ptPadBetDecBtn = CCPointMake(510, 419);
static const CCPoint ptPadBetIncBtn = CCPointMake(666, 419);
static const CCPoint ptPadCreateBtn = CCPointMake(431, 366);
static const CCPoint ptPadCancelBtn = CCPointMake(593, 366);

static const CCRect rtPadTableNameText = CCRectMake(491, 299, 200, 26);
static const CCRect rtPadTablePlayerText = CCRectMake(540, 338, 96, 26);

static const CCPoint ptMinBetValueLbl = CCPointMake(348, 160);
static const CCPoint ptPadMinBetValueLbl = CCPointMake(584, 410);



Scene* CreateTableScene::createScene()
{
	// 'scene' is an autorelease object
	Scene* scene = NULL;
	do {

	scene = Scene::create();

	// 'layer' is an autorelease object
	auto layer = CreateTableScene::create();

	scene->addChild(layer);
	} while (0);
	return scene;
}

// on "init" you need to initialize your instance
bool CreateTableScene::init()
{
    //////////////////////////////
	do {
		if (!Layer::init())
		{
			return false;
		}

		m_fBetValue = 1;
		m_nMinBetIndex = 0;
		m_fBetValue = nMinBetValue[m_nMinBetIndex];
		drawImages();
		drawButtons();
		drawLabels();
		initTextFields();
	} while (0);
    return true;
}

void CreateTableScene::drawImages()
{
	Size size = Director::getInstance()->getWinSize();
	
    pSpriteBack = MenuItemImage::create("image/iPhone/common/" + strBKImageName->_string, "image/iPhone/common/" + strBKImageName->_string);
	pSpriteBack->setCallback(std::bind(menu_selector(CreateTableScene::menuCallbackHandler), this, std::placeholders::_1));
    pSpriteBack->setScale(CGameSetting::getInstance()->g_scaleFactor);
	pSpriteBack->setPosition(getPointFrom3GRect(rtCreateTable));
	this->addChild(pSpriteBack);
}


void CreateTableScene::initTextFields()
{
	CCRect rt = getRectWithBackFrom3GRect(rtTableNameText, rtCreateTable);
	textTableName = EditBox::create(CCSize(rt.size.width, rt.size.height), Scale9Sprite::create());
	textTableName->setPosition( CCSize(rt.origin.x, rt.origin.y));
	textTableName->setReturnType(ui::EditBox::KeyboardReturnType::DONE);
	textTableName->setMaxLength(20);
	textTableName->setFontSize(14);
	textTableName->setColor(Color3B::WHITE);
	textTableName->setInputMode(ui::EditBox::InputMode::ANY);
	textTableName->setPlaceHolder("aaaaaaaaaaa");
	textTableName->setMaxLength(MAX_TABLENAME_LEN);
	textTableName->setDelegate(this);//Open client
	textTableName->setFontColor(Color3B::BLACK);//Sets the text color
	pSpriteBack->addChild(textTableName);
}

void CreateTableScene::drawButtons()
{
	Size size = Director::getInstance()->getWinSize();

	
	MenuItemImage* pBetDecBtn = MenuItemImage::create("image/iPhone/common/" + strArrowLeftNml->_string, "image/iPhone/common/"+ strArrowLeftAct->_string);
	pBetDecBtn->setCallback(std::bind(menu_selector(CreateTableScene::menuCallbackHandler), this, std::placeholders::_1));
	pBetDecBtn->setPosition(getPointWithBackFrom3GRect(rtBetDecBtn, rtCreateTable));
	pBetDecBtn->setTag(kMenuBetDec);

	
	MenuItemImage* pBetIncBtn = MenuItemImage::create("image/iPhone/common/" + strArrowRightNml->_string, "image/iPhone/common/" + strArrowRightAct->_string);
	pBetIncBtn->setCallback(std::bind(menu_selector(CreateTableScene::menuCallbackHandler), this, std::placeholders::_1));
	pBetIncBtn->setPosition(getPointWithBackFrom3GRect(rtBetIncBtn, rtCreateTable));
	pBetIncBtn->setTag(kMenuBetInc);
	

	MenuItemImage* pCreateBtn = MenuItemImage::create("image/iPhone/eng/" + strCreateNml->_string, "image/iPhone/eng/" + strCreateAct->_string);
	pCreateBtn->setCallback(std::bind(menu_selector(CreateTableScene::menuCallbackHandler), this, std::placeholders::_1));
	pCreateBtn->setPosition(getPointWithBackFrom3GRect(rtCreateBtn, rtCreateTable));
	pCreateBtn->setTag(kMenuCreateTable);
	

	MenuItemImage* pCancelBtn = MenuItemImage::create("image/iPhone/eng/" + strCancelNml->_string, "image/iPhone/eng/" + strCancelAct->_string);
	pCancelBtn->setCallback(std::bind(menu_selector(CreateTableScene::menuCallbackHandler), this, std::placeholders::_1));
	pCancelBtn->setPosition(getPointWithBackFrom3GRect(rtCancelBtn, rtCreateTable));
	pCancelBtn->setTag(kMenuCancel);

	Vector<MenuItem*> items;
	items.pushBack(pBetDecBtn);
	items.pushBack(pBetIncBtn);
	items.pushBack(pCreateBtn);
	items.pushBack(pCancelBtn);


	auto pMenu = Menu::createWithArray(items);
	pMenu->setPosition(Vec2::ZERO);
	//pSpriteBack->addChild(pMenu);
	this->addChild(pMenu);
}


void CreateTableScene::drawLabels()
{
	Size size = Director::getInstance()->getWinSize();

	// User Name Label
	m_pMinBetValueLabel = CCLabelTTF::create("", g_FontName->_string, 12, getRectFrom3GRect(rtTableStakeText).size);
	m_pMinBetValueLabel->setPosition(ptMinBetValueLbl);
	m_pMinBetValueLabel->setColor(colorLabelText);
	m_pMinBetValueLabel->setString(getMoneyString(m_fBetValue)->_string);
	//pSpriteBack->addChild(m_pMinBetValueLabel);
	this->addChild(m_pMinBetValueLabel);
	
}

void CreateTableScene::menuCallbackHandler(Ref * pSender)
{
	CallFunc * callFunc = NULL;
	int tag = ((MenuItem*)pSender)->getTag();
	CCString * str = new CCString();
	switch (tag)
	{
		case kMenuBetDec:
			m_nMinBetIndex--;
			if (m_nMinBetIndex < 0) {
				m_nMinBetIndex = MIN_BET_COUNT - 1;
			}
			m_fBetValue = nMinBetValue[m_nMinBetIndex];
			m_pMinBetValueLabel->setString(getMoneyString(m_fBetValue)->_string);
			break;
		case kMenuBetInc:
			m_nMinBetIndex++;
			if (m_nMinBetIndex >= MIN_BET_COUNT) {
				m_nMinBetIndex = 0;
			}
			m_fBetValue = nMinBetValue[m_nMinBetIndex];
			str = getMoneyString(m_fBetValue);
			m_pMinBetValueLabel->setString(str->_string);

			break;
		case kMenuCreateTable:
			createTable();
			break;
		case kMenuCancel:
			this->removeFromParentAndCleanup(true);
			break;
	}

}


void CreateTableScene::editBoxEditingDidBegin(cocos2d::ui::EditBox* editBox)
{

}

void CreateTableScene::editBoxEditingDidEnd(cocos2d::ui::EditBox* editBox)
{

}

void CreateTableScene::editBoxTextChanged(cocos2d::ui::EditBox* editBox, const std::string& text)
{

}

void CreateTableScene::editBoxReturn(ui::EditBox* editBox)
{

}


void CreateTableScene::createTable()
{
	std::vector<std::string> headers;

	const char *strTableName = textTableName->getText();
	char temp[MAX_USERNAME_LEN];
	CGameSetting::getInstance()->getUserID(temp);

	CCString *strCreatorID = new CCString(temp);
	if (!strTableName || strlen(strTableName) == 0) {
		MessageBox("Please enter table name", "Notice");
		return;
	}
	//Creating a URL
	HttpRequest *request = new HttpRequest();
	request->setUrl(CREATE_GAME_URL);
	request->setRequestType(HttpRequest::Type::POST);


	m_fBetValue = nMinBetValue[m_nMinBetIndex];
	MessageBox(strCreatorID->getCString(), "");

	CCString *str = CCString::createWithFormat("gameName=%s&bettingMoney=%f&gameCreator=%s", strTableName, m_fBetValue, strCreatorID->getCString());


	const char* postData = str->getCString();

	MessageBox(postData, "");
	//const char* postData = "gameName=DOLDOLDOL&bettingMoney=1000&gameCreator=ANONYMOUS";
	CCLOG(postData);
	request->setRequestData(postData, strlen(postData));
	request->setResponseCallback(this, httpresponse_selector(CreateTableScene::onHttpRequestCompleted));
	
	request->setHeaders(headers);
	HttpClient::getInstance()->send(request);
	request->release();
}

void CreateTableScene::onHttpRequestCompleted(cocos2d::network::HttpClient *sender, cocos2d::network::HttpResponse *response)
{
	if (!response) {
		return;
	}

	if (0 != strlen(response->getHttpRequest()->getTag()))
	{
		CCLOG("%s completed", response->getHttpRequest()->getTag());
	}

	int statusCode = response->getResponseCode();
	char statusString[64] = {};
	sprintf(statusString, "HTTP Status Code: %d, tag = %s", statusCode, response->getHttpRequest()->getTag());
	CCLOG("response code: %d", statusCode);


	switch (statusCode) {
	case 409:
		MessageBox("Email already exists. Please try again", "Notice");
		break;
	case 422:
		MessageBox("Input Valid Email Address", "Notice");
		break;

	}
	// A connection failure
	if (!response->isSucceed())
	{
		CCLOG("response failed");
		CCLOG("error buffer: %s", response->getErrorBuffer());
		MessageBox("Failed in creating account", "Notice");
		return;
	}

	MessageBox("Succeed in creating account", "Notice");
	App->changeSceneWithState(TGAME_TABLE);
}
