#include "Util.h"
#include <stdlib.h>
#include "ByteBuffer.h"
#include "cocos2d.h"
#include <sys/stat.h>
using namespace cocos2d;

string byteToHexStr(unsigned char *byte_arr, int arr_len)
{
	string  hexstr;
	for (int i = 0; i < arr_len; i++) {
		char hex1;
		char hex2;
		int value = byte_arr[i];
		int v1 = value / 16;
		int v2 = value % 16;

		if (v1 >= 0 & v1 <= 9)
			hex1 = (char)(48 + v1);
		else
			hex1 = (char)(55 + v1);

		if (v2 >= 0 && v2 <= 9)
			hex2 = (char)(48 + v2);
		else
			hex2 = (char)(55 + v2);

		hexstr += hex1;
		hexstr += hex2;
	}

	return hexstr;

}

