#include "TimerCtrl.h"
#include "SimpleAudioEngine.h"
#include "Global.h"
#include "ViewSetting.h"
#include <time.h>
USING_NS_CC;
using namespace CocosDenshion;
using namespace std;
static const CCRect rtview = CCRectMake(100, 100, 72, 16);
static const CCRect rtClock = CCRectMake(0, 4, 7, 7);
static CCString* strFrontFileName = new CCString("clockicon.png");
static CCString* strRemainStickFileName = new CCString("timebar.png");
static CCString* strUsedStickFileName = new CCString("timebar_1.png");
static const int STICK_WIDTH = 3;
static const int STICK_INTERVAL = 1;

Scene* TimerCtrl::createScene()
{
	// 'scene' is an autorelease object
	Scene* scene = NULL;
	do {

	scene = Scene::create();

	// 'layer' is an autorelease object
	auto layer = TimerCtrl::create();

	scene->addChild(layer);
	} while (0);
	return scene;
}

// on "init" you need to initialize your instance
bool TimerCtrl::init()
{
    //////////////////////////////
	do {
		if (!Layer::init())
		{
			return false;
		}


	} while (0);
    return true;
}
void TimerCtrl::initTimerCtrl(TableScene *pView, float fTotalTime)
{
	m_rtMainWindow = rtview;
	m_rtMainWindow.size.width = m_rtMainWindow.size.height = 0;

	// Initialization code
	m_pParent = pView;
	m_fTotalTime = fTotalTime;
	m_fRemainTime = m_fTotalTime;

	m_pClockImage = Sprite::create("image/iPhone/common/" + strFrontFileName->_string);
	m_pClockImage->setPosition(getPointFrom3GRect(m_rtMainWindow + rtClock));
	this->addChild(m_pClockImage);

	CCRect rt;
	for (int i = 0; i < STICK_COUNT; i++) {
		rt = m_rtMainWindow + CCRectMake(
			(STICK_WIDTH + STICK_INTERVAL) * i + rtClock.size.width + 1,
			3,
			STICK_WIDTH,
			10
		);

		m_pRemainStickImage[i] = Sprite::create("image/iPhone/common/" + strRemainStickFileName->_string);
		this->addChild(m_pRemainStickImage[i]);
	
		m_pRemainStickImage[i]->setPosition(getPointFrom3GRect(rt));
		m_pRemainStickImage[i]->setVisible(false);
			
		m_pUsedStickImage[i] = Sprite::create("image/iPhone/common/" + strUsedStickFileName->_string);
		m_pUsedStickImage[i]->setPosition(getPointFrom3GRect(rt));
		m_pUsedStickImage[i]->setVisible(false);
	}

}

void TimerCtrl::drawSticks()
{
	for (int i = 0; i < STICK_COUNT; i++) {
		m_pRemainStickImage[i]->setVisible(false);
		m_pUsedStickImage[i]->setVisible(false);			
	}
	if (m_fRemainTime >= m_fTotalTime) {
		return;
	}
	int width = 0;
	int index = 0;
	while (width < rtview.size.width - 8) {
		if (index >= STICK_COUNT || index < 0)
				break;

		if (float(width) / (rtview.size.width - rtClock.size.width - 1) < m_fRemainTime / m_fTotalTime)
			m_pRemainStickImage[index]->setVisible(true);
		else
			m_pUsedStickImage[index]->setVisible(true);
		width += STICK_WIDTH + STICK_INTERVAL;
		index++;
	}
}

void TimerCtrl::onTimer(double cur_time)
{
	if(this->isVisible() == false)
		return;

	m_fRemainTime = m_fTotalTime - (cur_time - m_timeStart);
	CCLOG("startTime = %f, Current Time = %f, total time = %f", m_timeStart, cur_time, m_fTotalTime);

	if (m_fRemainTime < 0)
	{
		this->closeTimerCtrl();
	}
	else
		this->drawSticks();
		
}

void TimerCtrl::refreshTimerCtrl(TCASH fMaxTime, CCPoint pos)
{
	this->setVisible(true);
	if (getScaleFactor() == 1)
	{
		pos.y -= 5;
	}

	m_rtMainWindow.origin = pos;
	this->moveWindow(m_rtMainWindow);
	
	m_fTotalTime = fMaxTime;
	m_fRemainTime = m_fTotalTime;

	timeval curTime;
	gettimeofday(&curTime, NULL);

	m_timeStart = curTime.tv_usec / 1000.0f;

}


void TimerCtrl::closeTimerCtrl()
{
	this->setVisible(false);
}

void TimerCtrl::moveWindow(CCRect rt)
{
	m_rtMainWindow = rt;
	m_pClockImage->setPosition(getPointFrom3GRect(m_rtMainWindow + rtClock));

	CCRect temprt;
	for (int i = 0; i < STICK_COUNT; i++) {
		temprt = CCRectMake(
			(STICK_WIDTH + STICK_INTERVAL) * i + rtClock.size.width + 1,
			3,
			STICK_WIDTH,
			10
		);

		m_pRemainStickImage[i]->setPosition(getPointFrom3GRect(m_rtMainWindow + temprt));
		m_pUsedStickImage[i]->setPosition(getPointFrom3GRect(m_rtMainWindow + temprt));
	}
}
