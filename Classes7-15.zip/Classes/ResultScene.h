#ifndef __RESULT_SCENE_H__
#define __RESULT_SCENE_H__

#include "cocos2d.h"
#include "Global.h"
#include "AppDelegate.h"
using namespace cocos2d;
class ResultScene : public cocos2d::Layer

{
public:
	static cocos2d::Scene* createScene();
	virtual bool init();
	void menuCallbackHandler(Ref * pSender);
	void drawImages();
	void drawLabels();
	// implement the "static create()" method manually
	CREATE_FUNC(ResultScene);
private:
    CCSprite *pSpriteBack;
	double m_fStartTime;
	double m_fEndTime;
};

#endif // __RESULT_SCENE_H__
