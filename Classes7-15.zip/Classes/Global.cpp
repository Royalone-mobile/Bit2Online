
#include <string>
#include "Global.h"

using namespace std;
CGameSetting				g_GameSetting;
GE::GameTable	m_GameTable;
extern char m_UserPhoto[MAX_USERNAME_LEN];

CGameSetting* CGameSetting::_instance = nullptr;


Point getPointFrom3GRect(Rect rt3G, float fParentHeight)
{
	Size size = Director::getInstance()->getWinSize();

	Point retVal;

	if (fParentHeight == 0) {
		retVal = CCPointMake((rt3G.origin.x + rt3G.size.width / 2) / 480 * size.width, size.height - ((rt3G.origin.y + rt3G.size.height / 2) / 320 * size.height));
	}
	else {
		retVal = CCPointMake((rt3G.origin.x + rt3G.size.width / 2) / 480 * size.width, fParentHeight - ((rt3G.origin.y + rt3G.size.height / 2) / 320 * size.height));
	}

	return retVal;
}

CCRect getRectFrom3GRect(CCRect rt3G)
{
    Size size = Director::getInstance()->getWinSize();
	CCRect retVal = CCRectMake(rt3G.origin.x / 480 * size.width, rt3G.origin.y / 320 * size.height,
		rt3G.size.width / 480 * size.width, rt3G.size.height / 320 * size.height);
	return retVal;
}

CCPoint getPointWithBackFrom3GRect(CCRect rt3G, CCRect rt3GBack, float fParentHeight)
{
	CCSize size = Director::getInstance()->getWinSize();
    //CCSize size  = Director::getInstance()->getOpenGLView()->getVisibleSize();
	CCPoint retVal;
	if (fParentHeight == 0) {
		retVal = CCPointMake((rt3G.origin.x + rt3G.size.width / 2 + rt3GBack.origin.x) / 480 * size.width,
			size.height - ((rt3G.origin.y + rt3G.size.height / 2 + rt3GBack.origin.y) / 320 * size.height));
	}
	else {
		retVal = CCPointMake((rt3G.origin.x + rt3G.size.width / 2 + rt3GBack.origin.x) / 480 * size.width,
			fParentHeight - ((rt3G.origin.y + rt3G.size.height / 2 + rt3GBack.origin.y) / 320 * size.height));
	}

	return retVal;
}


CCPoint getCenterPoint(CCRect rt, float fParentHeight)
{
	CCSize size = Director::getInstance()->getWinSize();
    //CCSize size  = Director::getInstance()->getOpenGLView()->getVisibleSize();
	if (fParentHeight == 0) {
		fParentHeight = size.height;
	}
	return CCPointMake(rt.origin.x + rt.size.width / 2, fParentHeight - (rt.origin.y + rt.size.height / 2));
}

CCSize getSizeFrom3GSize(CCSize Size3G)
{
	CCSize size = Director::getInstance()->getWinSize();
	return CCSizeMake(Size3G.width / 480 * size.width, Size3G.height / 480 * size.height);
}

int getPosfromSeatID(int nSeatID)
{
	int myseat = NetLogic_GetSeatID();
		if (NetLogic_GetUserState() == stateTableSeat)
	if (myseat >= 0 && myseat < MAX_PLAYERS) {
		return (SEAT_COUNT + nSeatID - myseat) % SEAT_COUNT;
	}
	if (nSeatID == -1) {
		return 0;
	}
	return nSeatID;

	//return 0;

}
int getSeatIDfromPos(int nPos)
{
	if (NetLogic_GetSeatID() >= 0 && NetLogic_GetSeatID() < MAX_PLAYERS)
		return (nPos + NetLogic_GetSeatID() + SEAT_COUNT) % SEAT_COUNT;
	return nPos;
	//return 0;
}

CCRect getRectWithBackFrom3GRect(CCRect rt3G, CCRect rtBack3G)
{
	CCSize size = Director::getInstance()->getWinSize();
	CCRect retVal = CCRectMake(rt3G.origin.x + rtBack3G.origin.x, rt3G.origin.y + rtBack3G.origin.y, rt3G.size.width, rt3G.size.height);
	return CCRectMake(retVal.origin.x / 480 * size.width, retVal.origin.y / 320 * size.height, 
		retVal.size.width / 480 * size.width, retVal.size.height / 320 * size.height);
}


CCImage* getChUIImage(unsigned long nPlayerId, int nCharacterID, const char * szImageUrl, bool&bLoaded)
{
	CCImage* image = new CCImage();

	if (nCharacterID >= 0 && nCharacterID < 20) {
		CCString *filename = new CCString();
		filename->initWithFormat("image/iPhone/common/character/cha_%d.png", nCharacterID);
		image->initWithImageFile(filename->_string);
		bLoaded = true;
		return image;
	}
		/*
	Big2_ccAppDelegate* pAppDelegate = (Big2_ccAppDelegate*)[[UIApplication sharedApplication] delegate];
	if ((nCharacterID == PERSONAL_CH_ID) ||
		(nCharacterID == FACEBOOK_CH_ID)) {
		image = [pAppDelegate getImageWithUrl : szImageUrl];
		if (image != nil) {
			bLoaded = true;
			return image;
		}
	}*/

	bLoaded = false;
	CCString * filename= new CCString("defaulticon.png");
	image->initWithImageFile(filename->_string);
	return image;
}
CCSize sizeWithFont(const char *string, const char* fontName, float fontSize)
{
    CCLabelTTF *label = CCLabelTTF::create(string,fontName,fontSize);
    CCSize size = label->getBoundingBox().size;
    delete label;
    return size;
}


bool endsWith(const std::string& str, const std::string& suffix)
{
	return str.size() >= suffix.size() && !str.compare(str.size() - suffix.size(), suffix.size(), suffix);
}


CCRect operator+(const CCRect& param1, const CCRect& param2)
{
	CCRect ret = param1;
	ret.origin.x += param2.origin.x;
	ret.origin.y += param2.origin.y;
	ret.size.width += param2.size.width;
	ret.size.height += param2.size.height;
	return ret;
}


CCString* removeSuffixZero(CCString* str)
{
	int nLen = str->length();
	CCString* strRemovedZero;
	char chZero = '0';
	if (str->_string.at(nLen - 2) != chZero) {
		return str;
	}
	else if (str->_string.at(nLen - 2) == chZero && str->_string.at(nLen - 3) != chZero) {
		strRemovedZero = CCString::createWithFormat("%s%c", CCString::create(str->_string.substr(0,nLen-2))->getCString(), str->_string.at(nLen - 1));
	}
	else {
		strRemovedZero = CCString::createWithFormat("%s%c", CCString::create(str->_string.substr(0, nLen - 4))->getCString(), str->_string.at(nLen - 1));
	}
	return strRemovedZero;
}

CCString * insertComma(CCString * str) {
	int nLen = str->length() - 4;
	if (nLen <= 3) {
		return str;
	}

	int nPos = 0;
	CCString * commaStr = new CCString();
	CCString * temp = new CCString();
	if (nLen % 3 == 0) {
		commaStr = new CCString(str->_string.substr(0, 3));
		nPos = 3;
	}
	else {
		commaStr = new CCString(str->_string.substr(0, nLen % 3));
		nPos = (nLen % 3);
	}


	while (nPos < nLen) {
		temp = new CCString(str->_string.substr(0, 3));
		commaStr->append(",");
		commaStr->append(temp->_string);
		nPos += 3;
	}

	temp = new CCString(str->_string.substr(nPos, nLen - nPos + 4));
	commaStr->append(",");
	commaStr->append(temp->_string);

	return commaStr;
}



//bFlag true:from M  false from K
CCString* getMoneyString(TCASH fCash, bool bFlag)
{
	CCString *str = new CCString();
	bool bMinus = false;
	if (fCash < 0) {
		bMinus = true;
		fCash = -fCash;
	}

	//float temp = 0;

	if (fCash >= 1000000)
	{
		int64_t tmp = (int64_t)(fCash / 10000);
		fCash = tmp * 1.0f / 100;

		str = removeSuffixZero(insertComma(CCString::createWithFormat("%.2fM",fCash)));
	}
	if (fCash >= 1000 && str->isEqual(new CCString("")))
	{
		if (bFlag == false)
		{
			int64_t tmp = (int64_t)(fCash / 10);
			fCash = tmp * 1.0f / 100;
			str = removeSuffixZero(CCString::createWithFormat("%.2fK", fCash));
		}
		else {
			CCString* str1 = CCString::createWithFormat("%.0f", fCash);
			int nLen = str1->length();
			CCString* strSuf = new CCString(str1->_string.substr(nLen - 3, nLen-1));
			
			str1 = new CCString(str1->_string.substr(0, nLen - 3));
			str = CCString::createWithFormat("%s,%s", str1, strSuf);
		}
	}
	if (str->isEqual(new CCString(""))) {
		str = CCString::createWithFormat("%.0f", fCash);
	}
	if (bMinus) {
		CCString* str1 = new CCString("-$");
		str1->append(str->_string);
		return str;
	}
	
	return new CCString("$" + str->_string);
	//return CCString::createWithFormat("$%s", str);
}

CCSprite* getCharacterImage(unsigned long nPlayerId, int nCharacterID, const char * szImageUrl, bool& bLoaded)
{
	CCImage * image = getChUIImage(nPlayerId, nCharacterID, szImageUrl, bLoaded);

	CCString *str; 
	CCString *path = CCString::create(szImageUrl);
	CCSprite *character;
	
	
	transform(path->_string.begin(), path->_string.end(), path->_string.begin(), ::tolower);
	
	if (endsWith(path->_string, ".jpg") == true)
	{
		CCTexture2D * texture = CCTextureCache::getInstance()->addImage(image, "character");
		character = Sprite::createWithTexture(texture);
	}
	else
	{
		CCTexture2D * texture = CCTextureCache::getInstance()->addImage(image,"character");
		character = Sprite::createWithTexture(texture);
	}

	return character;
}


//implement CGameSetting
CGameSetting::CGameSetting()
{
	m_bRemember = false;
	m_szUserID[0] = NULL;
	m_szUserName[0] = NULL;
	m_szUserEmail[0] = NULL;
	m_dCash = 0.0f;
	m_szPassword[0] = NULL;
	m_bSafeLogout = true;
	m_bChatBlock = false;
	m_bFriendState = true;
	m_bVibration = true;
	m_bSound = true;
    m_bFirstLaunch = true;
}

bool CGameSetting::IsFirstLaunch()
{
    return m_bFirstLaunch;
}
void CGameSetting::setFirstLaunch(bool bFirstLaunch)
{
    m_bFirstLaunch = bFirstLaunch;
}

void CGameSetting::setSettings(bool bRemember,
	char *szUserID,
	char* szUserName,
	char *szUserEmail,
	char* szPassword,
	bool bSafeLogout,
	bool bChatBlock,
	bool bFriendState,
	bool bVibration,
	bool bSound)
{
	m_bRemember = bRemember;
	strcpy(m_szUserName, szUserName);
	strcpy(m_szUserEmail, szUserEmail);
	strcpy(m_szPassword, szPassword);
	strcpy(m_szUserID, szUserID);
	m_bSafeLogout = bSafeLogout;
	m_bChatBlock = bChatBlock;
	m_bFriendState = bFriendState;
	m_bVibration = bVibration;
	m_bSound = bSound;

}

CGameSetting::~CGameSetting()
{
}

bool CGameSetting::IsRemember()
{
	return m_bRemember;
}

void CGameSetting::setRemember(bool bRemember)
{
	m_bRemember = bRemember;
}

void CGameSetting::getUserID(char * szUserID)
{
	strcpy(szUserID, m_szUserID);
}

void CGameSetting::setUserID(char* szUserID)
{
	strcpy(m_szUserID, szUserID);
}

void CGameSetting::getUserName(char * szUserName)
{
	strcpy(szUserName, m_szUserName);
}

void CGameSetting::setUserName(char* szUserName)
{
	strcpy(m_szUserName, szUserName);
}

void CGameSetting::getUserEmail(char * szUserEmail)
{
	strcpy(szUserEmail, m_szUserEmail);
}

void CGameSetting::setUserEmail(char* szUserEmail)
{
	strcpy(m_szUserEmail, szUserEmail);
}

void CGameSetting::getPassword(char * szPassword)
{
	strcpy(szPassword, m_szPassword);
}

void CGameSetting::setPassword(char* szPassword)
{
	strcpy(m_szPassword, szPassword);
}

bool CGameSetting::IsSafeLogout()
{
	return m_bSafeLogout;
}
void CGameSetting::setSafeLogout(bool bSafeLogout)
{
	m_bSafeLogout = bSafeLogout;
}

bool CGameSetting::IsChatBlock()
{
	return m_bChatBlock;
}

void CGameSetting::setChatBlock(bool bChatBlock)
{
	m_bChatBlock = bChatBlock;
}

bool CGameSetting::IsFriendState()
{
	return m_bFriendState;
}

void CGameSetting::setFriendState(bool bFriendState)
{
	m_bFriendState = bFriendState;
}

bool CGameSetting::IsVibration()
{
	return m_bVibration;
}

void CGameSetting::setVibration(bool bVibration)
{
	m_bVibration = bVibration;
}

bool CGameSetting::IsSoundOn()
{
	return m_bSound;
}

void CGameSetting::setSound(bool bSound)
{
	m_bSound = bSound;
}

TCASH CGameSetting::getCash()
{
	return m_dCash;
}
void CGameSetting::setCash(TCASH dCash)
{
	m_dCash = dCash;
}

void CGameSetting::saveGameSetting()
{
	FILE* fp = fopen("big2_GameSetting.ini", "w+");
	if (fp == NULL)
		return;

	char szUserID[MAX_USERNAME_LEN];
	CGameSetting::getInstance()->getUserID(szUserID);
	int nUserIDLen = strlen(szUserID);

	char szUserName[MAX_USERNAME_LEN];
	CGameSetting::getInstance()->getUserName(szUserName);
	int nUserNameLen = strlen(szUserName);

	char szUserEmail[MAX_EMAILADDR_LEN];
	CGameSetting::getInstance()->getUserEmail(szUserEmail);
	int nUserEmailLen = strlen(szUserEmail);

	char szPassword[255];
	CGameSetting::getInstance()->getPassword(szPassword);
	int nPasswordLen = strlen(szPassword);

	bool bRemember = CGameSetting::getInstance()->IsRemember();
	bool bSafeLogout = CGameSetting::getInstance()->IsSafeLogout();
	bool bChatBlock = CGameSetting::getInstance()->IsChatBlock();
	bool bFriendState = CGameSetting::getInstance()->IsFriendState();
	bool bVibration = CGameSetting::getInstance()->IsVibration();
	bool bSound = CGameSetting::getInstance()->IsSoundOn();

	int nVersion = GAME_SETTING_VER;
	fwrite(&nVersion, sizeof(int), 1, fp);
	fwrite(&bRemember, sizeof(bool), 1, fp);

	fwrite(&nUserIDLen, sizeof(int), 1, fp);
	fwrite(szUserID, sizeof(char), nUserIDLen, fp);

	fwrite(&nUserNameLen, sizeof(int), 1, fp);
	fwrite(szUserName, sizeof(char), nUserNameLen, fp);

	fwrite(&nUserEmailLen, sizeof(int), 1, fp);
	fwrite(szUserEmail, sizeof(char), nUserEmailLen, fp);

	fwrite(&nPasswordLen, sizeof(int), 1, fp);
	fwrite(szPassword, sizeof(char), nPasswordLen, fp);
	fwrite(&bSafeLogout, sizeof(bool), 1, fp);
	fwrite(&bChatBlock, sizeof(bool), 1, fp);
	fwrite(&bFriendState, sizeof(bool), 1, fp);
	fwrite(&bVibration, sizeof(bool), 1, fp);
	fwrite(&bSound, sizeof(bool), 1, fp);
	fclose(fp);
}

void CGameSetting::loadGameSetting()
{
	FILE* fp = fopen("big2_GameSetting.ini", "r+");
		
	if (fp == NULL)
	{
		return;
	}
	bool bRemember, bSafeLogout, bChatBlock, bFriendState, bVibration, bSound;
	char szUserID[MAX_USERNAME_LEN] = { NULL, };
	char szUserName[MAX_USERNAME_LEN] = { NULL, };
	char szUserEmail[MAX_EMAILADDR_LEN] = { NULL, };
	char szPassword[/*MAX_USERPWD_LEN*/255] = { NULL, };
	int nUserIDLen, nUserNameLen, nUserEmailLen, nPasswordLen;
	int nVersion = 0;

	fread(&nVersion, sizeof(int), 1, fp);
	if (nVersion != GAME_SETTING_VER)
	{
		fclose(fp);
		return;
	}
	fread(&bRemember, sizeof(bool), 1, fp);
	fread(&nUserNameLen, sizeof(int), 1, fp);
	fread(szUserName, sizeof(char), nUserNameLen, fp);

	fread(&nUserIDLen, sizeof(int), 1, fp);
	fread(szUserID, sizeof(char), nUserIDLen, fp);

	fread(&nUserEmailLen, sizeof(int), 1, fp);
	fread(szUserEmail, sizeof(char), nUserEmailLen, fp);

	fread(&nPasswordLen, sizeof(int), 1, fp);
	fread(szPassword, sizeof(char), nPasswordLen, fp);
	fread(&bSafeLogout, sizeof(bool), 1, fp);
	fread(&bChatBlock, sizeof(bool), 1, fp);
	fread(&bFriendState, sizeof(bool), 1, fp);
	fread(&bVibration, sizeof(bool), 1, fp);
	fread(&bSound, sizeof(bool), 1, fp);

	bRemember != 0 ? bRemember = true : bRemember = false;
	bChatBlock != 0 ? bChatBlock = true : bChatBlock = false;
	bFriendState != 0 ? bFriendState = true : bFriendState = false;
	bVibration != 0 ? bVibration = true : bVibration = false;
	bSound != 0 ? bSound = true : bSound = false;
	setSettings(bRemember, szUserID, szUserName, szUserEmail, szPassword, bSafeLogout, bChatBlock, bFriendState, bVibration, bSound);
	fclose(fp);
}
//GameSetting class end

CGameSetting* CGameSetting::getInstance()
{
    if(_instance == nullptr)
        _instance = new CGameSetting();
    return _instance;
}

bool IsValidUserName(char *szUserName)
{
	int nUserNameLen = strlen(szUserName);
	if (nUserNameLen == 0) {
		return false;
	}

	for (int i = 0; i < nUserNameLen; i++) {
		if (!((szUserName[i] >= 'a' && szUserName[i] <= 'z')
			|| (szUserName[i] >= 'A' && szUserName[i] <= 'Z')
			|| (szUserName[i] >= '0' && szUserName[i] <= '9')
			|| szUserName[i] == '_' || szUserName[i] == '-'))
		{
			return false;
		}
	}
	return true;
}

bool IsValidEmailAddr(char * szEmailAddr)
{
	int nPos = 256;
	int nEmailLen = strlen(szEmailAddr);
	if (nEmailLen == 0) {
		return false;
	}
	for (int i = 0; i < nEmailLen; i++) {
		if (szEmailAddr[i] == '@') {
			if (i == 0 || i == nEmailLen - 1 || szEmailAddr[i + 1] == '.') {
				return false;
			}
			nPos = i;
		}
		if (szEmailAddr[i] == '.') {
			if (i < nPos || i == nEmailLen - 1) {
				return false;
			}
		}
	}
	if (nPos == 256) {
		return false;
	}
	return true;
}
