#ifndef MESSAGE_H
#define MESSAGE_H

#include "Util.h"
#include "cocos2d.h"

using namespace cocos2d;

// connection failed
static const unsigned int TYPE_SELF_DEINE_MESSAGE_CONNECT_FAIL = 0xfffffA01;
// connection terminate
static const unsigned int TYPE_SELF_DEINE_MESSAGE_CONNECT_TERMINATE = 0xfffffA02;
// server close connection
static const unsigned int TYPE_SELF_DEINE_MESSAGE_SERVER_CLOSE_CONNECTION = 0xfffffA03;
// cannot send message
static const unsigned int TYPE_SELF_DEINE_MESSAGE_CANNOT_SEND_MESSAGE = 0xfffffA04;
// idle timeout
static const unsigned int TYPE_SELF_DEINE_MESSAGE_IDLE_TIMEOUT = 0xfffffA05;
// reconnect hint
static const unsigned int TYPE_SELF_DEINE_MESSAGE_RECONNECT_HINT = 0xfffffA06;
// reconnect force
static const unsigned int TYPE_SELF_DEINE_MESSAGE_RECONNECT_FORCE = 0xfffffA07;
// error message
static const unsigned int TYPE_SELF_DEINE_MESSAGE_ERROR_MESSAGE = 0xfffffA08;
// client kill message
static const unsigned int TYPE_SELF_DEINE_MESSAGE_CLIENT_KILL_MESSAGE = 0xfffffA09;

class Message : public Ref
{
public:
    char HEAD0;
    char HEAD1;
    char HEAD2;
    char HEAD3;
    
    byte serverVersion[4];
    byte length[4];
    byte commandId[4];

    static const int MAX_LENGTH = 512;

    char data[MAX_LENGTH];
	
	Message();
	~Message();

	int datalength();

	static Message * create();
};

#endif

