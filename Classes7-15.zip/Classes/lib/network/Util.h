#ifndef _UTIL_H_
#define _UTIL_H_
#include "cocos2d.h"

#include <vector>
#include <string>
#include <cmath>
//algorithm头文件包含make_heap,pop_heap等堆操作（android）by hubin.
#include <algorithm>
//增加sleep方法的头文件，不然android版本着不到对应的函数，iphone的是默认找的苹果系统里的同样方法 by hubin
#include <unistd.h>
#include "pthread.h"

typedef signed char byte;
typedef bool boolean;
class ByteBuffer;

using namespace std;

#define  Float_MAX_VALUE  3.4028235E+38F
#define  Float_MIN_VALUE  1.4E-45F;

extern string byteToHexStr(unsigned char *byte_arr, int arr_len);

#define SAFE_DELETE_ELEMENT( ptr ) if (ptr != NULL) { delete ptr; ptr = NULL; }
#define SAFE_DELETE_ARRAY( ptr )if (ptr != NULL){ delete[] ptr;ptr = NULL; }

template<typename _RandomAccessIterator>
inline void safe_delete_vector(_RandomAccessIterator __first, _RandomAccessIterator __last)
{
	for (_RandomAccessIterator it = __first;it!= __last ; ++it) {
		if ((*it) != NULL) {
			delete *it;
			*it = NULL;
		}
	}
}	

template <class Class, typename TT>
inline bool instanceof(TT const &object)
{
    return dynamic_cast<Class const *>(&object);
}

class MyLock
{
	pthread_mutex_t* mutex_t;
public:
	MyLock(pthread_mutex_t* _mutex_t);
	~MyLock();
};

std::string createRandString(int len, boolean filter);

#endif
