/*
 *  message.cpp
 *
 *  Created by HELEN on 15-1-1.
 *  Copyright 2015 JDRX. All rights reserved.
 *
 */

#include "message.h"
#include "SocketClient.h"

Message::Message()
{
	memset(data, 0x00, sizeof(char) * Message::MAX_LENGTH);

	HEAD0 = 'H';
	HEAD1 = 'E';
	HEAD2 = 'A';
	HEAD3 = 'D';

    int a = 1;
    serverVersion[3] = (byte)(0xff&a);
    serverVersion[2] = (byte)((0xff00&a) >> 8);
    serverVersion[1] = (byte)((0xff0000&a) >> 16);
    serverVersion[0] = (byte)((0xff000000&a) >> 24);
}

Message::~Message()
{
}

int Message::datalength()
{
    return SocketClient::bytesToInt(length) + 12;
}

Message * Message::create()
{
	Message *ret = new (std::nothrow) Message();
    if (ret) {
        ret->autorelease();
        return ret;
    }
    else {
        CC_SAFE_DELETE(ret);
        return nullptr;
    }
}
