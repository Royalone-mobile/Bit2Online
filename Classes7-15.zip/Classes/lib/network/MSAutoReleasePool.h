/*
 *  MSAutoReleasePool.h
 *
 *  Created by HELEN on 15-1-1.
 *  Copyright 2015 JDRX. All rights reserved.
 *
 */

#ifndef _MS_AUTO_RELEASE_POOL_H_
#define _MS_AUTO_RELEASE_POOL_H_

//class NSAutoreleasePool;

class MSAutoReleasePool
{
private:
	void * pool;

public:
	MSAutoReleasePool();
	~MSAutoReleasePool();
};

#endif
