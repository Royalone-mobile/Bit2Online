
#include "Global.h"
#include "UIBlindBar.h"
#include "SelTableScene.h"

USING_NS_CC;

extern TStakeList	m_fTableStakeList;
extern TTableList   m_TableList;
extern TID			nCurTableID;
extern int			nArrangeOption;
extern bool			bArrangeAscending;
//extern TCASH		fSelTableCash; //rmj20101201
extern int			nViewOption;

#define BLINDBAR_LEFT		128
#define BLINDBAR_TOP		289
#define BLINDBAR_WIDTH		212
#define BLINDBAR_HEIGHT		16
#define LABEL_WIDTH			71
#define LABEL_WIDTH_PAD	140


Scene* UIBlindBar::createScene()
{
	// 'scene' is an autorelease object
	Scene* scene = NULL;
	do {

	scene = Scene::create();

	// 'layer' is an autorelease object
	auto layer = UIBlindBar::create();

	scene->addChild(layer);
	} while (0);
	return scene;
}

// on "init" you need to initialize your instance
bool UIBlindBar::init()
{
    //////////////////////////////
	do {
		if (!Layer::init())
		{
			return false;
		}

	} while (0);
    return true;
}

void UIBlindBar::initBlindBar(SelTableScene* pView)
{
	m_pParent = pView;
	m_nCurDispIndex = 0;
	m_bEnable = true;

	CCRect rtBlindLbl[3] = { CCRectMake(128, 295, 71, 10),
		CCRectMake(199, 295, 71, 10),
		CCRectMake(270, 295, 71, 10) };
	CCPoint ptPadBlindLbl[3] = { CCPointMake(332, 33),
		CCPointMake(472, 33),
		CCPointMake(612, 33) };
	for (int i = 0; i < 3; i++) {
		m_pBlindLabel[i] = CCLabelTTF::create("sddd", "Arial", 11, getRectFrom3GRect(rtBlindLbl[i]).size);
		m_pParent->addChild(m_pBlindLabel[i], 1);
		m_pBlindLabel[i]->setPosition(getPointFrom3GRect(rtBlindLbl[i]));
	}
	this->displayStake();
}
void UIBlindBar::displayStake()
{
	int nCount = m_fTableStakeList.size();

	switch (nCount) {
	case 0:
		
		break;
	case 1:
		m_pBlindLabel[1]->setString(getMoneyString(m_fTableStakeList[m_nCurDispIndex])->_string);
		break;
	case 2:
	{
		if (m_nCurDispIndex == 0) {
			m_pBlindLabel[1]->setString(getMoneyString(m_fTableStakeList[m_nCurDispIndex])->_string);
			m_pBlindLabel[2]->setString(getMoneyString(m_fTableStakeList[m_nCurDispIndex + 1])->_string);
		}
		else {
			m_pBlindLabel[1]->setString(getMoneyString(m_fTableStakeList[m_nCurDispIndex])->_string);
			m_pBlindLabel[0]->setString(getMoneyString(m_fTableStakeList[m_nCurDispIndex - 1])->_string);
		}
	}
	break;
	default:
	{
		m_pBlindLabel[1]->setString(getMoneyString(m_fTableStakeList[m_nCurDispIndex])->_string);
		int ntemp = m_nCurDispIndex + 1;
		if (ntemp == nCount) {
			ntemp = 0;
		}
		m_pBlindLabel[2]->setString(getMoneyString(m_fTableStakeList[ntemp])->_string);
		ntemp = m_nCurDispIndex - 1;
		if (ntemp == -1) {
			ntemp = nCount - 1;
		}
		m_pBlindLabel[0]->setString(getMoneyString(m_fTableStakeList[ntemp])->_string);
	}
	break;
	}
}
void UIBlindBar::setStake(TCASH fStake)
{
	for (unsigned int i = 0; i < m_fTableStakeList.size(); i++)
		if (m_fTableStakeList[i] == fStake) {
			m_nCurDispIndex = i;
			break;
		}
	this->displayStake();
}
void UIBlindBar::setAnimation(bool bLeft)
{
		float aniDuration = 0.3f;
		float aniWidth = 0;
		if (getScaleFactor() == 1) {
			aniWidth = LABEL_WIDTH / 2;
		}
		else {
			aniWidth = LABEL_WIDTH_PAD / 2;
		}

		CCRect rtBlindLbl[3] = { CCRectMake(128, 295, 71, 10),
			CCRectMake(199, 295, 71, 10),
			CCRectMake(270, 295, 71, 10) };
		CCPoint ptPadBlindLbl[3] = { CCPointMake(332, 33),
			CCPointMake(472, 33),
			CCPointMake(612, 33) };
		for (int i = 0; i < 3; i++) {
			CCPoint ptLabel;
			if (getScaleFactor() == 1) {
				ptLabel = getPointFrom3GRect(rtBlindLbl[i]);
			}
			else {
				ptLabel = ptPadBlindLbl[i];
			}

		CCMoveTo * action1, *action3;

		if (bLeft) {
			action1 = CCMoveTo::create(aniDuration, CCPointMake(ptLabel.x - aniWidth, ptLabel.y));
			action3 = CCMoveTo::create(0, CCPointMake(ptLabel.x + aniWidth, ptLabel.y));
		}
		else {
			action1 = CCMoveTo::create(aniDuration, CCPointMake(ptLabel.x + aniWidth, ptLabel.y));
			action3 = CCMoveTo::create(0, CCPointMake(ptLabel.x - aniWidth, ptLabel.y));
		}

		auto action2 = CCFadeOut::create(aniDuration);
		auto action4 = CCMoveTo::create(aniDuration, ptLabel);
		auto action5 = CCFadeIn::create(aniDuration);
			
		auto actionleft = CCSpawn::create(action1, action2);
		auto actionright = CCSpawn::create(action4, action5);
		auto action = CCSequence::create(actionleft, action3, actionright);

		m_pBlindLabel[i]->runAction(action);
		
	}
}
void UIBlindBar::enableBlindBar(bool bEnable)
{
	m_bEnable = bEnable;
	if (m_bEnable) {
		for (int i = 0; i < 3; i++) {
			m_pBlindLabel[i]->setVisible(true);
		}
	}
	else {
		for (int i = 0; i < 3; i++) {
			m_pBlindLabel[i]->setVisible(false);
		}
	}
}

void UIBlindBar::menuCallbackHandler(Ref * pSender)
{

}
