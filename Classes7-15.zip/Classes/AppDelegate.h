#ifndef  _APP_DELEGATE_H_
#define  _APP_DELEGATE_H_

#include "cocos2d.h"
#include "Global.h"
#include "SoundManager.h"

/**
@brief    The cocos2d Application.

Private inheritance here hides part of interface from Director.
*/
class  AppDelegate : private cocos2d::Application
{
static AppDelegate *s_instance;
public:
    AppDelegate();
    virtual ~AppDelegate();
	inline static AppDelegate *getInstance() { return s_instance; }
    virtual void initGLContextAttrs();
	bool changeSceneWithState(int nState);
	cocos2d::CCLayer* m_pCurScene;


	void initGame();
	bool initSound();
	void playSE(int nIndex);
	void releaseSound();

	SoundManager *snd_logon;
	SoundManager *snd_lose;
	SoundManager *snd_win;
	SoundManager *snd_card_pass;
	SoundManager *snd_card_ok;


    /**
    @brief    Implement Director and Scene init code here.
    @return true    Initialize success, app continue.
    @return false   Initialize failed, app terminate.
    */
    virtual bool applicationDidFinishLaunching();

    /**
    @brief  Called when the application moves to the background
    @param  the pointer of the application
    */
    virtual void applicationDidEnterBackground();

    /**
    @brief  Called when the application reenters the foreground
    @param  the pointer of the application
    */
    virtual void applicationWillEnterForeground();

};


#define App	(AppDelegate::getInstance())
#endif // _APP_DELEGATE_H_

