#ifndef __CREATE_TABLE_SCENE_H__
#define __CREATE_TABLE_SCENE_H__

#include "cocos2d.h"
#include "Global.h"
#include "AppDelegate.h"
#include "network/HttpClient.h"
#include "cocos-ext.h"

using namespace cocos2d;
class CreateTableScene : public cocos2d::Layer, public cocos2d::ui::EditBoxDelegate

{
public:
    static cocos2d::Scene* createScene();

    virtual bool init();
   
	MenuItemImage * pSpriteBack;

	TCASH					m_fBetValue;
	int						m_nLimitPlayerCount;
	int						m_nMinBetIndex;
	CCLabelTTF *m_pMinBetValueLabel;

	void menuCallbackHandler(Ref * pSender);

	void drawImages();
	void drawButtons();
	void drawLabels();
	void initTextFields();

	void createTable();
    // implement the "static create()" method manually
    CREATE_FUNC(CreateTableScene);
private:
	ui::EditBox*            textTableName;
	void onHttpRequestCompleted(cocos2d::network::HttpClient *sender, cocos2d::network::HttpResponse *response);

	virtual void editBoxEditingDidBegin(cocos2d::ui::EditBox* editBox)override;
	virtual void editBoxEditingDidEnd(cocos2d::ui::EditBox* editBox)override;
	virtual void editBoxTextChanged(cocos2d::ui::EditBox* editBox, const std::string& text)override;
	virtual void editBoxReturn(cocos2d::ui::EditBox* editBox)override;
};

#endif // __CREATE_TABLE_SCENE_H__
