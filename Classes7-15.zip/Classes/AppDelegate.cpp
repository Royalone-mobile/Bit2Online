#include "AppDelegate.h"
#include "MainMenuScene.h"
#include "WelcomeScene.h"
#include "SelTableScene.h"
#include "AccountScene.h"
#include "RankingLayer.h"
#include "TableScene.h"

//#define USE_AUDIO_ENGINE 1
 //#define USE_SIMPLE_AUDIO_ENGINE 1

#if USE_AUDIO_ENGINE && USE_SIMPLE_AUDIO_ENGINE
#error "Don't use AudioEngine and SimpleAudioEngine at the same time. Please just select one in your game!"
#endif

#if USE_AUDIO_ENGINE
#include "audio/include/AudioEngine.h"
using namespace cocos2d::experimental;
#elif USE_SIMPLE_AUDIO_ENGINE
#include "audio/include/SimpleAudioEngine.h"
using namespace CocosDenshion;
#endif

USING_NS_CC;





static cocos2d::Size designResolutionSize = cocos2d::Size(480, 320);
static cocos2d::Size smallResolutionSize = cocos2d::Size(480, 320);
static cocos2d::Size mediumResolutionSize = cocos2d::Size(1024, 768);
static cocos2d::Size largeResolutionSize = cocos2d::Size(2048, 1536);


AppDelegate * AppDelegate::s_instance;


AppDelegate::AppDelegate()
{
	s_instance = this;
}


bool AppDelegate::initSound()
{
	snd_logon = new SoundManager();
	snd_logon->initWithResource(new CCString("sound/logon.wav"));

	snd_win = new SoundManager();
	snd_win->initWithResource(new CCString("sound/win.wav"));

	snd_lose =new SoundManager();
	snd_lose->initWithResource(new CCString("sound/lose.wav"));

	snd_card_pass = new SoundManager();
	snd_card_pass->initWithResource(new CCString("sound/pass.wav"));

	snd_card_ok = new SoundManager();
	snd_card_ok->initWithResource(new CCString("sound/play_choose_card.wav"));

	return true;
}


void AppDelegate::releaseSound()
{
	if (snd_logon)
		delete snd_logon;
	//snd_win->release();
	//snd_lose->release();
	//snd_card_pass->release();
	//snd_card_ok->release();
}

void AppDelegate::playSE(int nIndex)
{	
	
	if (CGameSetting::getInstance()->IsSoundOn())
		return;

	switch (nIndex) {
		case soundLogon: snd_logon->play(); break;
		case soundWin: snd_win->play(); break;
		case soundLose: snd_lose->play(); break;
		case soundCardOk: snd_card_ok->play(); break;
		case soundCardPass: snd_card_pass->play(); break;
	}
}

bool AppDelegate::changeSceneWithState(int nState)
{
	auto director = Director::getInstance();
	switch (nState)
	{
		case TGAME_LOGIN:
		{
			CCScene *scene = MainMenuScene::createScene();
			m_pCurScene = (CCLayer*)scene->getChildren().at(0);
			if (director->getRunningScene() == NULL) {
				director->runWithScene(scene);
			}
			else {
				director->replaceScene(scene);
			}
		}
		break;
		case TGAME_WELCOME:
		{
			CCScene *scene = WelcomeScene::createScene();
			m_pCurScene = (CCLayer*)scene->getChildren().at(0);
			director->replaceScene(scene);
		}
		break;
		case TGAME_SELTABLE:
		{
			CCScene *scene = SelTableScene::createScene();
			m_pCurScene = (CCLayer*)scene->getChildren().at(0);
			director->replaceScene(scene);
		}
		break;
		case TGAME_TABLE:
		{
			CCScene *scene = TableScene::createScene();
			m_pCurScene = (CCLayer*)scene->getChildren().at(0);
			director->replaceScene(scene);
		}
		break;
		case TGAME_ACCOUNT:
		{
			CCScene *scene = AccountScene::createScene();
			m_pCurScene = (CCLayer*)scene->getChildren().at(0);
			director->replaceScene(scene);
		}
		break;
		default:
			break;
	}
	return true;
}


AppDelegate::~AppDelegate() 
{
#if USE_AUDIO_ENGINE
    AudioEngine::end();
#elif USE_SIMPLE_AUDIO_ENGINE
    SimpleAudioEngine::end();
#endif
	CCDirector::getInstance()->release();
	this->releaseSound();

}



// if you want a different context, modify the value of glContextAttrs
// it will affect all platforms
void AppDelegate::initGLContextAttrs()
{
    // set OpenGL context attributes: red,green,blue,alpha,depth,stencil
    GLContextAttrs glContextAttrs = {8, 8, 8, 8, 24, 8};

    GLView::setGLContextAttrs(glContextAttrs);
}

// if you want to use the package manager to install more packages,  
// don't modify or remove this function
static int register_all_packages()
{
    return 0; //flag for packages manager
}

bool AppDelegate::applicationDidFinishLaunching() {
    // initialize director
    auto director = Director::getInstance();
    auto glview = director->getOpenGLView();
    if(!glview) {
#if (CC_TARGET_PLATFORM == CC_PLATFORM_WIN32)
        //glview = GLViewImpl::createWithRect("Big2Online", cocos2d::Rect(0, 0, designResolutionSize.width, designResolutionSize.height);
        glview = GLViewImpl::create("Big2Online");
		//glview->setFrameSize(1024, 768);
#else
        //glview = GLViewImpl::create("Big2Online");
#endif
        
        director->setOpenGLView(glview);
    }

    // turn on display FPS
   // director->setDisplayStats(true);

    // set FPS. the default value is 1.0/60 if you don't call this
    director->setAnimationInterval(1.0f / 60);
    
    // Set the design resolution
    glview->setDesignResolutionSize(designResolutionSize.width, designResolutionSize.height, ResolutionPolicy::NO_BORDER);
    auto frameSize = glview->getFrameSize();
    
    
    float g_scaleFactor = 1.0f;
    float heightRate = frameSize.height / designResolutionSize.height;
    float widthRate = frameSize.width / designResolutionSize.width;
    
    if(widthRate < heightRate)
        g_scaleFactor = widthRate / heightRate;
    else
        g_scaleFactor = heightRate / widthRate;
    
    CGameSetting::getInstance()->g_scaleFactor = g_scaleFactor;
    
	//director->setContentScaleFactor(1);

	const char* cocosVersion = cocos2dVersion();
	printf(cocosVersion);

	
    register_all_packages();

	initGame();
    // create a scene. it's an autorelease object
    //auto scene = TableScene::createScene();

	auto scene = MainMenuScene::createScene();
	//auto scene = WelcomeScene::createScene();
    // run
    director->runWithScene(scene);
	
    return true;
}

void AppDelegate::initGame()
{
	CGameSetting::getInstance()->loadGameSetting();
	CCDirector *director = CCDirector::getInstance();
	director->setAnimationInterval(1.0 / 60);
	this->initSound();
}
// This function will be called when the app is inactive. Note, when receiving a phone call it is invoked.
void AppDelegate::applicationDidEnterBackground() {
    Director::getInstance()->stopAnimation();

#if USE_AUDIO_ENGINE
    AudioEngine::pauseAll();
#elif USE_SIMPLE_AUDIO_ENGINE
    SimpleAudioEngine::getInstance()->pauseBackgroundMusic();
    SimpleAudioEngine::getInstance()->pauseAllEffects();
#endif
}

// this function will be called when the app is active again
void AppDelegate::applicationWillEnterForeground() {
    Director::getInstance()->startAnimation();

#if USE_AUDIO_ENGINE
    AudioEngine::resumeAll();
#elif USE_SIMPLE_AUDIO_ENGINE
    SimpleAudioEngine::getInstance()->resumeBackgroundMusic();
    SimpleAudioEngine::getInstance()->resumeAllEffects();
#endif
}


