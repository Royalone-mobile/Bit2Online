
#include "Common.h"
#include <memory.h>
#include <cstring>

int nScaleFactor = 1;

int getScaleFactor() 
{
	return nScaleFactor;
}

void setScaleFactor(int nScale)
{
	nScaleFactor = nScale;
}

uint64 doubleTouint64(double fValue)
{
	uint64 nValue;
	memcpy(&nValue, &fValue, 8);
	return nValue;
}

double uint64Todouble(uint64 nValue)
{
	double fValue;
	memcpy(&fValue, &nValue, 8);
	return fValue;
}

