//
//  Common.h
//  Big2
//
//

#ifndef _COMMON_H
#define _COMMON_H

#include "NetCommon.h"

#define IPHONE_WIDTH	480
#define IPHONE_HEIGHT	320

#define IPAD_WIDTH		1024
#define IPAD_HEIGHT		768

#define MAX_GROUP_COUNT 10

#define MAX_NAME_LETTERS	32
#define MAX_USERPWD_LEN		16
#define MAX_SERVERADDR_LEN	32
#define MAX_EMAILADDR_LEN	256
#define MAX_FRIENDNAME_LEN	128
#define MAX_FRIENDID_LEN	128
#define MAX_FRIENDPHOTO_LEN	256
#define MAX_CHIPNAME_LEN	256
#define MAX_CHIPPHOTO_LEN	256

#define MAX_CHIPKIND_COUNT	6

#define MAX_PLAYERS			4

#define MAX_CHIPKIND_COUNT	6

#define MAX_CHA_IMAGE_COUNT	10

#define MIN_BET_COUNT	10

#define deallocCtrl(pCtrl) \
if (pCtrl) {\
[pCtrl removeFromSuperview];\
[pCtrl release];\
pCtrl = nil;\
}

#define createSpriteWithTexture(pointer, texture, objName, rect) \
pointer = CCSprite::createWithTexture(texture); \
rect = g_TextureManager.getTextureRect(objName); \
pointer.setTextureRect(rect);


#define MAKECOLOR(R,G,B,A) [UIColor colorWithRed:float(R) / 256.0f green:float(G) / 256.0f blue:float(B) / 256.0f alpha:float(A) / 256.0f]


typedef	unsigned int			uint32;

uint64 doubleTouint64(double fValue);
double uint64Todouble(uint64 nValue);

int getScaleFactor();
void setScaleFactor(int nScale);

enum TGameState {
	TGAME_NONE,
	TGAME_LOGIN = 30,
	TGAME_WELCOME,
	TGAME_SELTABLE,
	TGAME_TABLE,
	TGAME_ACCOUNT,
	TGAME_GROUP,
};



enum TNotifyRecv {
	notifySysError,

	notifyLoginOK = 1000,
	notifyLoginFailed,
	notifyDisconnect,

	notifyCreateAccountOK,
	notifyCreateAccountFailed,

	notifyForgetPasswordOK,
	notifyForgetPasswordFailed,

	notifyTableListChanged,				//wParam = bCurSelTable		lParam = bTableCountChanged
	notifyTableRemoved,					//wParam = bCurSelTable
	notifyEnterTable,					//wParam = preState
	notifyLeaveTable,					//wParam = SeatID

	notifyTableInfoArrived,
	notifyInvited,
	notifyInvalidTableID,				//wParam = ErrorCode

	notifyFindUser,					//wParam = tableID

	notifyCreateTableOK,
	notifyCreateTableFailed,

	notifyJoinFailed,
	notifyJoinOK,

	notifyViewFailed,
	notifyViewOK,

	notifyObservserListChanged,

	notifyLobbyUsersArrived,
	notifyAcceptInvite,
	notifyRejectInvite,
	notifyFailedInvite,

	notifyStartGame,
	notifyDeal,
	notifyFinishGame,					//wParam = nWinnerID, lParam = fMoney
	notifyKickout,						//wParam = kickedName, lParam = no money ? 0 : 1
	notifyChat,							//wParam = From string buffer pointer, lParam = Chatting string buffer pointer

	notifySitTable,						//wParam = SeatID, lParam = nPlayerID

	notifyReady,						//wparam = PlayerID lParam = bIsReady
	notifyGoButton,						//wparam = 0:Disable, 1:Enable

	notifyActionPlayed,					//wParam = PlayerID lParam = nAction
	notifyCashChanged,
	notifyBuyChipOK,
	notifyBuyChipFailed,
	notifyFBLoginOK,
	notifyFriendList,
	notifyFriendUpdate,					//wParam = FriendName lParam = bOnline
	notifyFriendChange,					//wParam = old name		lParam = new name


	notifyFriendImageArrived,			//wParam = FriendDBID lParam = bSuccess
	notifyUserImageArrived,

	notifyPlayerInfoArrived,			//wParam = playerDBID lParam = PlayerInfo
	notifyAskPlayerInfoFailed,				//[d:PlayerID][d:errorCode]:
	notifyRegisterFriend,				//wParam = playerDBID lParam = bAccept
	notifyRegisterFriendFailed,			//wParam = playerDBID lParam = error_code

	notifyRequestFriend,				//wParma = szPlayerName  lParam = PlayerID


	notifyError,
	notifyMessage,
	notifyWaiting,						//wParam = waitingID
	notifyRanking,
	notifyReceivedChips,				//wParam = friendName lParam = cash
	notifySendChipsOk,					//wParam = friendName	lParam = cash

	notifyChangeNameOk,
	notifyChangeNameFailed,				//wParam = errorcode
	notifyChangeCharOk,

	notifyMemo,
	notifyFriendInfoArrived,			//wParam = friendName, lParam = TableID

	notifyAlertView,					//wParam = alertType	lParam = nButtonIndex

	notifyVersion,						//wParam = bSuccess		lParam = error_code
	notifyUploadKey,					//wParam = key
};

enum TMessage
{
	Message_Bonus,
	Message_Reject_Invite,
};
enum TWaiting
{
	Waiting_None,
	Waiting_Login,
	Waiting_BuyChip,
	Waiting_Table,
	Waiting_Sit,
	Waiting_Standup,
	Waiting_Email,
	Waiting_RegisterFriend,
	waiting_Ranking,
	Waiting_FriendInfo,
};

enum TUserState {
	stateNone = 100,
	stateConnected,
	stateLoginRequest,
	stateLoginSuccess,
	stateLobby,
	stateEnterTableRequest,
	stateTableSeat,
	stateTableView,
};

enum TGameLanguage {
	TGAME_ENG_LANG = 500,
	TGAME_CHN_LANG,
	TGAME_CHN_SIMLANG,
};

enum TGameTableView {
	TGAME_VIEW_ALL = 1,
	TGAME_HIDE_FULL,
};

enum TGameArrange {
	TGAME_ARRANGE_NAME = 70,
	TGAME_ARRANGE_BLIND,
};

enum TGameSoundIndex {
	soundLogon = 200,
	soundLose,
	soundWin,
	soundCardPass,
	soundCardOk,
};

enum TGameAlert {
	alertRegisterFriend = 10000,
	alertInvite,
	alertFriendInfo,
	alertRequestFriend,
};

#define LOG_LEVEL 2
enum {
	Log_info,
	Log_warning,
	Log_detail,
};

#endif // _COMMON_H

