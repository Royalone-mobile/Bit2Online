﻿#include <stdio.h>

#include <stdlib.h>
#include <string.h>
#include <wchar.h>
#include <time.h>

#include "GameTable.h"

namespace GE
{
	
char GameTable::m_sTemp[TEMP_STR_SIZE];

GameTable::GameTable(int nTableID, char* sName, TCASH fStake, bool bMaster)
:m_bFirstPlaying(true)
,m_bPlaying(false)
,m_nTableID(nTableID)
,m_bMaster(bMaster)
,m_fStack(fStake)
,m_pCallbackfunc(0)
,m_pCallbackLog(0)
,m_nWinnerSeatID(-1)
,m_fMoney(0.0f)
,m_nCurPlayerSeatID(0)
{
	strcpy(m_sName, sName);
	_clear();

	for( int i = 0 ; i < SEAT_COUNT; i++ )
	{
		m_bSeatsState[i] = false;
	}
}

GameTable::GameTable()
	:m_bFirstPlaying(true)
	,m_bPlaying(false)
	,m_nTableID(0)
	,m_bMaster(false)
	,m_fStack(0)
	,m_pCallbackfunc(0)
	,m_pCallbackLog(0)
	,m_nWinnerSeatID(-1)
	,m_fMoney(0.0f)
	,m_nCurPlayerSeatID(0)
	{
	strcpy(m_sName, "");
	_clear();
	for( int i = 0 ; i < SEAT_COUNT; i++ )
	{
		m_bSeatsState[i] = false;
	}
}

GameTable::GameTable(const GameTable& obj)
{
	m_bFirstPlaying = obj.m_bFirstPlaying;
	m_bPlaying = obj.m_bPlaying;
	m_nTableID = obj.m_nTableID;
	strcpy(m_sName, obj.m_sName);
	m_fStack = obj.m_fStack;
	m_bMaster = obj.m_bMaster;
	m_nCurPlayerSeatID = obj.m_nCurPlayerSeatID;

	for( int i = 0 ; i < SEAT_COUNT; i++ )
	{
		m_Players[i] = obj.m_Players[i];
		m_bSeatsState[i] = obj.m_bSeatsState[i];
		m_resultDatas[i] = obj.m_resultDatas[i];
	}

	m_pCallbackfunc = obj.m_pCallbackfunc;

	m_Actions = obj.m_Actions;
	m_fMoney = 0.0f;

	m_pCallbackLog = obj.m_pCallbackLog;
	m_nWinnerSeatID = obj.m_nWinnerSeatID;

}

GameTable& GameTable::operator= (const GameTable& obj)
{
	m_bFirstPlaying = obj.m_bFirstPlaying;
	m_bPlaying = obj.m_bPlaying;
	m_nTableID = obj.m_nTableID;
	strcpy(m_sName, obj.m_sName);
	m_fStack = obj.m_fStack;

	m_bMaster = obj.m_bMaster;

	m_pCallbackfunc = obj.m_pCallbackfunc;

	for( int i = 0 ; i < SEAT_COUNT; i++ )
	{
		m_Players[i] = obj.m_Players[i];
		m_bSeatsState[i] = obj.m_bSeatsState[i];
		m_resultDatas[i] = obj.m_resultDatas[i];
	}
	m_Actions = obj.m_Actions;
	m_fMoney = 0.0f;

	m_pCallbackLog = obj.m_pCallbackLog;

	m_nWinnerSeatID = obj.m_nWinnerSeatID;
	m_nCurPlayerSeatID = obj.m_nCurPlayerSeatID;

	return *this;
}

GameTable::~GameTable()
{
	_remove();
}

void GameTable::initGameTable(int nTableID, char* sName, TCASH fStake, bool bMaster)
{
	m_bFirstPlaying = true;
	m_bPlaying = false;
	m_nTableID = nTableID;
	m_fStack = fStake;
	m_fMoney = 0.0f;
	strcpy(m_sName, sName);

	bMaster = bMaster;

	m_Actions.clear();
	m_nWinnerSeatID = -1;

	for(int i = 0 ; i < SEAT_COUNT; i++)
		m_bSeatsState[i] = false;
	
	_clear();
}

int	 GameTable::_calcFirstPlayerSeatID(int nSeatID)
{
	/*
	int nPlayerCount = _getPlayerCountInTable();
	if (nPlayerCount == 0) {
		nPlayerCount = 1;
	}
	int id = rand() % nPlayerCount;
	int i = 0;
	for ( i = 0; i < SEAT_COUNT; i++ ) {
		if ( m_bSeatsState[i] == true ) {
			if(id == 0)
				return i;
			id--;
		}
	}

	int ret = 0;
	for ( i = 0; i < SEAT_COUNT; i++ ) {
		if (m_bSeatsState[i] == true) {
			ret = i;
		}
	}
	return ret;
	*/
	int ret = -1;
	if (m_bFirstPlaying == true)
	{
		m_nMinCard = 100;
		for ( int i = 0; i < SEAT_COUNT; i++ )
		{
			if (m_bSeatsState[i] == true)
			{
				char nCurCard = m_Players[i].getCard(CARD_COUNT_PER_PLAYER - 1);
				if (nCurCard < m_nMinCard)
				{
					m_nMinCard = nCurCard;
					ret = i;
				}
			}
		}
		return ret;
	}
	else
	{
		for ( int i = 0; i < SEAT_COUNT; i++ )
		{
			int nCurSeatID = (i + m_nWinnerSeatID) % SEAT_COUNT;
			if ( ! Assert(0<=nCurSeatID && nCurSeatID<4, "nCurSeatID is invalid.")) return 0;
			if (m_bSeatsState[ nCurSeatID ] == true)
				return nCurSeatID;
		}
	}
	for ( int i = 0; i < SEAT_COUNT; i++ ) {
		if (m_bSeatsState[i] == true) {
			ret = i;
		}
	}
	return ret;
}
bool GameTable::startGame(	)
{
#ifdef Test
	_log("-------------Game Started-------------");
#endif
	m_Actions.clear();
	for( int i = 0 ; i < SEAT_COUNT ; i++ )
	{
		if (m_bSeatsState[i] == true) {
			Player &player = m_Players[i];
			player.setPlaying();
		}
	}

	_clear();
    m_bMaster = true;
	if( m_bMaster )
	{
		_deal();
		m_nCurPlayerSeatID = _calcFirstPlayerSeatID(m_nCurPlayerSeatID);
		Action action(m_nCurPlayerSeatID,0,0);
		m_Actions.push_back(action);
	}

	m_bPlaying = true;

	for ( int i = 0 ; i < SEAT_COUNT ; i++ )
	{
		m_resultDatas[i].m_bSeatsState = m_bSeatsState[i];
		if (m_resultDatas[i].m_bSeatsState)
		{
			m_resultDatas[i].m_nPlayerID = m_Players[i].getPlayerID();
			strcpy(m_resultDatas[i].m_sName, m_Players[i].getPlayerName());
			m_resultDatas[i].m_fEarnMoney = 0;
		}
	}
	onStateChanged(EngineEvent_StartGame, 1, m_nCurPlayerSeatID);
	return true;
}

bool GameTable::finishGame(TID nPlayerID, bool bAutoOut)
{
#ifdef Test
	_log("-------------Game Finished-------------\r\n");
#endif
	int nSeatID = getSeatIDfromPlayerID(nPlayerID);
	if ( ! Assert(0<=nSeatID && nSeatID<4, "nSeatID is invalid.")) return false;

	if ( nSeatID == -1)
		return false;

	Player* winner = const_cast<Player*>(getPlayer(nPlayerID));
	if ( ! Assert(winner != NULL, "nPlayerID is invalid.")) return false;

	ResultData &WinnerResult =  m_resultDatas[nSeatID];
	for( int i = 0 ; i < SEAT_COUNT ; i++ )
	{
		if ( m_bSeatsState[i])
		{
			if (winner == &m_Players[i] || m_Players[i].isPlaying() == false) {
				continue;
			}
			int nRemainCardCount = m_Players[i].getCurCardCount();
			TCASH fMoney = _getLostMoney(nRemainCardCount);
			m_Players[i].addEmployedMoney(-fMoney);
			m_Players[i].setEarnMoney(-fMoney);
			m_resultDatas[i].m_fEarnMoney = -fMoney;
			m_fMoney += fMoney;
			m_Players[i].setPlaying(false);
		}
	}
	winner->addEmployedMoney(m_fMoney);
	winner->setEarnMoney(m_fMoney);
	WinnerResult.m_fEarnMoney = m_fMoney;
    
		m_fMoney = 0.0f;
	m_bPlaying = false;
	m_nWinnerSeatID = getSeatIDfromPlayerID(nPlayerID);
	if ( ! Assert(0<=nSeatID && nSeatID<4, "nSeatID is invalid.")) return false;
	if (bAutoOut)
	{
		for( int i = 0 ; i < SEAT_COUNT ; i++ )
		{
			if ( m_bSeatsState[i] == true )
			{
				if (!isAvailableSit( m_Players[i].getEmployedMoney() ))
				{
					onStateChanged(EngineEvent_AutoOut, i);
				}
			}
		}
	}
	return true;
}

void GameTable::_clear()
{
	for( int i = 0 ; i < SEAT_COUNT ; i++ )
	{
		for( int j = 0 ; j < CARD_COUNT_PER_PLAYER ; j++ )
			m_Players[i].removeCard(j);
	}
}

bool GameTable::_deal()
{
#ifdef Test
	_log("deal cards");
#endif
	bool bDealCards[CARD_COUNT];
	memset(bDealCards, 0, sizeof(bool) * CARD_COUNT);

	/*_getRandCard(true);*/	

	char nPlayerCards[CARD_COUNT_PER_PLAYER];
	for( int nSeatID = 0 ; nSeatID < SEAT_COUNT ; nSeatID++ )
	{
		for( int nCardID = 0 ; nCardID < CARD_COUNT_PER_PLAYER ; nCardID++ )
		{
			int nCardNumber = _getRandCard() % CARD_COUNT;
			for(int i = 0 ; i < CARD_COUNT ; i++)
			{
				if( ! bDealCards[nCardNumber])
				{
					bDealCards[nCardNumber] = true;
					break;
				}
				nCardNumber = (nCardNumber + 1) % CARD_COUNT;
			}
			nPlayerCards[nCardID] = nCardNumber + 1;
		}
		_sortCardsByNumber(nPlayerCards, CARD_COUNT_PER_PLAYER);
		if (m_bSeatsState[nSeatID])
			m_Players[nSeatID].setCards(nPlayerCards, CARD_COUNT_PER_PLAYER);
#if Test
		int length = 0;
		length += sprintf_s(m_sTemp + length, TEMP_STR_SIZE - length , "Deal: SeatID = %d Cards = ", nSeatID );
		makeCardsToStr(m_sTemp + length, TEMP_STR_SIZE - length, nPlayerCards, CARD_COUNT_PER_PLAYER);
		_log(m_sTemp);
#endif
	}

	return true;
}

void GameTable::update(unsigned int nTime)
{
}

void GameTable::onStateChanged(EngineEvent event, uint64 wParam, uint64 lParam)
{ 
	if( m_pCallbackfunc) m_pCallbackfunc(this, event, wParam, lParam);
}

void GameTable::_remove()
{
}

bool GameTable::sit( Player player, TPOS *pos)
{
	bool ret = false;
	for( int i = 0 ; i < SEAT_COUNT ; i++ )
	{
		ret = sit( i, player );
		if( ret )
		{
			if( pos != NULL)
				*pos = i;
			return true;
		}
	}
	onStateChanged(EngineEvent_Sit, player.getPlayerID(), 0);

	return false;
}
bool GameTable::sit(int nSeatID, Player player)
{
	//Seat is not find
	if( nSeatID >= SEAT_COUNT )
		return false;

	//when Seat is employed already, return false
	if( m_bSeatsState[nSeatID])
		return false;

	if ( !isAvailableSit(player.getEmployedMoney()) )
		return false;

	m_bSeatsState[nSeatID] = true;
	//seats player
	m_Players[nSeatID] = player;

	//onStateChanged(EngineEvent_Sit, nSeatID, 1);

	return true;
}

bool GameTable::isAvailableSit(TCASH fCash)
{
	TCASH fMinMoney = _getLostMoney(CARD_COUNT_PER_PLAYER);
	if (fCash < fMinMoney)
		return false;
	return true;
}
	
bool GameTable::isAvailableSitFromSeatID(int nSeatID)
{
	if (nSeatID >= SEAT_COUNT && nSeatID < 0) {
		return false;
	}
	return !m_bSeatsState[nSeatID];
}

bool GameTable::isAvailableStart()
{
	if( getCurPlayerCount() < 2 )
		return false;
	TCASH fMinMoney = _getLostMoney(CARD_COUNT_PER_PLAYER);
	for( int i = 0 ; i < SEAT_COUNT ; i++ )
	{
		if (m_bSeatsState[i] && m_Players[i].getEmployedMoney() < fMinMoney )
			return false;
	}
	return true;
}

int GameTable::_getPlayerCountInTable()
{
	int nCount = 0;
	for (int i = 0 ; i < SEAT_COUNT; i++ ) {
		if (m_bSeatsState[i] == true) {
			nCount++;
		}
	}
	return nCount;
}
int GameTable::_getNextPlayer(int nSeatID)
{
	if( _getPlayerCountInTable() == 1 )
		return nSeatID;

	// when next seat isn't employed any player 
	//or it is employed but player is not playing, 
	// find next player
	for( int i = 0 ; i < SEAT_COUNT ; i++ )
	{
		nSeatID = ( nSeatID + SEAT_COUNT + 1 ) % SEAT_COUNT;
		if( m_bSeatsState[nSeatID] && m_Players[nSeatID].isPlaying())
			break;
	}
	
	return nSeatID;
}

int GameTable::_getPrevPlayer(int nSeatID)
{
	if( _getPlayerCountInTable() == 1 )
		return nSeatID;

	// when previous seat isn't employed any player 
	//or it is employed but player is not playing, 
	// find previous player
	for( int i = 0 ; i < SEAT_COUNT ; i++ )
	{
		nSeatID = ( nSeatID + SEAT_COUNT - 1 ) % SEAT_COUNT;
		if( m_bSeatsState[nSeatID] && m_Players[nSeatID].isPlaying())
			break;
	}

	return nSeatID;
}

char* GameTable::getTableName()
{
	return m_sName;
}

bool GameTable::setAction(int nPlayerID, char * cards, int nCardCount)
{
	if ( ! Assert(0<=m_nCurPlayerSeatID && m_nCurPlayerSeatID<4, "m_nCurPlayerSeatID is invalid.")) return false;
	if ( ! Assert(0<=nCardCount && nCardCount<=MAX_CARD_COUNT, "nCardCount is invalid.")) return false;

	Player &player = m_Players[m_nCurPlayerSeatID];
	if(player.getPlayerID() != nPlayerID )
		return false;

	if( ! player.isPlaying())
		return false;

	if( nCardCount < 0 || nCardCount > 5)
		return false;

	for( int i  = 0 ; i < nCardCount ; i++ )
	{
		if ( player.getCardPos(cards[i]) == -1 )
			return false;
		
	}

	if (nCardCount != 0)
	{
		if ( _getCardGroup(cards, nCardCount) == CARDGROUP_NONE )
			return false;

		// temporary comment
		/*
        if (m_bFirstPlaying)
        {
            bool bExist = false;
            for( int i  = 0 ; i < nCardCount ; i++ )
            {
                if(cards[i] == m_nMinCard)
                    bExist = true;
            }
            if (!bExist)
                return false;

            m_bFirstPlaying = false;
        }*/
		if (m_nCurPlayerSeatID != getLastPlayerSeatID() )
		{
			if( nCardCount != getTableCardCount()/*m_nCurCardCount*/ )
				return false;
			if ( _isLarge( cards, getTableCards()/*m_nCurCards*/, nCardCount ) != 1 )
				return false;
		}
		_sortCards( cards, nCardCount);
		Action action(m_nCurPlayerSeatID, nCardCount, cards);
		m_Actions.push_back(action);

		onStateChanged(EngineEvent_ActionPlayed, nPlayerID, 1);

	}
	else
	{
		if (m_nCurPlayerSeatID == getLastPlayerSeatID()/*m_nLastPlayerSeatID*/ )
			return false;
		onStateChanged(EngineEvent_ActionPlayed, nPlayerID, 0);
	}

#if Test
	int length = 0;
	length += sprintf_s(m_sTemp + length, TEMP_STR_SIZE - length, "Action:\t SeatID = %d Cards = ", m_nCurPlayerSeatID);
	length += makeCardsToStr(m_sTemp + length, TEMP_STR_SIZE - length, cards, nCardCount);
	_log(m_sTemp);
#endif
	for (int i = 0 ; i < nCardCount ; i++ )
		player.removeCardbyCardNumber(cards[i]);

	m_nCurPlayerSeatID = _getNextPlayer(m_nCurPlayerSeatID);

	if( player.getCurCardCount() == 0 )
	{
		finishGame(nPlayerID);
		return true;
	}

	return false;
}
int GameTable::_isLarge(const char* card1, const char* card2, int nCardCount)
{
	CardGroupState state1 = _getCardGroup( card1, nCardCount );
	CardGroupState state2 = _getCardGroup( card2, nCardCount );
	if( state1 <  state2 )
	{
		return -1;
	}
	else if( state1 > state2 )
		return 1;
	else
	{
		char tempcards1[MAX_CARD_COUNT];
		_copyCards(tempcards1, card1, nCardCount );
		_sortCards(tempcards1, nCardCount);

		char tempcards2[MAX_CARD_COUNT];
		_copyCards(tempcards2, card2, nCardCount);
		_sortCards(tempcards2, nCardCount);

		int indexOfCard = 0;
		for( ; indexOfCard < nCardCount ; indexOfCard++ )
		{
			int nLarge = _isLarge(tempcards1[indexOfCard] , tempcards2[indexOfCard]) ;
			if( nLarge == 1 )
				return 1;
			if( nLarge == -1 )
				return -1;
		}
	}
	return 0;
}

bool GameTable::outPlayerInSeatFromSeatID(int nSeatID)
{
	if( nSeatID >= SEAT_COUNT || nSeatID < 0)
	{
		unsigned int wParam = MAKEWPARAM(0,nSeatID );// HIWORD(wParam) = nSeatID LOWORD(wParam) = false
		onStateChanged(EngineEvent_Out, wParam, 0);

		return false;
	}

	//already seat is empty, return false
	if( ! m_bSeatsState[nSeatID])
	{
		unsigned int wParam = MAKEWPARAM(0,nSeatID );// HIWORD(wParam) = nSeatID LOWORD(wParam) = false
		onStateChanged(EngineEvent_Out, wParam, 0);

		return true;
	}

	Player &player = m_Players[nSeatID];
	ResultData &result = m_resultDatas[nSeatID];
	int nRemainPlayerCount = 0;
	for (int i = 0 ; i < SEAT_COUNT ; i++ )
	{
		if ( m_bSeatsState[i] && m_Players[i].isPlaying())
		{
			nRemainPlayerCount++;
		}
	}


	if (!m_Players[nSeatID].isPlaying()) {
		//if cur player is not playing, do nothing
	}
	else if(nRemainPlayerCount == 2)
	{
		int nRemainPlayerID = 0;
		
		int i = 0;
		for (i = 0 ; i < SEAT_COUNT ; i++ )
		{
			if ( m_bSeatsState[i] && i != nSeatID && m_Players[i].isPlaying() )
			{
				nRemainPlayerID = m_Players[i].getPlayerID();
			}
		}

		m_bFirstPlaying = true;
		finishGame(nRemainPlayerID, false);
	}
	else if ( nRemainPlayerCount > 2 )
	{
		TCASH fLostMoney = _getLostMoney( player.getCurCardCount() );
		m_fMoney +=  fLostMoney ;
		player.addEmployedMoney(- fLostMoney );
		player.setEarnMoney(- fLostMoney );
		result.m_fEarnMoney = -fLostMoney;
	}
	onStateChanged(EngineEvent_Out, nSeatID, 1 );
	player.setPlaying(false);
	player.setPlayerID(0);
	player.setEmployedMoney(0.0f);
	player.setPlaying(false);
	
	m_bSeatsState[nSeatID] = false;

	if( nSeatID == m_nCurPlayerSeatID )
		m_nCurPlayerSeatID = _getNextPlayer(nSeatID);

	Action lastAction = getLastAction();
	if( nSeatID == getLastAction().nSeatID ){
		Action newAction = lastAction;
		newAction.nSeatID = _getNextPlayer( lastAction.nSeatID ) ;
		m_Actions.push_back(newAction);
	}
	return true;
}
bool GameTable::outPlayerInSeat(int nPlayerID)
{
	int nSeatID = getSeatIDfromPlayerID(nPlayerID);
	if ( ! Assert(0<=nSeatID && nSeatID<4, "nSeatID is invalid.")) return false;
	return outPlayerInSeatFromSeatID(nSeatID);
}

const Player* GameTable::getPlayer(int nPlayerID)
{
	int nSeatID= 0;
	nSeatID = getSeatIDfromPlayerID(nPlayerID);
	if (nSeatID == -1) {
		return NULL;
	}
	return getPlayerfromSeatID(nSeatID);
}
const Player* GameTable::getPlayerfromSeatID(int nSeatID)
{
	if( nSeatID >= SEAT_COUNT )
		return NULL;
	if ( nSeatID < 0) {
		return NULL;
	}
	//if( m_bSeatsState[nSeatID])
    return &m_Players[nSeatID];
	//return NULL;
}


bool GameTable::_sortCardsByNumber(char* cards, int nCardCount)
{
	bool bReplaced = false;
	do 
	{
		bReplaced = false;
		for ( int i = 0; i < nCardCount - 1 ; i++ )
		{
			if( _isLarge( cards[i] ,
				cards[i+1]) == -1 )
			{
				_replaceTwoCards(&cards[i], &cards[i+1]);
				bReplaced = true;
			}
		}
	} while (bReplaced);
	return true;
}
bool GameTable::_sortCards(char* cards, int nCardCount)
{
	_sortCardsByNumber(cards, nCardCount);

	char* pCards = cards;

	while ( _getSameCardCount(pCards,nCardCount) >= 2)
	{
		int nMaxCount = _getSameCardCount(pCards,nCardCount);

		int nCount = 1;
		for(int i = 1; i < nCardCount; i++ )
		{
			if( _getCardNumber(pCards[i - 1]) == _getCardNumber(pCards [i]) )
			{
				nCount++;
				if ( nCount == nMaxCount )
				{
					int nPrevCount = i - nMaxCount + 1;
					char* pPrevCards = new char[nPrevCount];
					_copyCards(pPrevCards, pCards, nPrevCount);
					for (int j = nPrevCount ; j <nPrevCount + nMaxCount ; j++ )
						pCards[j - nPrevCount] = pCards[j];
					_copyCards(pCards + nMaxCount, pPrevCards, nPrevCount);
					pCards += nMaxCount;
					nCardCount -= nMaxCount;
					SAFE_DELETE_ARRAY(pPrevCards);
					break;
				}
			}
			else
				nCount = 1;
		}
	}
/*	if( nCardCount == 5 &&
		_getCardNumber(cards[0])  == 1 &&
		_getCardNumber(cards[1])  == 0 &&
		_getCardNumber(cards[2])  == 4 &&
		_getCardNumber(cards[3])  == 3 &&
		_getCardNumber(cards[4])  == 2)
	{
		char tempcards[5];
		memcpy(tempcards, cards, sizeof(char) * 5);
		cards[0]  = tempcards[2];
		cards[1]  = tempcards[3];
		cards[2]  = tempcards[4];
		cards[3]  = tempcards[0];
		cards[4]  = tempcards[1];
	}
*/
	return true;

}

void GameTable::_replaceTwoCards(char* card1, char* card2)
{
	char temp = *card1;
	*card1 = *card2;
	*card2 = temp;
}
int GameTable::_isLarge(char card1, char card2)
{
	int cardNumber1 = int( (card1- 1) / SUIT_COUNT) ;

	int cardNumber2 = int( (card2 -1) / SUIT_COUNT) ;

	if( cardNumber1 < 2  )
		cardNumber1 += CARD_NUMBER_COUNT ;

	if( cardNumber2 < 2 )
		cardNumber2 += CARD_NUMBER_COUNT;

	if( cardNumber1 > cardNumber2 )
		return 1;
	else if( cardNumber1 < cardNumber2 )
		return -1;
	else if (card1 > card2 )
		return 1;
	else if (card1 < card2)
		return -1;
	else
		return 0;

	return 0;
}
int GameTable::_getSameCardCount(const char* cards, int nCardCount)
{
	char* tempcards = new char[nCardCount];
	
	int i  = 0 ;
	for(; i < nCardCount; i++ )
	{
		tempcards[i] = cards[i];
	}
	_sortCardsByNumber(tempcards, nCardCount);
	

	int nMaxCount =0, nCount = 1;
	for(i = 0; i < nCardCount -1; i++ )
	{
		if(_getCardNumber( tempcards[i] )== _getCardNumber( tempcards[i + 1] ) )
		{
			nCount++;
			if( nCount > nMaxCount )
				nMaxCount = nCount;
		}
		else
			nCount = 1;
	}
	
	SAFE_DELETE_ARRAY(tempcards);
	return nMaxCount;
}

int GameTable::_getDiffCardCount(const char* cards, int nCardCount)
{
	char* tempcards = new char[nCardCount];
	_copyCards(tempcards, cards, nCardCount);
	_sortCardsByNumber(tempcards, nCardCount);

	int nCount = 1;
	for(int i = 1; i < nCardCount; i++ )
	{
		if( _getCardNumber(tempcards[i]) != _getCardNumber(tempcards[i - 1]) )
			nCount++;
	}

	SAFE_DELETE_ARRAY(tempcards);
	return nCount;
}
CardGroupState GameTable::_getCardGroup(const char* cards, int nCardCount)
{
	if( _isStraightFlush(cards, nCardCount) )
		return CARDGROUP_STRAIGHTFLUSH;
	if( _isQuad(cards, nCardCount) )
		return CARDGROUP_QUAD;
	if( _isFullHouse(cards, nCardCount) )
		return CARDGROUP_FULLHOUSE;
	if( _isFlush(cards, nCardCount) )
		return CARDGROUP_FLUSH;
	if( _isStraight(cards, nCardCount) )
		return CARDGROUP_STRAIGHT;
	if( _isTriple(cards, nCardCount) )
		return CARDGROUP_TRIPLE;
	if( _isPair(cards, nCardCount) )
		return CARDGROUP_PAIR;
	if( _isSingle(cards, nCardCount) )
		return CARDGROUP_SINGLE;

	return CARDGROUP_NONE;
}
bool GameTable::_isSingle(const char* cards, int nCardCount)
{
	if( nCardCount == 1 )
		return true;
	return false;
}

bool GameTable::_isPair(const char* cards, int nCardCount)
{
	if( nCardCount != 2)
		return false;
	if( _getSameCardCount(cards, nCardCount) == 2 )
		return true;
	return false;
}

bool GameTable::_isTriple(const char* cards, int nCardCount)
{
	if( nCardCount != 3 )
		return false;
	if( _getSameCardCount(cards, nCardCount) == 3 )
			return true;
	return false;
}
bool GameTable::_isFive(const char* cards, int nCardCount)
{
	return _isStraight(cards, nCardCount)
		|| _isFlush(cards, nCardCount)
		|| _isFullHouse(cards, nCardCount)
		|| _isQuad(cards, nCardCount)
		|| _isStraightFlush(cards, nCardCount);
}
bool GameTable::_isStraight(const char* cards, int nCardCount)
{
	if( nCardCount != 5 )
		return false;
	if( __isStraight(cards, nCardCount) 
		&& !__isFlush(cards, nCardCount) )
		return true;
	return false;
}

bool GameTable::_isFlush(const char* cards, int nCardCount)
{
	if( nCardCount != 5 )
		return false;
	if( __isFlush(cards, nCardCount) 
		&& !__isStraight(cards, nCardCount) )
		return true;
	return false;
}

bool GameTable::_isFullHouse(const char* cards, int nCardCount)
{
	if( nCardCount != 5 )
		return false;
	char* tempCards = new char[nCardCount];
	_copyCards(tempCards, cards, nCardCount);
	_sortCards(tempCards, nCardCount);
	bool ret  = _getSameCardCount(tempCards,     nCardCount   ) == 3 ?	true : false;
	ret  &=     _getSameCardCount(tempCards + 3, nCardCount -3) == 2 ?	true : false;
	SAFE_DELETE_ARRAY(tempCards);
	return ret;
}

bool GameTable::_isQuad(const char* cards, int nCardCount)
{
	if( nCardCount != 5 )
		return false;
	if( _getSameCardCount(cards, nCardCount) == 4 )
		return true;
	return false;
}
bool GameTable::_isStraightFlush(const char* cards, int nCardCount)
{
	if ( __isStraight(cards, nCardCount)
		&& __isFlush(cards, nCardCount) )
		return true;
	return false;
}
void GameTable::_copyCards(char* dstCards, const char* srcCards, int nCount)
{
	memcpy(dstCards, srcCards, sizeof(bool) * nCount);
}
bool GameTable::__isStraight(const char* cards, int nCardCount)
{
	if(nCardCount < 5)
		return false;
	if(_getDiffCardCount(cards,nCardCount) < 5 )
		return false;

	char* tempCards = new char[nCardCount];
	_copyCards(tempCards, cards, nCardCount);
	_sortCards(tempCards, nCardCount);

	if( _getCardNumber(tempCards[0]) == 1 &&
		_getCardNumber(tempCards[1]) == 0 &&
		_getCardNumber(tempCards[2]) == 4 &&
		_getCardNumber(tempCards[3]) == 3 &&
		_getCardNumber(tempCards[4]) == 2 )
	{
		SAFE_DELETE_ARRAY(tempCards);
		return true;
	}
	if( _getCardNumber(tempCards[0]) == 1 &&
		_getCardNumber(tempCards[1]) == 5 &&
		_getCardNumber(tempCards[2]) == 4 &&
		_getCardNumber(tempCards[3]) == 3 &&
		_getCardNumber(tempCards[4]) == 2 )
	{
		SAFE_DELETE_ARRAY(tempCards);
		return true;
	}
	if( _getCardNumber(tempCards[0]) == 0 &&
		_getCardNumber(tempCards[1]) == 12 &&
		_getCardNumber(tempCards[2]) == 11 &&
		_getCardNumber(tempCards[3]) == 10 &&
		_getCardNumber(tempCards[4]) == 9 )
	{
		SAFE_DELETE_ARRAY(tempCards);
		return true;
	}
	int nCount = 1;
	for( int i = 1 ; i < nCardCount ; i++ )
	{
		if( _getCardNumber(tempCards[i]) == _getCardNumber(tempCards[i - 1]) - 1 )
			nCount++;
		else
			nCount = 1;
	}
	SAFE_DELETE_ARRAY(tempCards);
	if( nCount >= 5)
		return true;
	return false;
}
bool GameTable::__isFlush(const char* cards, int nCardCount)
{
	for( int i = 0 ; i < (int)SUIT_COUNT; i++)
	{
		int nCount = 0;
		for( int j = 0 ; j < nCardCount; j++ )
			if( _getCardSuit(cards[j]) == (Suit)i )
				nCount++;
		if( nCount >= 5)
			return true;
	}
	return false;
}

int GameTable::_getRandCard(bool init)
{
/*	static int randserial[] = {0, 4, 8, 12, 16, 20, 24, 28, 32, 36, 40, 44, 48,
							   1, 5, 9, 13, 17, 21, 25, 29, 33, 37, 41, 45, 49,
							   2, 6, 10, 14, 18, 22, 26, 30, 34, 38, 42, 46, 50,
							   3, 7, 11, 15, 19, 23, 27, 31, 35, 39, 43, 47, 51};
	static int i = 0;
	int randNum = 0;

	if (init)
	{
		i = 0;
		return 0;
	}

	if (i < sizeof(randserial)/sizeof(randserial[0])){
		randNum = randserial[i];
		i++;
	}else {
		randNum = rand() % CARD_COUNT;
	}

	return randNum;
*/
	return rand() % CARD_COUNT;
}
int GameTable::getCurPlayerCount() const
{
	int nCount = 0 ;
	for( int i = 0 ; i < SEAT_COUNT ; i++ )
	{
		if( m_bSeatsState[i])
		{
			nCount++;
		}
	}
	return nCount;
}

int	GameTable::getSeatIDfromPlayerID(int nPlayerID)
{
	int i = 0;
	for( i = 0 ; i < SEAT_COUNT ; i++ )
	{
		if( m_bSeatsState[i] && m_Players[i].getPlayerID() == nPlayerID )
			return i;
	}
	return -1;
}

bool GameTable::dealFromOther(char* pCards)
{

	int counter = 0;
	for( int i = 0 ; i < SEAT_COUNT ; i++ )
	{
		for (int j = 0 ; j < CARD_COUNT_PER_PLAYER ; j++ )
		{
			if (m_bSeatsState[i] == true)
				m_Players[i].addCard(pCards[counter]);
			counter++;
		}
#if Test
		int length = 0;
		length += sprintf_s(m_sTemp + length, TEMP_STR_SIZE - length , "Deal:\t SeatID = %d Cards = ", i );
		makeCardsToStr(m_sTemp + length, TEMP_STR_SIZE - length, m_Players[i].getCards(), m_Players[i].getCurCardCount());
		_log(m_sTemp);
#endif
	}
    m_nMinCard = 100;
    for ( int i = 0; i < SEAT_COUNT; i++ )
    {
        if (m_bSeatsState[i] == true)
        {
            char nCurCard = m_Players[i].getCard(CARD_COUNT_PER_PLAYER - 1);
            if (nCurCard < m_nMinCard)
            {
                m_nMinCard = nCurCard;
            }
        }
    }

	return true;
}

void GameTable::_log(char* buf)
{
	if(m_pCallbackLog)
		m_pCallbackLog(buf);
}

#if Test
int GameTable::makeCardsToStr(char* str, int nStrlen,const char* cards, int nCardCount)
{
	int length = 0;
	
	char strSuit[SUIT_COUNT][3]			= { "♦", "♣", "♥", "♠" };
	char strNumber[CARD_NUMBER_COUNT][3]= { "A", "2", "3","4","5","6","7","8","9","10","J","Q","K"};
	for (int i = 0 ; i < nCardCount ; i++ )
	{
		int nCardNumber = _getCardNumber(cards[i]);
		int nCardSuit = _getCardSuit(cards[i]);
		length += sprintf_s(str + length, nStrlen - length, "%s%s ", strSuit[nCardSuit], strNumber[nCardNumber] );
	}
	return length;
}
#endif

void GameTable::setFirstPlayerSeatID(int nSeatID)
{ 
	m_nCurPlayerSeatID = nSeatID;
	Action action(nSeatID, 0,0);
	m_Actions.push_back(action);
}

Actions GameTable::getAvailableActions(TID nPlayerID)
{
	int nSeatID = getSeatIDfromPlayerID(nPlayerID);
	if ( ! Assert(0<=nSeatID && nSeatID<4, "nSeatID is invalid.")) nSeatID = 0;
	Player& player = m_Players[nSeatID];
	Actions actions;
	Action lastAction = getLastAction();
	if( nSeatID == lastAction.nSeatID 
		|| lastAction.nCardCount == 0 )
		_findAll(actions, player.getCards());
	else if (lastAction.nCardCount == 1)
		_findSingleCards(actions,lastAction.Cards, lastAction.nCardCount, player.getCards());
	else if (lastAction.nCardCount == 2)
		_findPairCards(actions,lastAction.Cards, lastAction.nCardCount, player.getCards());
	else if (lastAction.nCardCount == 3)
		_findTripleCards(actions,lastAction.Cards, lastAction.nCardCount, player.getCards());
	else if (lastAction.nCardCount == 5)
		_findFiveCards(actions,lastAction.Cards, lastAction.nCardCount, player.getCards());
	return actions;
}
bool GameTable::isAvailableAction(TID nPlayerID, const char* cards, int nCardCount)
{
	int nSeatID = getSeatIDfromPlayerID(nPlayerID);
	if ( ! Assert(0<=nSeatID && nSeatID<4, "nSeatID is invalid.")) nSeatID = 0;
	Player& player = m_Players[nSeatID];
	Actions actions;
	Action lastAction = getLastAction();
	if( nSeatID == lastAction.nSeatID 
	   || lastAction.nCardCount == 0 )
		_findAll(actions, player.getCards());
	else if (lastAction.nCardCount == 1)
		_findSingleCards(actions,lastAction.Cards, lastAction.nCardCount, player.getCards());
	else if (lastAction.nCardCount == 2)
		_findPairCards(actions,lastAction.Cards, lastAction.nCardCount, player.getCards());
	else if (lastAction.nCardCount == 3)
		_findTripleCards(actions,lastAction.Cards, lastAction.nCardCount, player.getCards());
	else if (lastAction.nCardCount == 5)
		_findFiveCards(actions,lastAction.Cards, lastAction.nCardCount, player.getCards());

	Actions::iterator it = actions.begin(), itEnd = actions.end();
	for (; it != itEnd; it++ ) {
		if (it->nCardCount == nCardCount)
		{
			bool bAvailable = true;
			for (int i = 0 ; i < nCardCount; i++)
			{
				if (it->Cards[i] != cards[i]) {
					bAvailable = false;
					break;
				}
			}
			if (bAvailable)
				return true;
		}
	}
	return false;
}

void GameTable::_findAll(Actions& actions, const char *cards)
{
	_findFiveCards(actions, 0, NULL, cards);
	_findTripleCards(actions,0, NULL, cards);
	_findPairCards(actions,0, NULL, cards);
	_findSingleCards(actions,0, NULL, cards);
}

void GameTable::_findSingleCards(Actions& actions, const char* pPrevCards, int nPrevCardsCount, const char *cards)
{
	if( nPrevCardsCount != 1 && nPrevCardsCount != 0 )
		return;
	for (int i = 0 ; i < CARD_COUNT_PER_PLAYER ; i++ )
	{
		if (cards [i] == 0 )
			continue;
        
        if( (nPrevCardsCount == 1 && _isLarge(cards[i], pPrevCards[0]) == 1) 
           || nPrevCardsCount == 0 )
        {
            if (m_bFirstPlaying) {
                //if (cards[i] == m_nMinCard) {
                    actions.push_back(Action(0, 1, cards + i ));
                //}
            }
            else
                actions.push_back(Action(0, 1, cards + i ));
            
        }
	}
}
void GameTable::_findPairCards(Actions& actions, const char* pPrevCards, int nPrevCardsCount, const char  *cards)
{
	if( nPrevCardsCount != 2 && nPrevCardsCount != 0 )
		return;
	char tempCards[CARD_COUNT_PER_PLAYER];
	_copyCards(tempCards, cards, CARD_COUNT_PER_PLAYER);
	_sortCards(tempCards, CARD_COUNT_PER_PLAYER);

	_sortCardsByNumber(tempCards, CARD_COUNT_PER_PLAYER);

	for (int i = 0 ; i < CARD_COUNT_PER_PLAYER ; i++ )
	{
		if (tempCards [i] == 0 )
			continue;
		for (int j = i+1 ; j < CARD_COUNT_PER_PLAYER ; j++)
		{
			if (tempCards [j] == 0 )
				continue;
			char push[2] = { tempCards[i], tempCards[j] } ;
			if( !_isPair(push, 2 ))
				continue;
			if( nPrevCardsCount == 2 
				&&  _isLarge(push, pPrevCards,2) != 1 )
				continue;
			/*
            if (m_bFirstPlaying) {
                bool bAvailable = false;
                for ( int nPushCardID = 0; nPushCardID < 2; nPushCardID++ ) {
                    if(push[nPushCardID] == m_nMinCard)
                    {
                        bAvailable = true;
                        break;
                    }
                }
                if (!bAvailable)
                    continue;
            }*/
			actions.push_back(Action(0, 2, push));
		}
	}
}

void GameTable::_findTripleCards(Actions& actions, const char * pPrevCards, int nPrevCardsCount, const char  *cards)
{
	if( nPrevCardsCount != 3 && nPrevCardsCount != 0 )
		return;
	char tempCards[CARD_COUNT_PER_PLAYER];
	_copyCards(tempCards, cards, CARD_COUNT_PER_PLAYER);
	_sortCards(tempCards, CARD_COUNT_PER_PLAYER);

	_sortCardsByNumber(tempCards, CARD_COUNT_PER_PLAYER);

	for (int i = 0 ; i < CARD_COUNT_PER_PLAYER ; i++ )
	{
		if (tempCards [i] == 0 )
			continue;
		for (int j = i+1 ; j < CARD_COUNT_PER_PLAYER ; j++)
		{
			if (tempCards [j] == 0 )
				continue;

			for (int k = j+1 ; k < CARD_COUNT_PER_PLAYER ; k++)
			{
				if (tempCards [k] == 0 )
					continue;
				char push[3] = { tempCards[i], tempCards[j], tempCards[k] } ;
				if( !_isTriple(push, 3 ) )
					continue;
				if( nPrevCardsCount == 3 
					&& _isLarge(push, pPrevCards ,3) != 1 )
					continue;
				/*
                if (m_bFirstPlaying) {
                    bool bAvailable = false;
                    for ( int nPushCardID = 0; nPushCardID < 3; nPushCardID++ ) {
                        if(push[nPushCardID] == m_nMinCard)
                        {
                            bAvailable = true;
                            break;
                        }
                    }
                    if (!bAvailable)
                        continue;
                }*/
				actions.push_back(Action(0, 3, push));
			}
		}
	}
}

void GameTable::_findFiveCards(Actions& actions, const char * pPrevCards, int nPrevCardsCount, const char  *cards)
{
	if( nPrevCardsCount != 5 && nPrevCardsCount != 0 )
		return;
	char tempCards[CARD_COUNT_PER_PLAYER];
	_copyCards(tempCards, cards, CARD_COUNT_PER_PLAYER);
	_sortCards(tempCards, CARD_COUNT_PER_PLAYER);

	_sortCardsByNumber(tempCards, CARD_COUNT_PER_PLAYER);

	for (int i1 = 0 ; i1 < CARD_COUNT_PER_PLAYER ; i1++ )
	{
		if (tempCards [i1] == 0 )
			continue;
		for (int i2 = i1+1 ; i2 < CARD_COUNT_PER_PLAYER ; i2++)
		{
			if (tempCards [i2] == 0 )
				continue;

			for (int i3 = i2+1 ; i3 < CARD_COUNT_PER_PLAYER ; i3++)
			{
				if (tempCards [i3] == 0 )
					continue;
				for (int i4 = i3+1 ; i4 < CARD_COUNT_PER_PLAYER ; i4++)
				{
					if (tempCards [i4] == 0 )
						continue;
					for (int i5 = i4+1 ; i5 < CARD_COUNT_PER_PLAYER ; i5++)
					{
						if (tempCards [i5] == 0 )
							continue;
						char push[5] = { tempCards[i1], tempCards[i2], tempCards[i3] , tempCards[i4] , tempCards[i5] } ;
						if( !_isFive(push, 5 ) )
							continue;
						if( nPrevCardsCount == 5 
							&& _isLarge(push, pPrevCards , 5) != 1 )
							continue;
						/*
                        if (m_bFirstPlaying) {
                            bool bAvailable = false;
                            for ( int nPushCardID = 0; nPushCardID < 5; nPushCardID++ ) {
                                if(push[nPushCardID] == m_nMinCard)
                                {
                                    bAvailable = true;
                                    break;
                                }
                            }
                            if (!bAvailable)
                                continue;
                        }*/
						actions.push_back(Action(0, 5, push));
					}
				}
			}
		}
	}
}


Action	GameTable::getLastAction()
{
	if (m_Actions.size() == 0 )
	{
		return Action(0,0,0);
	}
	return m_Actions.back();
}

void GameTable::updateAutoPlayer(TID nPlayerID, Action& action )
{
	Actions actions = getAvailableActions(nPlayerID);
	int nActionCount = actions.size();
	if( nActionCount == 0 )
	{
		action.nSeatID = 0;
		action.nCardCount = 0;
		return;
	}
    int id = rand() % actions.size();
    action  = actions[id];
}

TCASH GameTable::_getLostMoney(int nCardCount)
{
	int nTimes = 1;
	if ( nCardCount <= 7 )
		nTimes = 1;
	else if( nCardCount <= 9 )
		nTimes = 2;
	else if( nCardCount <= 12)
		nTimes = 3;
	else
		nTimes = 4;
	
	return nTimes * m_fStack * nCardCount;
}
}//end of Namespace GE
