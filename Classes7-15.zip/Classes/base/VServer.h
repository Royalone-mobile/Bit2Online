#pragma once

#include "ServerTable.h"

typedef void CallBackFuncSendtoPlayer(int ID, int pktID, void* buf, unsigned int size);

//class for Virtual Server
class VServer
{
public:
	VServer(void);
	virtual ~VServer(void);
	void createTable(TCASH fStake);
	void setFuncSendtoPlayer(CallBackFuncSendtoPlayer *pFunc) {m_pFuncSendtoPlayer = pFunc; }

	void	recvPacket(TID nPlayerID, int pktID, void* pData, unsigned int size);
	
	void	update(unsigned int nTime);
	
	const GE::ServerTable* getServerTable(){ return m_pServerTable; }
protected:
	GE::ServerTable* m_pServerTable;

	CallBackFuncSendtoPlayer *m_pFuncSendtoPlayer;
};
