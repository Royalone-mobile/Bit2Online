#pragma once
#include "GameTable.h"

typedef void (CallBackFunc2Params)(int ID, int pktID, unsigned int wParam, unsigned int lParam);
typedef void (CallBackFunc6Params)(int ID, int pktID, unsigned int wParam1, unsigned int wParam2, unsigned int wParam3, unsigned int wParam4, unsigned int wParam5, unsigned int wParam6);
typedef void (CallBackFuncBuf)(int ID, int pktID, void* buf, unsigned int size);
typedef bool (CallBackChangeCash)(int nPlayerID, TCASH fCash);
typedef bool (CallBackHistory)(int nPlayerID, int winType);
typedef void (CallBackKickOut)(TID nPlayerID, TID nTableID, int reason);
typedef void (CallBackLog)(const char *pLog);

namespace GE
{

class ServerTable : public GameTable
{
public:

	void setCallbackFunc(CallBackFunc2Params *pCallBackTableSend1  = NULL
		, CallBackFunc6Params *pCallBackTableSend2  = NULL
		, CallBackFuncBuf  *pCallBackTableSend3  = NULL
		, CallBackFunc2Params *pCallBackPlayerSend1 = NULL
		, CallBackFunc6Params *pCallBackPlayerSend2 = NULL
		, CallBackFuncBuf  *pCallBackPlayerSend3  = NULL
		, CallBackChangeCash *pCallackChangeCash = NULL
		, CallBackHistory *pCallBackHistory = NULL
		, CallBackKickOut *pCallBackKickOut = NULL
		, CallBackLog *pCallBackLog = NULL
		);
	bool	startGame();

	//it calls when Game ended
	// param
	//		bForce : 
	bool	finishGame(TID nPlayerID, bool bAutoOut = true);
	bool	outPlayerInSeatFromSeatID(int nSeatID);
	
	bool	setAction(int nPlayerID, char * cards, int nCardCount);

	virtual void update(unsigned int nTime);

	//return 0 : success, return other: ErrorCode
	int onNotifyReceive(TID nPlayerID, int pktID, void* pData, unsigned int size);

	void onStateChanged(EngineEvent event, uint64 wParam, uint64 lParam);

	void variableParameter(...);

	void	viewTable(int nPlayerID){ onStateChanged(EngineEvent_ViewTable,nPlayerID,0); }

	bool Assert(bool bValid, const char *pstrAssert){
		if ( ! bValid)
		{
			if (m_pCallBackLog)
			{
				if (pstrAssert) m_pCallBackLog(pstrAssert);
			}
		}
		return bValid;
	};

protected:

	unsigned int		m_nStartGameTime;
	unsigned int		m_nActionDelayTime;

	CallBackFunc2Params *m_pCallBackTableSend1 ;
	CallBackFunc6Params *m_pCallBackTableSend2 ;
	CallBackFuncBuf  *m_pCallBackTableSend3 ;

	CallBackFunc2Params *m_pCallBackPlayerSend1;
	CallBackFunc6Params *m_pCallBackPlayerSend2;
	CallBackFuncBuf  *m_pCallBackPlayerSend3;

	CallBackChangeCash *m_pCallBackChangeCash;
	CallBackHistory *m_pCallBackHistory;
	CallBackKickOut *m_pCallBackKickOut;

	CallBackLog *m_pCallBackLog;
public:

	ServerTable(int nTableID, char* sName, TCASH fStake
		, CallBackFunc2Params *pCallBackTableSend1  = NULL
		, CallBackFunc6Params *pCallBackTableSend2  = NULL
		, CallBackFuncBuf  *pCallBackTableSend3  = NULL
		, CallBackFunc2Params *pCallBackPlayerSend1 = NULL
		, CallBackFunc6Params *pCallBackPlayerSend2 = NULL
		, CallBackFuncBuf  *pCallBackPlayerSend3  = NULL
		, CallBackChangeCash *pCallBackChangeCash = NULL
		, CallBackHistory *pCallBackHistory = NULL
		, CallBackKickOut *pCallBackKickOut = NULL
		, CallBackLog *pCallBackLog = NULL
		);

	virtual ~ServerTable(void);
public:
	enum {
		KICK_TIME_OUT,
		KICK_NOT_ENOUGH_MONEY,
	};
};


};
