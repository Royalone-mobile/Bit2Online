
/*	
	About format of packet parameter
	b: 1Byte
	w: 2Byte
	d: 4Byte
	q: 8Byte
	s: string
	u: Unicode string

	prefix : M_CS -> From client to server
	prefix : M_SC -> From server to client
*/
enum
{
	M_CS_VERSION				= 1,			//[d:Version][s:Version]
	M_SC_VERSION_OK,
	M_SC_VERSION_FAILED,						//[d:ErrorCode]
	
	M_SC_WEB_SERVER_ADDRESS		= 10,			//[s:WebServerAddress]
	M_SC_BUY_SERVER_ADDRESS		= 20,			//[s:BuyChipServerAddress]

	M_CS_LOGIN 					= 100,			//[s:ID] [s:password]
	M_SC_LOGIN_OK				= 101,			//[d:DBID][s:Name][f:Cash][w:CharacterID][d:Ranking][s:CharacterURL]
	M_SC_LOGIN_FAILED			= 102,			//[d:ErrorCode]

	M_CS_CREATEACCOUNT			= 103, 			//[s:UserID][s:UserPwd][w:CharacterID][s:Email]
	M_SC_CREATEACCOUNT_OK		= 104,			//[d:DBID]
	M_SC_CREATEACCOUNT_FAILED	= 105,			//[d:ErrorCode]
	
	M_SC_GROUPLIST				= 106,			//[d:listSize][[d:GroupType][s:GroupName][f:MinStake][f:MaxStake][d:PlayerCount]]
	M_SC_TABLELIST				= 107,			//[d:listSize][[d:TableID][s:TableName][f:Stake][d:MaxPlayer][d:CurPalyer][d:CreateUserDBID]]

	M_CS_LOBBY_ASK_TABLEINFO	= 111,			//[d:TableID]
	M_SC_LOBBY_TABLEINFO		= 112,			//[d:TableID][d:MaxPlayerCount][d:CurPlayerCount][[b:Pos][d:PlayerID][s:PlayerName][f:cash][w:CharacterID][s:CharacterIDURL]]
	M_SC_LOBBY_ASK_FAILED		= 113,			//[d:ErrorCode]

	M_CS_LOBBY_FIND_BUDDY		= 114,			//[s:BuddyEmail]
	M_CS_LOBBY_FIND_USER		= 114,			//[s:BuddyEmail]

	M_SC_LOBBY_FIND_BUDDY		= 115,			//[d:ListSize][[s:buddyID][b:bOnline]]
	M_SC_LOBBY_FIND_USER		= 115,			//[d:ListSize][[s:buddyID][b:bOnline]]

	M_CS_CREATETABLE			= 120, 			//[s:TableName][f:Stake][d:maxPlayer]
	M_SC_CREATETABLE_OK			= 121,			//[d:TableID]
	M_SC_CREATETABLE_FAILED		= 122,			//[d:ErrorCode]
	
	M_SC_UPDATE_TABLELIST		= 123,			//[d:listSize][[d:TableID][s:TableName][f:Stake][d:MaxPlayer][d:CurPalyer][d:CreateUserDBID]]
	M_SC_TABLE_REMOVE			= 124,			//[d:TableCount][[d:TableID]]
	
	M_CS_JOIN					= 201,			//[d:TableID][b:Pos]
	M_SC_JOIN_OK				= 202,			//[d:OwnPos]
	M_SC_JOIN_FAILED			= 203,			//[d:ErrorCode]

	M_CS_VIEW					= 204,			//[d:TableID]
	M_SC_VIEW_OK				= 205,
	M_SC_VIEW_FAILED			= 206,
	
	M_CS_STANDUP				= 207,	
	
	M_SC_TABLE_TABLEINFO		= 401,			//[d:TableID][s:TableName][f:Stake][d:MaxPlayer]
												//[d:PlayerCount][[b:Pos][d:PlayerID][s:PlayerName][b:CharID][s:CharacterIDURL][f:Money]]
	
	M_SC_TABLE_SIT				= 402,			//[b:Pos][d:PlayerID][s:PlayerName][b:CharID][s:CharacterIDURL][f:Money]
	
	/*M_SC_TABLE_DEAL				= 403,			//[b:CardCount][[b:CardID]]*/

	M_SC_TABLE_STARTGAME		= 404,			//[d:FirstPlayerSeatID][d:cardCount][[c:card]]

	M_CS_TABLE_ACTION			= 405,			//[d:cardCount][[b:card]]
	M_SC_TABLE_ACTION			= 406,			//[d:PlayerID][d:cardCount][[b:card]]

	M_SC_TABLE_FINISHGAME		= 407,			//[d:winner][fWinnerEarnMoney][PlayerCount][[PlayerName][f:EarnMoney]]
	
	M_CS_TABLE_LEAVE			= 408,
	M_SC_TABLE_LEAVE			= 409,			//[d:SeatID]

	/*M_SC_TABLE_READY			= 410,			//[d:PlayerID][b:IsReady]*/
	/*M_CS_TABLE_READY			= 411,			//[b:IsReady]*/
	/*M_CS_TABLE_GO				= 412,*/
	
	M_CS_TABLE_ASK_LOBBYUSERS	= 420,
	M_SC_TABLE_LOBBYUSERS		= 421,			//[[d:PlayerCount][d:PlayerID][s:PlayerName]]
	
	M_CS_TABLE_INVITE			= 430,			//[d:playerID]
	M_SC_LOBBY_ACCEPT_INVITE,					//[d:InviteeID]
	M_SC_LOBBY_REJECT_INVITE,					//[d:InviteeID]
	M_SC_TABLE_INVITE_FAILED,					//[d:ErrorCode]
	
	M_SC_TABLE_INVITE			= 440,			//[d:TableID][d:InviterID][s:InviterName]
	M_CS_LOBBY_ACCEPT_INVITE	= 441,			//[d:TableID][d:InviterID]
	M_CS_LOBBY_REJECT_INVITE	= 442,			//[d:TableID][d:InviterID]

	M_CS_TABLE_CHAT				= 450,			//[s:Chat string]
	M_SC_TABLE_CHAT,							//[s:From][s:Chat string]

	/*M_SC_TABLE_MASTER,							//[d:TableMasterID]*/
	
	M_SC_TABLE_TABLEINFO_VIEW	= 460,			//[d:TableID][s:TableName]/*[d:MasterID]*/[d:state][d:SeatCount][d:CurPlayerCount][d:FirstPlayerSeatID][d:CurPlayerSeatID][d:raiseCount][d:riaserSeatID]
												//[f:smallBlind][f:bigBlind][f:PotMoney][f:MaxMoney][d:MaxCardCount][d:CurCardCount]
												//[[d:Pos][d:PlayerID][d:bAuto][s:PlayerName][d:characterID][s:CharacterIDURL][f:EmployedMoney][f:MoneyInhand][d:selectedAciton]/*[d:ready]*/[d:MaxCardCount][d:nCurCardCount][[c:card]]]
	
	M_SC_TABLE_OBSERVER_LIST	= 470,			//[d:ObserverCount][[s:observerName]]
	M_SC_TABLE_OBSERVER_UPDATE	= 471,			//[s:observername]
	M_SC_TABLE_OBSERVER_REMOVE	= 472,			//[s:observername]
	
	M_CS_LOGOUT					= 900,

	M_SC_FORCE_LOGOUT,							//[d:ErrorCode]

	M_CS_DELETE,

	M_SC_BONUS					=800,			//[d:BonusAccount]					

	M_CS_PING					= 910,
	M_SC_PING,									

	M_CS_TEST					= 1000,			//[d:TestValue]
	M_SC_TEST					= 1001,			//[d:TestValue]

	M_CS_PlAYNOW				= 1010,			

	M_CS_FORGOT_PWD				= 1020,			//[s:ID][s:Email]
	M_SC_FORGOT_PWD_OK,							
	M_SC_FORGOT_PWD_FAILED,						//[d:ErrorCode]

	M_CS_BUY_CASH				=1030,			//[f:cash]
	M_SC_BUY_CASH_OK,
	M_SC_BUY_CASH_FAILED,

	// Facebook related
	M_CS_FACEBOOK_LOGIN 		= 1100,			//[s:Facebook uid][s:Facebook Name][s:Facebook Email][s:FaceBook PicURL]
	M_SC_FACEBOOK_LOGIN_OK,						//[d:DBID][s:Name][f:Cash][w:CharacterID][d:Ranking]

	
	// friend related
	M_CS_FACEBOOK_FRIENDS		= 1200,			//[[s:Facebook Name]]
	M_SC_FRIENDS,								//[[d:DBID][s:UserID][w:character_id][s:character_id_URL][b:online]]
	M_SC_FRIENDS_UPDATE,						//[[d:DBID][s:UserID][w:character_id][s:character_id_URL][b:online]]
	M_SC_FRIENDS_CHANGE,						//[[d:DBID][s:UserID][w:character_id][s:character_id_URL][b:online]]

	M_CS_ASK_PLAYER_INFO,						//[d:PlayerID]
	M_SC_ASK_INFO_FAILED,						//[d:PlayerID][d:errorCode]
	M_SC_PLAYER_INFO,							//[d:PlayerID][d:total][d:win][d:Ranking]

	M_CS_TABLE_FRIEND			= 1210,			//[d:FriendID]
	M_SC_TABLE_ACCEPT_FRIEND,					//[d:FriendID][s:character_id_URL]
	M_SC_TABLE_REJECT_FRIEND,					//[d:FriendID]
	M_SC_TABLE_FRIEND_FAILED,					//[d:error_code]

	M_SC_TABLE_FRIEND			= 1220,			//[d:playerID][s:playerName]
	M_CS_TABLE_ACCEPT_FRIEND,					//[d:playerID]
	M_CS_TABLE_REJECT_FRIEND,					//[d:playerID]

	M_CS_RANKING				= 1230,				
	M_SC_RANKING,								//[d:count][[d:No][d:DBID][s:UserName][w:character_id][s:character_id_URL][f:cash]]
													//[d:count][[d:No][d:DBID][s:UserName][w:character_id][s:character_id_URL][f:cash]]

	M_CS_CHANGE_CHARACTER		= 1240,			//[w:characterID][s:CharacterURL]:characterURL is valid, if the characterID is PERSONAL_CH_ID.
	M_SC_CHANGE_CHARACTER_OK,					//[w:characterID][s:CharacterURL]:characterURL is valid, if the characterID is PERSONAL_CH_ID.

	M_CS_GIVE_CASH				= 1250,			//[d:RecevieID][f:cash]
	M_SC_GIVE_CASH_OK,							//[s:ReceiveName][f:cash]
	M_SC_RECEIVE_CASH,							//[d:SendID][s:SendName][f:cash][d:ReceiveID]

	M_CS_CHANGE_NAME			= 1260,			//[s:Name]
	M_SC_CHANGE_NAME_OK,						//[s:Name]
	M_SC_CHANGE_NAME_FAILED,					//[d:ErrorCode]
	
	M_SC_MEMO					= 1270,			//[d:count][[d:memoType][d:param1][d:param2][f:param3][s:param4]]

	M_CS_FRINED_INFO			= 1280,			//[d:friendID]
	M_SC_FRIEND_INFO,							//[d:friendID][s:friendName][d:tableID]

	M_SC_KICKOUT_OVER_TIME		= 1290,			//[s:kickedName]
	M_SC_KICKOUT_NOT_MONEY,						//[s:kickedName]

	// SYSTEM related
	M_SC_SYSTEM_ERR				= 5000,			//[d:ErrorCode]

	// Upload Server related
	M_US_AUTH_USER				= 7000,			//[d:UserIndex][d:AuthKey][s:filenameToUpload]
	M_SU_AUTH_USER_OK,
	M_SU_AUTH_USER_FAILED,

	M_CS_TO_UPLOAD				= 7010,			//[s:fileName];
	M_SC_TO_UPLOAD,								//[d:AuthKey];

	// Buy Server related
	M_BS_BUY_CHIP				= 8000,			//[d:UserIndex][f:chip]

	// GM related
	M_CS_GM_LOGIN				= 10000,		//[s:ID] [s:password]
	M_SC_GM_LOGIN_OK,							//[d:DBID]
	M_SC_GM_LOGIN_FAILED,						//[d:ErrorCode]

	M_SC_GM_USERLIST,							//[d:ListSize][[d:dbid][s:name][f:cash][w:characterID][d:state][d:table_id]]
	M_SC_GM_UPDATE_USERLIST,					//[d:ListSize][[d:dbid][s:name][f:cash][w:characterID][d:state][d:table_id]]
	M_SC_GM_USER_REMOVE,						//[d:ListSize][d:dbid]

	M_CS_GM_OUTUSER,							//[d:DBID]
};
