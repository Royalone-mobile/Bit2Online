#ifndef __ACCOUNT_SCENE_H__
#define __ACCOUNT_SCENE_H__

#include "cocos2d.h"
#include "Global.h"
#include "AppDelegate.h"
#include "cocos-ext.h"
#include "extensions/cocos-ext.h"
#include "network/HttpClient.h"

using namespace cocos2d;
class AccountScene : public cocos2d::Layer,public cocos2d::ui::EditBoxDelegate
{
public:
    static cocos2d::Scene* createScene();
	
    virtual bool init();
   
	Sprite *			pSpriteBack;

	CCLabelTTF *m_pUserNameLabel;
	CCLabelTTF *m_pCurBalanceLabel;

	void menuCallbackHandler(Ref * pSender);

	void drawImages();
	void drawButtons();
    void drawLabels();
    void initTextFields();
    

	void registerUser();
    // implement the "static create()" method manually
	CREATE_FUNC(AccountScene);
private:
    ui::EditBox*			useremail;
    ui::EditBox*            password;
    ui::EditBox*            confirmPassword;
    ui::EditBox*            username;
	void onHttpRequestCompleted(cocos2d::network::HttpClient *sender, cocos2d::network::HttpResponse *response);
    virtual void editBoxEditingDidBegin(cocos2d::ui::EditBox* editBox)override;
    virtual void editBoxEditingDidEnd(cocos2d::ui::EditBox* editBox)override;
    virtual void editBoxTextChanged(cocos2d::ui::EditBox* editBox, const std::string& text)override;
    virtual void editBoxReturn(cocos2d::ui::EditBox* editBox)override;
    
	CCSprite*	m_pCharactImage[MAX_CHA_IMAGE_COUNT];
	CCMenuItem*	m_pLoginBtn;
	CCLabelTTF*	m_pChaImgIndexLabel;
	int		m_nChaImgNumber;
	float		m_fMove;

};

#endif // __ACCOUNT_SCENE_H__
