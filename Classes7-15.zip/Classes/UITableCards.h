#ifndef __WELCOME_SCENE_H__
#define __WELCOME_SCENE_H__

#include "cocos2d.h"
#include "TableScene.h"
#include <Global.h>


using namespace cocos2d;

struct PlayerCard
{
	char playerCards[CARD_COUNT_PER_PLAYER];
	bool selected[CARD_COUNT_PER_PLAYER];
	CCSprite*	ctrlPlayerCards[CARD_COUNT_PER_PLAYER];
	char tableCards[MAX_CARD_COUNT];
	CCSprite*	ctrlTableCards[CARD_COUNT_PER_PLAYER];

	int nPlayerCardCount;
	int nTableCardCount;
	PlayerCard();
	~PlayerCard() {};
};


class CardManager : public cocos2d::Layer

{
public:
    static cocos2d::Scene* createScene();

    virtual bool init();
	CardManager(void) {};
	~CardManager(void) {};
	void menuCallbackHandler(Ref * pSender);
	
	void initCardManager(TableScene * pParent);
	void clearCardManager();
	void setSelectable(bool bSelectable);
	void setTableCards(int nID, char *cards, int nCardCount);
	PlayerCard* getPlayer(int nID);
	void setCardCount(int nID, int nCardCount);
	int getCardCount(int nID);
	char* getCards(int nID);
	void setCards(int nID, const char * cards);
	char getCard(int nID, int nCardID);
	void drawPlayerCards(int nID);
	void drawTableCards(int nID);
	void drawClickedCard(int nCardID);
	void refreshSelect();
	void click(int nCardID);
	int getCardPos(int nPlayerPos, int nCardID);
	int getCardID(int nPlayerPos, int nCardPos);

	bool isSelected(int nID, int nCardID);


	void addEvents();
	void touchEvent(cocos2d::Touch* touch);
    
    void setParent(TableScene *m_pParent);
    // implement the "static create()" method manually
    CREATE_FUNC(CardManager);
private:
	TableScene* m_pParent;
	CCSprite*  m_FrontCards[CARD_COUNT];
	CCSprite*	m_BackCards[CARD_COUNT];
	PlayerCard m_player[MAX_PLAYER_COUNT];
	bool		m_bSelectable;
};

#endif // __WELCOME_SCENE_H__
