#ifndef __VIEWMENU_H__
#define __VIEWMENU_H__

#include "cocos2d.h"
#include "Global.h"
#include "AppDelegate.h"

class TableScene;


using namespace cocos2d;
class MenuLayer: public cocos2d::Layer

{
public:
	CCMenuItemLabel*			m_pSitOutBtn;
	CCMenuItemLabel*			m_pStandUpBtn;
	CCMenuItemLabel*			m_pSettingsBtn;
	CCMenuItemLabel*			m_pMainMenuBtn;
	CCMenuItemLabel*			m_pFindUserBtn;
	
	TableScene*					m_pParent;

	void onSitout();
	void onStandUp();
	void onSetting();
	void onMainMenu();
	void onFindUser();
	void closeAllSubWindows();
	void setParent(TableScene *pParent);
	void setStandUp(bool bStandUp);

public:
    virtual bool init();
	void drawImages();
	void drawButtons();
	void menuCallbackHandler(Ref * pSender);
	static Scene* createScene();
	CREATE_FUNC(MenuLayer);
private:
    CCSprite *pSpriteBack;
};

#endif




