//
//  TextureManager.mm
//  Big2_cc
//
//  Created by SIP on 8/19/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#include "TextureManager.h"

TextureManager	g_TextureManager;

TextureManager::TextureManager() {
	
	TextureRect trt;
	
	for (int i = 0; i < 8; i++) {
		for (int j = 0; j < 7; j++) {
			int nCardId = i + j * 8;
			if (nCardId < 53) {
				trt.rt[DEVICE_IPHONE] = CCRectMake(i * 49, 73 * j, 48, 72);
				trt.rt[DEVICE_IPAD] = CCRectMake(i * 96, 144 * j, 95, 143);
				trt.rt[DEVICE_IPHONE4] = CCRectMake(i * 48, 72 * j, 48, 72);
				m_TextureRect[Pic_Table_card1 + i + j * 8] = trt;
			}			
		}
	}
	
	trt.rt[DEVICE_IPHONE] = CCRectMake(392, 0, 80, 120);
	trt.rt[DEVICE_IPAD] = CCRectMake(768, 785, 159, 240);
	trt.rt[DEVICE_IPHONE4] = CCRectMake(384, 392, 80, 120);
	m_TextureRect[Pic_Table_Pan_Menu] = trt;
	
//	trt.rt[DEVICE_IPHONE] = CCRectMake(375, 438, 80, 24);
	trt.rt[DEVICE_IPHONE] = CCRectMake(376, 438, 80, 24);
	trt.rt[DEVICE_IPAD] = CCRectMake(768, 385, 160, 40);
	trt.rt[DEVICE_IPHONE4] = CCRectMake(386, 192, 80, 22);
	m_TextureRect[Pic_Table_Btn_Menu0] = trt;
	
	trt.rt[DEVICE_IPHONE] = CCRectMake(376, 467, 80, 24);
	trt.rt[DEVICE_IPAD] = CCRectMake(768, 424, 160, 40);
	trt.rt[DEVICE_IPHONE4] = CCRectMake(387, 221, 80, 22);
	m_TextureRect[Pic_Table_Btn_Menu1] = trt;
	
	trt.rt[DEVICE_IPHONE] = CCRectMake(392, 242, 80, 24);
	trt.rt[DEVICE_IPAD] = CCRectMake(768, 464, 160, 40);
	trt.rt[DEVICE_IPHONE4] = CCRectMake(386, 137, 80, 22);
	m_TextureRect[Pic_Table_Btn_Friend0] = trt;
	
	trt.rt[DEVICE_IPHONE] = CCRectMake(393, 268, 80, 24);
	trt.rt[DEVICE_IPAD] = CCRectMake(768, 503, 160, 40);
	trt.rt[DEVICE_IPHONE4] = CCRectMake(387, 163, 80, 22);
	m_TextureRect[Pic_Table_Btn_Friend1] = trt;
	
	trt.rt[DEVICE_IPHONE] = CCRectMake(392, 141, 76, 23);
	trt.rt[DEVICE_IPAD] = CCRectMake(768, 196, 151, 46);
	trt.rt[DEVICE_IPHONE4] = CCRectMake(384, 30, 76, 24);
	m_TextureRect[Pic_Table_Btn_Ok0] = trt;
	
	trt.rt[DEVICE_IPHONE] = CCRectMake(392, 166, 76, 23);
	trt.rt[DEVICE_IPAD] = CCRectMake(768, 243, 151, 46);
	trt.rt[DEVICE_IPHONE4] = CCRectMake(384, 54, 76, 24);
	m_TextureRect[Pic_Table_Btn_Ok1] = trt;
	
	trt.rt[DEVICE_IPHONE] = CCRectMake(294, 438, 76, 23);
	trt.rt[DEVICE_IPAD] = CCRectMake(485, 864, 151, 46);
	trt.rt[DEVICE_IPHONE4] = CCRectMake(242, 432, 76, 24);
	m_TextureRect[Pic_Table_Btn_Ok2] = trt;
	
	trt.rt[DEVICE_IPHONE] = CCRectMake(392, 191, 76, 23);
	trt.rt[DEVICE_IPAD] = CCRectMake(768, 291, 151, 46);
	trt.rt[DEVICE_IPHONE4] = CCRectMake(384, 78, 76, 24);
	m_TextureRect[Pic_Table_Btn_Pass0] = trt;
	
	trt.rt[DEVICE_IPHONE] = CCRectMake(392, 216, 76, 23);
	trt.rt[DEVICE_IPAD] = CCRectMake(768, 338, 151, 46);
	trt.rt[DEVICE_IPHONE4] = CCRectMake(384, 102, 76, 24);
	m_TextureRect[Pic_Table_Btn_Pass1] = trt;
	
	trt.rt[DEVICE_IPHONE] = CCRectMake(294, 466, 76, 23);
	trt.rt[DEVICE_IPAD] = CCRectMake(485, 913, 151, 46);
	trt.rt[DEVICE_IPHONE4] = CCRectMake(242, 457, 76, 24);
	m_TextureRect[Pic_Table_Btn_Pass2] = trt;
	
	trt.rt[DEVICE_IPHONE] = CCRectMake(473, 0, 22, 22);
	trt.rt[DEVICE_IPAD] = CCRectMake(950, 101, 43, 43);
	trt.rt[DEVICE_IPHONE4] = CCRectMake(475, 50, 22, 22);
	m_TextureRect[Pic_Table_Btn_sit] = trt;
	
	trt.rt[DEVICE_IPHONE] = CCRectMake(457, 442, 55, 70);
	trt.rt[DEVICE_IPAD] = CCRectMake(914, 570, 110, 150);
	trt.rt[DEVICE_IPHONE4] = CCRectMake(457, 285, 55, 75);
	m_TextureRect[Pic_Table_Pan_Waitting] = trt;
	
	trt.rt[DEVICE_IPHONE] = CCRectMake(392, 292, 71, 83);
	trt.rt[DEVICE_IPAD] = CCRectMake(768, 543, 141, 165);
	trt.rt[DEVICE_IPHONE4] = CCRectMake(384, 271, 71, 83);
	m_TextureRect[Pic_Table_Pan_Player] = trt;
	
	trt.rt[DEVICE_IPHONE] = CCRectMake(245, 438, 41, 29);
	trt.rt[DEVICE_IPAD] = CCRectMake(950, 0, 68, 42);
	trt.rt[DEVICE_IPHONE4] = CCRectMake(470, 75, 41, 29);
	m_TextureRect[Pic_Table_Btn_Chat0] = trt;
	
	trt.rt[DEVICE_IPHONE] = CCRectMake(245, 471, 41, 29);
	trt.rt[DEVICE_IPAD] = CCRectMake(950, 48, 68, 42);
	trt.rt[DEVICE_IPHONE4] = CCRectMake(470, 105, 41, 29);
	m_TextureRect[Pic_Table_Btn_Chat1] = trt;
	
	trt.rt[DEVICE_IPHONE] = CCRectMake(392, 376, 68, 26);
	trt.rt[DEVICE_IPAD] = CCRectMake(768, 0, 135, 51);
	trt.rt[DEVICE_IPHONE4] = CCRectMake(384, 0, 68, 26);
	m_TextureRect[Pic_Table_Chat_Ballon] = trt;
	
	trt.rt[DEVICE_IPHONE] = CCRectMake(392, 403, 79, 28);
	//trt.rt[DEVICE_IPHONE] = CCRectMake(0, 403, 79, 28);
	trt.rt[DEVICE_IPAD] = CCRectMake(768, 725, 157, 56);
	trt.rt[DEVICE_IPHONE4] = CCRectMake(384, 362, 79, 28);
	m_TextureRect[Pic_Table_Img_Win] = trt;
}

TextureManager::~TextureManager() {
	m_TextureRect.clear();
}

void TextureManager::setDeviceType(int nDevType)
{
	m_nDeviceType = nDevType;
}

CCRect TextureManager::getTextureRect(int nObjName)
{
	TTextureRect::iterator it = m_TextureRect.find(nObjName);
	if (it != m_TextureRect.end()) {
		return it->second.rt[m_nDeviceType];
	}
	return CCRect::ZERO;
}