#ifndef _NETCOMMON_H
#define _NETCOMMON_H

#define MAX_GROUP_COUNT 10

#define CARD_COUNT 52
#define CARD_NUMBER_COUNT 13
#define CARD_COUNT_PER_PLAYER 13
#define SEAT_COUNT 4

#define SUIT_COUNT	4

#define MAX_USERNAME_LEN	256
#define MAX_USERPWD_LEN		16
#define MAX_USERCHIDURL_LEN	256	
#define MAX_PLAYER_COUNT	4
#define MAX_CARD_COUNT		5

#define TIME_ACTION_DELAY	20
#define MAX_PLAYERS			4
#define MAX_TABLE_COUNT		500

#define MAX_GROUPNAME_LEN	16
#define MAX_TABLENAME_LEN	16
#define MAX_CHAT_LEN		128

#define TIME_START_GAME_DELAY	9

#define TIME_CHECK_ALIVE_INTERVAL	2	//seconds
#define TIME_CHECK_ALIVE_LIMIT		15	//seconds

#define TCASH				double
#define TID					unsigned long
#define TPOS				unsigned char
typedef	unsigned long long int	uint64;

#define INVALID_ID			0
#define	DEFAULT_POS_ID		255
#define	FACEBOOK_CH_ID		100			// Character ID of facebook account
#define PERSONAL_CH_ID		110			// personal Character ID
#define	APP_ID				"big2"		// app ID of facebook account
#define FACEBOOK_PWD		"facebookPassword"		// default facebook password
#define FACEBOOK_EMAIL		"facebook@hotmail.com"	//default facebook email

#define WSTR_BUF(buf, len) unsigned short buf[len+1]; buf[0] = (len + 1) * 2;
#define ASTR_BUF(buf, len) char  buf[len+2]; *((short*)&buf[0]) = len + 2;

enum MemoType
{
	MEMO_RECEIVE_CHIP = 1
};

#define CUR_VERSION			"1.0.4"
#define STRING_VERSION			200

#endif // _NETCOMMON_H
