/*
 *  Netlogic.h
 *  Showhand
 *
 *
 */

#ifndef _NET_LOGIC_H_
#define _NET_LOGIC_H_

#include <map>
#include <vector>
#include <list>
#include "Common.h"
#include "NetCommon.h"
#include "GameTable.h"
#include "Global.h"
#include "Player.h"

#define GAME_PORT	33333




struct MEMO_T
{
	int nMemoType;
	int nParam1;
	int nParam2;
	TCASH fParam3;
	char sParam4[256];
};
typedef std::list<MEMO_T> TMemoList;
extern TMemoList g_MemoList;

struct USER_INFO_T {
	TID			m_UserDBID;
	char		m_UserID[MAX_USERNAME_LEN];
	char		m_PWD[MAX_USERPWD_LEN];
	TCASH		m_nUserCash;
	short		m_nCharacterID;			
	int			m_nRanking;
};

struct GAMERESULT_T
{
	char		m_UserName[MAX_USERNAME_LEN];
	TCASH		m_fCash;
};
typedef std::vector<GAMERESULT_T> TGameResult;
extern TGameResult g_GameResult;
typedef std::map<TID, USER_INFO_T> TRegisterList;
extern TRegisterList		m_SendRequestList;
extern TRegisterList		m_ReceiveRequestList;

struct	PLAYER_INFO_T
{
	char	szName[MAX_USERNAME_LEN];
	short	character_id;
	char	szChUrl[MAX_USERCHIDURL_LEN];
	TCASH	cash;
	int		nPos;
	int		nTotalCount;
	int		nWinCount;
	PLAYER_INFO_T()
	:character_id(0)
	,cash(0)
	,nPos(0)
	,nTotalCount(0)
	,nWinCount(0)
	{
		szName[0] = 0;
		szChUrl[0] = 0;
	}
};

typedef std::map<TID, PLAYER_INFO_T>	TPlayerList;

struct	TABLE_INFO_T
{
	TID		table_id;
	char	szName[MAX_TABLENAME_LEN];
	int		nMaxPlayer;
	int		nCurPlayerCount;
	TCASH	stake;
	TPlayerList	players;
	TID		nCreaterID;
	
	TABLE_INFO_T()
	:table_id(0)
	,nMaxPlayer(0)
	,nCurPlayerCount(0)
	,stake(0.0f)
	,nCreaterID(0)
	{
		szName[0] = 0;
	}
};

struct INVITE_INFO_T	
{
	TID		nTableID;
	TID		nGroupType;
	TID		nUserID;
	char	szUserName[MAX_USERNAME_LEN];
};

typedef std::vector<INVITE_INFO_T>	TNameList;
typedef std::vector<USER_INFO_T>	TWinnerList;
typedef std::vector<TCASH>			TStakeList;
typedef std::vector<TID>			TTIDVector;

extern  TTIDVector					m_nTableIDList;

//typedef std::map<TID, GROUP_INFO_T>	TGroupList;
typedef std::map<TID, TABLE_INFO_T>	TTableList;

struct FRIEND_INFO_T
{
	char	szFriendName[MAX_FRIENDNAME_LEN];
	char	szFriendID[MAX_FRIENDID_LEN];
	char	szFriendPhoto[MAX_FRIENDPHOTO_LEN];
	short	nCharacterID;
	bool	bOnline;
	TID		nFriendDBID;
};

typedef std::vector<FRIEND_INFO_T>	TFriendList;
extern TFriendList		m_OnlineFriendList;
extern TFriendList		m_OfflineFriendList;

struct RANKING_INFO_T {
	int		nNo;
	short	nCharID;
	char	szChUrl[MAX_FRIENDPHOTO_LEN];
	TID		nDBID;
	char	szName[MAX_USERNAME_LEN];
	TCASH	fCash;
};

typedef std::vector<RANKING_INFO_T>	TRankingList;
extern TRankingList		m_TopRankingList;
extern TRankingList		m_MyRankingList;

struct FINDUSER_INFO_T	
{
	TID nUserDBID;
	char szName[MAX_EMAILADDR_LEN];
	bool bOnline;
};
typedef std::vector<FINDUSER_INFO_T>	TFindUserList;
extern TCASH nMinBetValue[MIN_BET_COUNT];
extern TFindUserList		m_FindUserList;

typedef void	(*TRecvCallback)(TNotifyRecv pkt, uint64 wParam, uint64 lParam);

void	NetLogic_log(int nLogLevel,const char * szFormat, ...);

bool	NetLogic_init(const char* szaddr);
void	NetLogic_release();
void	NetLogic_update(double cur_time);
	
bool	NetLogic_loginToServer(const char* szID, const char* szPWD);
void	NetLogic_disConnect(bool bNormal = false);

bool	NetLogic_send();
bool	NetLogic_isReceived();
bool	NetLogic_readPacket();

void	NetLogic_SetRecvCallback(TRecvCallback cb);
void	NetLogic_onReceive(int pktid, const void* pData, int nDataLen);

void	NetLogic_ArrangeTable(int nArrangeby, bool bAscending);
bool	NetLogic_RemoveTableIDFromIndex(TID tid);

TUserState	NetLogic_GetUserState();
void	NetLogic_SetUserState(TUserState state);
void NetLogic_StartGame();


int		NetLogic_GetTableCount();
TABLE_INFO_T &	NetLogic_GetTableFromIndex(int n);
TABLE_INFO_T &	NetLogic_GetTableFromID(TID id);


USER_INFO_T &	NetLogic_GetUserInfo();
void NetLogic_SetUserCash(TCASH cash);

INVITE_INFO_T& NetLogic_GetInvitedInfo();


bool	NetLogic_SendPlayNow();

bool	NetLogic_SendCreateTable(char* tname, TCASH stake, int maxplayer);
bool	NetLogic_SendJoinTable(TID tableid, int nPos);
bool	NetLogic_SendStandUp();

bool	NetLogic_SendViewTable(TID tableid);
bool	NetLogic_SendLeaveTable();
bool	NetLogic_SendCreateAccount(char* ch_name, char* ch_pwd, short ch_id, char* ch_Email);
bool	NetLogic_SendAskTableInfoAtLobby(TID table_id);
bool	NetLogic_SendForgetPassword(const char* ch_EmailAddr);
bool	NetLogic_SendAskPlayerInfo(TID nFriendDBID);
bool	NetLogic_SendRegisterFriend(TID nFriendDBID);
bool	NetLogic_SendAcceptRegisterFriend(TID nFriendDBID);
bool	NetLogic_SendRejectRegisterFriend(TID nFriendDBID);

//Invite
bool	NetLogic_SendAskLobbyUsers();
int		NetLogic_GetPlayerCountInLobby();
bool	NetLogic_SendAskInvite(TID nPlayerID);

bool	NetLogic_SendAcceptInvite(TID nTableID, TID nInviterID);
bool	NetLogic_SendRejectInvite(TID nTableID, TID nInviterID);


bool	NetLogic_SendPlayerReady(bool bIsReady);
bool	NetLogic_SendGo();

bool	NetLogic_SendPlayerAction(int PlayerID, const char* cards, unsigned long nCardCount);
bool	NetLogic_SendTableChat(char* chat_str);
bool	NetLogic_SendFindUser(const char* buddy);
bool	NetLogic_SendBuyCash(TCASH fCash);

GE::GameTable& NetLogic_GetGameTable();
int		NetLogic_GetSeatID();
void	NetLogic_SetSeatID(int nSeatID);
TID		NetLogic_GetPlayerID();
bool	NetLogic_loginToServerFB(const char* szFBName, const char* szFBUID, const char* szPicURL, const char* szEmail);
bool	NetLogic_SendFriendList();
bool	NetLogic_SendTestLocalStartGame();
bool	NetLogic_SendChangeAvatar(TID nCharID, const char *szPhotoName);
bool	NetLogic_SendChangeName(const char *szName);
bool	NetLogic_SendAskRankingInfo();
bool	NetLogic_SendChipsToFriend(TID nFriendDBID, TCASH fCash);
bool	NetLogic_SendAskFriendInfo(TID nFriendDBID);
bool	NetLogic_IsMyFriend(TID nDBID);
bool	NetLogic_SendVersion(const char *szVersion);
void    NetLogic_SetVersion(const char *szVersion);
char*   NetLogic_GetVersion();
void    NetLogic_SendReqUpload(const char *szFileName);



void NetLogic_Sit(int pos, GE::Player player);

#endif
