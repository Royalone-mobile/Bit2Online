#include "VServer.h"
#include "packet.h"
#include "NetLogic.h"

TID RequestRegisterID;

static void SendtoPlayer(int ID, int pktID, void* buf, unsigned int size)
{
	NetLogic_onReceive(pktID, buf, size);
}

VServer::VServer(void)
:m_pServerTable(0)
{
	m_pFuncSendtoPlayer = &SendtoPlayer;
}

VServer::~VServer(void)
{
	SAFE_DELETE(m_pServerTable);
}

void VServer::createTable(TCASH fStake)
{
	SAFE_DELETE(m_pServerTable);
	char szTableName[] = "ServerTable";
	m_pServerTable = new GE::ServerTable(1, szTableName, fStake);
	m_pServerTable->setCallbackFunc(NULL, NULL, m_pFuncSendtoPlayer, NULL, NULL, m_pFuncSendtoPlayer);

	for( int i = 0 ; i < SEAT_COUNT - 2; i++)
	{
		char sPlayerName[MAX_USERNAME_LEN];
		sprintf(sPlayerName, "Player%d", i+ 1 );
		char sChUrl[2] = "";
		GE::Player player(i+4, i, sChUrl, sPlayerName, 1000);
		m_pServerTable->sit(i+1,player);
	}
}

void VServer::update(unsigned int nTime)
{
	if ( m_pServerTable )
	{
		if (m_pServerTable->isPlaying()) {
			int nSeatID = m_pServerTable->getCurPlayerSeatID();
			if (nSeatID != 0) {
				GE::Action action;
				int nPlayerID = m_pServerTable->getPlayerfromSeatID(nSeatID)->getPlayerID();
				m_pServerTable->updateAutoPlayer(nPlayerID, action );
				m_pServerTable->setAction(nPlayerID, action.Cards, action.nCardCount);
			}
		}
		
		m_pServerTable->update(nTime);
	}
}

void VServer::recvPacket(TID nPlayerID, int pktID, void* pData, unsigned int size)
{
	m_pServerTable->onNotifyReceive(nPlayerID,pktID, pData, size);
}