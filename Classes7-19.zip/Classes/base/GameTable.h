﻿#pragma once
#include <stdlib.h>
#include <memory.h>
#include "Player.h"
#include <vector>
#ifdef MAKEWPARAM
#undef MAKEWPARAM
#endif
#define MAKEWPARAM(l, h)      l & 0xffff | h & 0xffff << 16

namespace GE {

class GameTable;
typedef void (*Callbackfunc)(GameTable* pGameTable, EngineEvent event, uint64 wParam , uint64 lParam);
typedef void	(*Callbacklog)(char* buf);
	
struct ResultData 
{
	bool	m_bSeatsState;
	TID		m_nPlayerID;

	//name of player
	char	m_sName[MAX_USERNAME_LEN];

	//earn Money
	TCASH	m_fEarnMoney;

	ResultData()
	{
		m_bSeatsState = false;
		m_nPlayerID = INVALID_ID;

		strcpy(m_sName, "");
		m_fEarnMoney = 0.0;
	}

	ResultData(const ResultData &other)
	{
		operator =(other);
	}

	ResultData &operator = (const ResultData &other)
	{
		m_bSeatsState = other.m_bSeatsState;
		m_nPlayerID = other.m_nPlayerID;
		m_fEarnMoney = other.m_fEarnMoney;

		strcpy(m_sName, other.m_sName);

		return *this;
	}

};


struct Action
{
	int nSeatID;
	int nCardCount;
	char Cards[MAX_CARD_COUNT];

	Action(TID seatid, int cardcount, const char* cards)
	{
		nSeatID = seatid;
		nCardCount = cardcount;

		if (nCardCount > 0 && cards != NULL)
		{
			for (int i = 0 ; i < cardcount; i++ )
				Cards[i] = cards[i];
		}
		else
		{
			for (int i = 0 ; i < MAX_CARD_COUNT; i++ )
				Cards[i] = 0;
		}
	}

	Action(const Action&other)
	{
		operator =(other);
	}

	Action& operator=(const Action &other)
	{
		nSeatID = other.nSeatID;
		nCardCount = other.nCardCount;
		for (int i = 0 ; i < other.nCardCount; i++ )
			Cards[i] = other.Cards[i];

		return *this;
	}

	Action()
	{
		nSeatID = 0;
		nCardCount = 0;
		for (int i = 0 ; i < MAX_CARD_COUNT; i++ )
			Cards[i] = 0;
	}
};
typedef std::vector<Action> Actions;
class GameTable
{
public:
	virtual void update(unsigned int nTime);
	virtual void onStateChanged(EngineEvent event, uint64 wParam = 0 , uint64 lParam = 0);

	virtual bool	isPlaying() { return m_bPlaying; }
	virtual void	setPlaying(bool bPlaying) { m_bPlaying = bPlaying; }
	/*---------------------------------------------------------
	자리에 앉기 위해 호출한다.
	자리에 이미 사람이 있으면 true, 없으면 false를 돌린다.
	사람이 없는 경우 게임이 시작한 상태이면 fold상태로 넘긴다.
	---------------------------------------------------------*/
	virtual bool	sit(int nSeatID, Player player);
	virtual bool	sit( Player player, TPOS *pos);
	virtual bool	isAvailableStart();
	virtual bool	isAvailableSit(TCASH fCash);
	virtual bool	isAvailableSitFromSeatID(int nSeatID);

		/*----------------------------------------------------------------
	게임을 시작할수 있는 경우 게임을 시작한다.
	FirstPlayer를 정하고 SmallBlind와 BigBlind를 낸 다음 패쪽을 나누어준다.
	----------------------------------------------------------------*/
	virtual bool	startGame();

	//it calls when Game ended
	// param
	//		bForce : 
	virtual bool	finishGame(TID nPlayerID, bool bAutoOut = true);

	virtual bool	setAction(int nPlayerID, char * cards, int nCardCount);

	virtual bool	outPlayerInSeat(int nPlayerID);
	virtual bool	outPlayerInSeatFromSeatID(int nSeatID);

	virtual const Player* getPlayer (int nPlayerID);
	virtual const Player* getPlayerfromSeatID (int nSeatID);

	//return seat id if player exist in table 
	//otherwise -1
	virtual int		getSeatIDfromPlayerID (int nPlayerID);

	virtual void	setFirstPlayerSeatID(int nSeatID);
	virtual void	setCurPlayerSeatID(int nSeatID){ m_nCurPlayerSeatID = nSeatID; }
	virtual int		getCurPlayerSeatID() const{ return m_nCurPlayerSeatID; }

	virtual int		getCurPlayerCount()const;

	virtual bool	dealFromOther(char* pCards);
	virtual void	setCallbackFunc(Callbackfunc cb) { m_pCallbackfunc = cb; }
	virtual void	setCallbackLog(Callbacklog cb) { m_pCallbackLog = cb; }

	virtual char*	getTableName();
	virtual TCASH	getStackMoney(){return m_fStack;}

	virtual Action	getLastAction() ;
	virtual int		getLastPlayerSeatID() { return m_Actions.back().nSeatID;}
	virtual int		getTableCardCount() { return m_Actions.back().nCardCount;}
	virtual char*	getTableCards() { return  m_Actions.back().Cards; }
	
	virtual int		getTableID(){ return m_nTableID; }

	virtual Actions getAvailableActions(TID nPlayerID);
	virtual bool	isAvailableAction(TID nPlayerID, const char* cards, int nCardCount);
	
	virtual void updateAutoPlayer(TID nPlayerID, Action& action );

	virtual void pushBackAction(Action action){ m_Actions.push_back(action); }
	virtual void setFirstPlaying(bool bFirstPlaying){m_bFirstPlaying = bFirstPlaying;}

	virtual bool Assert(bool bValid, const char *pstrAssert){return true;};
#if Test
	//make cards to string
	//set string to str
	//return value is written length
	int makeCardsToStr(char* str, int nStrlen, const char* cards, int nCardCount);
#endif
protected:


	int	 _calcFirstPlayerSeatID(int nSeatID);

	//deal cards.
	bool _deal();
	void _clear();
	void _remove();

	bool _updateGameState(int nSeatID, char *pCards, int nCardCount);
	bool _checkUpgrade(int nSeatID);
	TCASH _getLostMoney(int nCardCount);

	void _calcFirstPlayer();
	int _getPlayerCountInTable();

	//get next Player. if not find, return -1
	int _getNextPlayer(int nSeatID);

	//get previous Player. if not find, return -1
	int _getPrevPlayer(int nSeatID);

	CardGroupState _getCardGroup(const char* cards, int nCardCount);

	bool _isSingle(const char* cards, int nCardCount);
	bool _isPair(const char* cards, int nCardCount);
	bool _isTriple(const char* cards, int nCardCount);
	bool _isFive(const char* cards, int nCardCount);
	bool _isStraight(const char* cards, int nCardCount);
	bool _isFlush(const char* cards, int nCardCount);
	bool _isFullHouse(const char* cards, int nCardCount);
	bool _isQuad(const char* cards, int nCardCount);
	bool _isStraightFlush(const char* cards, int nCardCount);

	bool _sortCards(char* cards, int nCardCount);

	bool _sortCardsByNumber(char* cards, int nCardCount);
	int  _getSameCardCount(const char* cards, int nCardCount);
	int  _getDiffCardCount(const char* cards, int nCardCount);
	int _isLarge(char card1, char card2);
	void _replaceTwoCards(char* card1, char* card2);
	void _copyCards(char* dstCards, const char* srcCards, int nCount);
	int _getCardNumber(char Card){return (Card-1) / SUIT_COUNT;}
	int _getCardSuit(char Card){return (Card-1) % SUIT_COUNT;}
	bool __isStraight(const char* cards, int nCardCount);
	bool __isFlush(const char* cards, int nCardCount);

	int _getRandCard(bool init=false);
	int _isLarge(const char* card1, const char* card2, int nCardCount);

	void _log(char* buf);
	
	//make candy functions
	void _findAll(Actions& actions, const char *cards);
	void _findSingleCards(Actions& actions, const char* nPrevCards, int nPrevCardsCount, const char *cards);
	void _findPairCards(Actions& actions, const char* nPrevCards, int nPrevCardsCount, const char *cards);
	void _findTripleCards(Actions& actions, const char* nPrevCards, int nPrevCardsCount, const char *cards);
	void _findFiveCards(Actions& actions, const char* nPrevCards, int nPrevCardsCount, const char *cards);
protected:
	bool	m_bFirstPlaying;
    int     m_nMinCard;
	bool	m_bPlaying;
	int		m_nTableID;
	char	m_sName[MAX_TABLENAME_LEN];

	//weather engine deal card or not
	bool	m_bMaster;

	Player m_Players[SEAT_COUNT];

	ResultData			m_resultDatas[SEAT_COUNT];

	/*-----------------------------------------------
	if seat is employed by player , it's player's id.
	else 0
	-----------------------------------------------*/
	bool m_bSeatsState[SEAT_COUNT];

	//Seat id that is activated
	int m_nCurPlayerSeatID;

	TCASH m_fStack;

	Callbackfunc	m_pCallbackfunc;
	Callbacklog		m_pCallbackLog;

	Actions			m_Actions;
	
	int				m_nWinnerSeatID;

// 	//card count in the board
// 	int m_nCurCardCount;
// 
// 	//cards in the board
// 	char m_nCurCards[5];
// 
// 	//player's seat id that put the last cards in the board
//  	int m_nLastPlayerSeatID;

	//when player is out, he must put the money here according to his card's count.
	TCASH m_fMoney;

	//temp string for log and so on.
#define TEMP_STR_SIZE 1024
	static char m_sTemp[TEMP_STR_SIZE];
public:
	GameTable(int nTableID, char* sName, TCASH fStake, bool bMaster = true );
	GameTable();
	GameTable(const GameTable& obj);

	void initGameTable(int nTableID, char* sName, TCASH fStake, bool bMaster = true);


	GameTable& operator= (const GameTable& obj);

	virtual ~GameTable();
};
};//end of Namespace GE
