#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <wchar.h>
#include <time.h>


#include "ServerTable.h"
#include "packet.h"
namespace GE
{

ServerTable::ServerTable(int nTableID, char* sName, TCASH fStake
						 , CallBackFunc2Params *pCallBackTableSend1
						 , CallBackFunc6Params *pCallBackTableSend2
						 , CallBackFuncBuf *pCallBackTableSend3
						 , CallBackFunc2Params *pCallBackPlayerSend1
						 , CallBackFunc6Params *pCallBackPlayerSend2
						 , CallBackFuncBuf  *pCallBackPlayerSend3
						 , CallBackChangeCash *pCallBackChangeCash
						 , CallBackHistory *pCallBackHistory
						 , CallBackKickOut *pCallBackKickOut
						 , CallBackLog *pCallBackLog
						 )
						 : GameTable(nTableID, sName, fStake, true)
						 , m_pCallBackTableSend1(pCallBackTableSend1)
						 , m_pCallBackTableSend2(pCallBackTableSend2)
						 , m_pCallBackTableSend3(pCallBackTableSend3)
						 , m_pCallBackPlayerSend1(pCallBackPlayerSend1)
						 , m_pCallBackPlayerSend2(pCallBackPlayerSend2)
						 , m_pCallBackPlayerSend3(pCallBackPlayerSend3)
						 , m_pCallBackChangeCash(pCallBackChangeCash)
						 , m_pCallBackHistory(pCallBackHistory)
						 , m_pCallBackKickOut(pCallBackKickOut)
						 , m_pCallBackLog(pCallBackLog)
{
	m_nStartGameTime = 0;
}

ServerTable::~ServerTable(void)
{
}

void ServerTable::setCallbackFunc(CallBackFunc2Params *pCallBackTableSend1
					 , CallBackFunc6Params *pCallBackTableSend2
					 , CallBackFuncBuf  *pCallBackTableSend3
					 , CallBackFunc2Params *pCallBackPlayerSend1
					 , CallBackFunc6Params *pCallBackPlayerSend2
					 , CallBackFuncBuf  *pCallBackPlayerSend3
					 , CallBackChangeCash *pCallBackChangeCash
					 , CallBackHistory *pCallBackHistory
					 , CallBackKickOut *pCallBackKickOut
					 , CallBackLog *pCallBackLog
					 )
{
	m_pCallBackTableSend1 = pCallBackTableSend1;
	m_pCallBackTableSend2 = pCallBackTableSend2;
	m_pCallBackTableSend3 = pCallBackTableSend3;
	m_pCallBackPlayerSend1 = pCallBackPlayerSend1;
	m_pCallBackPlayerSend2 = pCallBackPlayerSend2;
	m_pCallBackPlayerSend3 = pCallBackPlayerSend3;
	m_pCallBackChangeCash = pCallBackChangeCash;
	m_pCallBackHistory = pCallBackHistory;
	m_pCallBackKickOut = pCallBackKickOut;
	m_pCallBackLog = pCallBackLog;
	m_nActionDelayTime = 0;
}

bool ServerTable::startGame()
{
	if (GameTable::startGame()) {
		m_nActionDelayTime = time(NULL) + TIME_ACTION_DELAY;
		return true;
	}
	return false;
}
bool ServerTable::finishGame(TID nPlayerID, bool bAutoOut)
{
	if (GameTable::finishGame(nPlayerID,bAutoOut)) {
		m_nActionDelayTime = 0;
		return true;
	}
	return false;
}

bool ServerTable::outPlayerInSeatFromSeatID(int nSeatID)
{
	if (GameTable::outPlayerInSeatFromSeatID(nSeatID))
	{

		if (m_bPlaying)
		{
			m_nActionDelayTime = time(NULL) + TIME_ACTION_DELAY;
		}
		return true;
	}
	return false;
}


bool ServerTable::setAction(int nPlayerID, char * cards, int nCardCount)
{
	m_nActionDelayTime = time(NULL) + TIME_ACTION_DELAY;
	return GameTable::setAction(nPlayerID,cards, nCardCount);
}

void ServerTable::update(unsigned int nTime)
{
	if (isPlaying() && m_nActionDelayTime != 0 && m_nActionDelayTime < nTime)
	{
		m_nActionDelayTime = 0;

		if (getCurPlayerSeatID() == getLastPlayerSeatID() )
		{
			if (Assert(0 <= getCurPlayerSeatID() && getCurPlayerSeatID() < 4, "getCurPlayerSeatID() is invalid."))
				m_pCallBackKickOut(m_Players[getCurPlayerSeatID()].getPlayerID(), getTableID(), KICK_TIME_OUT);
		}
		else
		{
			//setAction(m_Players[getCurPlayerSeatID()].getPlayerID(),NULL, 0);
			if (Assert(0 <= getCurPlayerSeatID() && getCurPlayerSeatID() < 4, "getCurPlayerSeatID() is invalid."))
				m_pCallBackKickOut(m_Players[getCurPlayerSeatID()].getPlayerID(), getTableID(), KICK_TIME_OUT);
		}
	}

	if ( !isPlaying() && m_nStartGameTime != 0 && nTime > m_nStartGameTime )
	{
		m_nStartGameTime = 0;
		if (isAvailableStart())
			startGame();
		return;
	}

	if ( !isPlaying() && m_nStartGameTime == 0 )
	{
		if ( isAvailableStart() )
		{
			m_nStartGameTime = nTime + TIME_START_GAME_DELAY;
			return;
		}
	}
}

int ServerTable::onNotifyReceive(TID nPlayerID, int pktID, void* pData0, unsigned int size)
{
	char* pData = (char*)pData0;
	switch(pktID)
	{
	case M_CS_JOIN:
		{
		}
		break;
	case M_CS_TABLE_LEAVE:
		{
			
		}
		break;
	case M_CS_TABLE_ACTION:
		{
			
		}
		break;
	}
	return 0;
}

void ServerTable::onStateChanged(EngineEvent event, uint64 wParam, uint64 lParam)
{

}


};

