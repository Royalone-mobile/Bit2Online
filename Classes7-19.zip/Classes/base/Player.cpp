#include "Player.h"
#include <string.h>
namespace GE {
Player::Player()
:m_bPlaying(false)
,m_nPlayerID(0)
,m_nCharID(0)
,m_fEmployedMoney(0)
,m_nCurCardCount(0)
,m_fEarnMoney(0.0)
{
	for (int i = 0 ; i < CARD_COUNT_PER_PLAYER ; i++ )
		m_pCards[i] = 0;
	strcpy(m_sName , "");
	strcpy(m_sCHIDURL, "");
}
Player::Player(int nPlayerID, int nCharID, char *sCHIDURL, char* sName, TCASH fMoneyInHand)
:m_bPlaying (false) 
,m_nPlayerID(nPlayerID)
,m_nCharID(nCharID)
,m_fEmployedMoney(fMoneyInHand)
,m_nCurCardCount(0)
,m_fEarnMoney(0)
{
	for (int i = 0 ; i < CARD_COUNT_PER_PLAYER ; i++ )
		m_pCards[i] = 0;
	strcpy(m_sName , sName);
	strcpy(m_sCHIDURL , sCHIDURL);
}

void Player::initPlayer(int nPlayerID, int nCharID, char *sCHIDURL, char* sName, TCASH fEmployedMoney)
{
	m_bPlaying = false ;
	m_nPlayerID = nPlayerID;
	m_nCharID = nCharID;
	m_fEmployedMoney = fEmployedMoney;
	m_nCurCardCount = 0;
	strcpy(m_sName , sName);
	strcpy(m_sCHIDURL, sCHIDURL);
	for (int i = 0 ; i < CARD_COUNT_PER_PLAYER ; i++ )
		m_pCards[i] = 0;
	m_fEarnMoney = 0;
}

Player::Player(const Player& player)
{
	m_bPlaying = player.m_bPlaying;
	m_nPlayerID = player.m_nPlayerID;
	strcpy(m_sName, player.m_sName);
	strcpy(m_sCHIDURL, player.m_sCHIDURL);
	m_nCharID = player.m_nCharID;
	m_fEmployedMoney = player.m_fEmployedMoney;
	m_nCurCardCount = player.m_nCurCardCount;

	int i = 0;
	for ( ; i < 13 ; i++ )
		m_pCards[i] = player.m_pCards[i];
	m_fEarnMoney = player.m_fEarnMoney;
}

const Player& Player::operator= (const Player& player)
{
	m_bPlaying = player.m_bPlaying;
	m_nPlayerID = player.m_nPlayerID;
	strcpy(m_sName, player.m_sName);
	strcpy(m_sCHIDURL, player.m_sCHIDURL);
	m_nCharID = player.m_nCharID;
	m_fEmployedMoney = player.m_fEmployedMoney;
	m_nCurCardCount = player.m_nCurCardCount;

	int i = 0;
	for ( ; i < 13 ; i++ )
		m_pCards[i] = player.m_pCards[i];
	m_fEarnMoney = player.m_fEarnMoney;
	return *this;
}
Player::~Player()
{
}

void Player::setPlayerName(const char* sName)
{
	strcpy(m_sName, sName);
}

void Player::setPlayerCHIDURL(const char *sCHIDURL)
{
	strcpy(m_sCHIDURL, sCHIDURL);
}

bool Player::setCards(char* cards, int nCardCount)
{
	if( nCardCount != CARD_COUNT_PER_PLAYER )
		return false;

	m_nCurCardCount = 0;
	for (int i = 0 ;i < nCardCount ; i++)
	{
		m_pCards[i] = cards[i];
		if(cards[i] != 0)
			m_nCurCardCount++;
	}
	return true;
}

bool Player::addCard(int nCardNumber) 
{ 
	if( nCardNumber == 0 )
		return false;
		
	for( int i = 0 ; i< CARD_COUNT_PER_PLAYER ; i++ )
		if( m_pCards[i] == 0 )
		{
			m_pCards[i] = nCardNumber;
			m_nCurCardCount++;
			return true;
		}
		return false;
}


bool  Player::removeCard(int nIndex)
{
	if( m_pCards[nIndex] == 0 )
		return false;
	m_pCards[nIndex] = 0;
	m_nCurCardCount--;
	return true;
}

bool Player::removeCardbyCardNumber(char nCardNumber)
{
	int nCardPos = getCardPos(nCardNumber) ;
	if ( nCardPos != -1 )
		removeCard(nCardPos);
	return true;
}

int Player::getCardPos(int nCardNumber) const
{
	if ( nCardNumber == 0 )
		return -1;
	for (int i = 0 ; i < CARD_COUNT_PER_PLAYER ; i++ )
	{
		if( m_pCards[i] == nCardNumber )
			return i;
	}
	return -1;
}
void Player::setEmployedMoney(TCASH fEmployedMoney)
{
	m_fEmployedMoney = fEmployedMoney;
	if (m_fEmployedMoney < 0)
		m_fEmployedMoney = 0;
}
void Player::addEmployedMoney(TCASH fAddMoney) 
{
	m_fEmployedMoney += fAddMoney; 
	if (m_fEmployedMoney < 0)
		m_fEmployedMoney = 0;
}

} //end of Namespace GE