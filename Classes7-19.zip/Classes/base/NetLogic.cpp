/*
 *  Netlogic.cpp
 *  Showhand
 *
 */

#include <string.h>
#include <map>
#include <stdarg.h>
#include <stdio.h>
#include "NetLogic.h"

#include "error.h"
#include "packet.h"


extern int nCurTableID;
extern GE::GameTable	m_GameTable;
extern int nArrangeOption;
extern bool bArrangeAscending;
extern TCASH fSelTableCash;
extern int nViewOption;

TID g_CashRecievedID;

TMemoList			g_MemoList;
TGameResult			g_GameResult;

char			m_szAddr[32];
char            m_szVersion[32];
bool            m_bVersionFailed = false;
TRecvCallback	m_RecvCb;
int				m_nUserState = stateNone;
USER_INFO_T		m_UserInfo;
char			m_UserPhoto[MAX_USERNAME_LEN];
char			m_WebSeverAddress[MAX_USERNAME_LEN];
char            m_BuyServerAddress[MAX_USERNAME_LEN];
FRIEND_INFO_T	m_FBInfo;
INVITE_INFO_T	m_InviteInfo;
TCASH nMinBetValue[MIN_BET_COUNT] = {2,10,50,200,1000,5000,20000,100000,500000,1000000};

//Register Friend
USER_INFO_T			m_RequestInfo;
TRegisterList		m_SendRequestList;
TRegisterList		m_ReceiveRequestList;

TTableList		m_TableList;
TNameList		m_InviteNameList;
TNameList		m_ObserverList;
TWinnerList		m_WinnerList;
TFriendList		m_OnlineFriendList;
TFriendList		m_OfflineFriendList;
TRankingList	m_TopRankingList;
TRankingList	m_MyRankingList;

TTIDVector		m_nTableIDList;
TStakeList  	m_fTableStakeList;

TFindUserList		m_FindUserList;

static unsigned int		m_nMySeatPos = 3;

#ifdef _TEST_LOCAL
#include "VServer.h"
VServer vServer;
#endif
#define MAX_LOG_BUF 512

//#define NO_LOG

//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
bool	_SendPingPacket();

void	NetLogic_log(int nLogLevel,const char * szFormat, ...)
{

}


bool	NetLogic_send()
{
	return false;
}


static bool _createSocketInstance()
{
	
	return true;
}

static void _deleteSocketInstance()
{
	
}

bool	NetLogic_init(const char* szaddr)
{
	NetLogic_log(Log_detail,"NetLogic_init");
	if (szaddr == NULL) {
		return false;
	}
	strncpy(m_szAddr, szaddr, 32);
	
	_deleteSocketInstance();
	_createSocketInstance();
    m_bVersionFailed = false;
	return true;
}

void	NetLogic_disConnect(bool bNormal)
{
	if (NetLogic_GetUserState() == stateNone) {
		return;
	}
	
	NetLogic_log(Log_info, "You are disconnected");
	
	_deleteSocketInstance();
	if (!bNormal) {
		m_RecvCb(notifyWaiting, Waiting_None, 0);
		m_RecvCb(notifyDisconnect, ERR_ABNORMAL_DISCONNECT, 0);
        if (m_bVersionFailed == false) {
            m_RecvCb(notifyError, ERR_ABNORMAL_DISCONNECT, 0);
        }
	}
	else
		m_RecvCb(notifyDisconnect, 0, 0);
}

void	NetLogic_release()
{
	NetLogic_disConnect(true);
}

#define _DETAIL_LOG

static void	_updateNetLogic(double cur_time)
{


}

void	NetLogic_update(double cur_time)
{
	static bool bInFlag = false;
	if ( bInFlag ) return;
	bInFlag = true;
	
	_updateNetLogic(cur_time);
	
	bInFlag = false;
	return;
}

bool	NetLogic_loginToServer(const char* szID, const char* szPWD)
{
	return true;
}

//[s:Facebook uid][s:Facebook Name][s:Facebook Email][s:FaceBook PicURL]
bool	NetLogic_loginToServerFB(const char* szFBName, const char* szFBUID, const char* szPicURL, const char* szEmail)
{
	return true;
}

bool	NetLogic_SendFriendList()
{

	return true;
}

bool	NetLogic_isReceived()
{
	return true;
}

bool	NetLogic_readPacket()
{
	return true;
}

USER_INFO_T &	NetLogic_GetUserInfo()
{
	return m_UserInfo;
}

void NetLogic_SetUserCash(TCASH cash)
{
	m_UserInfo.m_nUserCash = cash;
}


int		NetLogic_GetTableCount()
{
	return m_TableList.size();
}

TABLE_INFO_T &	NetLogic_GetTableFromIndex(int n)
{
	int count = 0;
	TTableList::iterator it= m_TableList.begin();
	TID	id = it->first; 
	
	for ( ; it != m_TableList.end(); it ++ )
	{
		if ( count == n )
		{
			id = it->first;
			break;
		}
		count ++;
	}
	return m_TableList[id];
}

TABLE_INFO_T &	NetLogic_GetTableFromID(TID id)
{
	return m_TableList[id];
}

/*void	NetLogic_SetCurGroupType(TID type)
 {
 m_nCurGroupType = type;
 }
 
 TID		NetLogic_GetCurGroupType()
 {
 return m_nCurGroupType;
 }*/

TUserState	NetLogic_GetUserState()
{
	return (TUserState)m_nUserState;
}


INVITE_INFO_T& NetLogic_GetInvitedInfo()
{
	return m_InviteInfo;
}

int NetLogic_GetSeatID()
{
	return m_nMySeatPos;
}

void NetLogic_SetSeatID(int nSeatID)
{
	m_nMySeatPos = nSeatID;
}

TID NetLogic_GetPlayerID()
{
	return m_UserInfo.m_UserDBID;
}

void	NetLogic_SetRecvCallback(TRecvCallback cb)
{
	m_RecvCb = cb;
}

GE::GameTable& NetLogic_GetGameTable()
{
	return m_GameTable;
}

void	NetLogic_onReceive(int pktid, const void* pData0, int nDataLen)
{
	
}

void NetLogic_StartGame()
{
	int nFirstPlayerSeatID = 0;
	int len = 0;


	m_GameTable.startGame();
	m_GameTable.setFirstPlayerSeatID(nFirstPlayerSeatID);	

}


void	NetLogic_ArrangeTable(int nArrangeby, bool bAscending)
{

}
bool	NetLogic_RemoveTableIDFromIndex(TID tid)
{
	/*
	 int nTableCount = NetLogic_GetTableCount();
	 int i = 0;
	 while(m_nTableIDList[i] != INVALID_ID && tid != m_nTableIDList[i]) {
	 i++;
	 }
	 for (int j = i; j < nTableCount; j++) {
	 m_nTableIDList[j] = m_nTableIDList[j + 1];
	 }
	 m_nTableIDList[nTableCount - 1] = INVALID_ID;
	 */
	return true;
}

//[d:GroupType][s:TableName][d:Stake][d:maxPlayer]
bool	NetLogic_SendCreateTable(char* tname, TCASH stake, int maxplayer)
{
	NetLogic_log(Log_detail,"NetLogic_SendCreateTable: tname=%s, stake=%.2f, maxplayer=%d",
				 tname, stake, maxplayer);
	m_RecvCb(notifyWaiting, Waiting_Table,0);
	return true;
}

//[s:UserID][s:UserPwd][w:CharacterID]
bool	NetLogic_SendCreateAccount(char* ch_name, char* ch_pwd, short ch_id, char* ch_Email)
{
	return true;
}

bool	NetLogic_SendPlayNow()
{
	NetLogic_log(Log_detail,"NetLogic_SendAskTableInfoAtLobby");
	return true;
}

void	NetLogic_SetUserState(TUserState state)
{
	m_nUserState = state;
}

bool	NetLogic_SendForgetPassword(const char* ch_EmailAddr)
{
	
	
	
	NetLogic_log(Log_detail,"NetLogic_SendForgetPassword: %s", ch_EmailAddr);
	return true;
}

//[d:TableID]
bool	NetLogic_SendAskTableInfoAtLobby(TID table_id)
{
	return true;
}

//[d:TableID]
bool	NetLogic_SendJoinTable(TID tableid, int nPos)
{
	return true;
}

bool	NetLogic_SendStandUp()
{
	NetLogic_log(Log_detail,"NetLogic_SendStandUp");
	
	return true;
}

//[d:TableID]
bool	NetLogic_SendViewTable(TID tableid)
{
	
	NetLogic_log(Log_detail,"NetLogic_SendViewTable: tableid=%d", tableid);
	
	m_RecvCb(notifyWaiting, Waiting_Table,0);
	return true;
}

bool	NetLogic_SendLeaveTable()
{

	NetLogic_log(Log_detail,"NetLogic_SendLeaveTable");
	
	return true;
}

bool	NetLogic_SendPlayerAction(int PlayerID, const char* cards, unsigned long nCardCount)
{

    return true;
}

bool	NetLogic_SendTableChat(char* chat_str)
{
	NetLogic_log(Log_detail,"NetLogic_SendTableChat: szchat = %s", chat_str);
	return true;
}

bool	_SendPingPacket()
{
	return true;
}

bool	NetLogic_SendFindUser(const char* name)
{
	return true;
}

bool	NetLogic_SendAskInvite(TID nPlayerID)
{
	return true;
}

bool	NetLogic_SendAskLobbyUsers()
{
	return true;
}
bool	NetLogic_SendBuyCash(TCASH fCash)
{
	return true;
}

bool	NetLogic_SendAskPlayerInfo(TID nFriendDBID)
{
	return true;
}

bool	NetLogic_SendRegisterFriend(TID nFriendDBID)
{
	return true;
}

bool	NetLogic_SendAcceptRegisterFriend(TID nFriendDBID)
{
	NetLogic_log(Log_detail,"NetLogic_SendAcceptRegisterFriend FriendDBID = %d", nFriendDBID);
	return true;
}

bool	NetLogic_SendRejectRegisterFriend(TID nFriendDBID)
{
	NetLogic_log(Log_detail,"NetLogic_SendRejecttRegisterFriend FriendDBID = %d", nFriendDBID);
	return true;
}

int		NetLogic_GetPlayerCountInLobby()
{
	return m_InviteNameList.size();
}

bool	NetLogic_SendAcceptInvite(TID nTableID, TID nInviterID)
{
	NetLogic_log(Log_detail,"NetLogic_SendAcceptInvite: nTableID = %d, nInviterID = %d", nTableID, nInviterID);

	return true;
}

bool	NetLogic_SendRejectInvite(TID nTableID, TID nInviterID)
{
	NetLogic_log(Log_detail,"NetLogic_SendRejectInvite: nTableID = %d, nInviterID = %d", nTableID, nInviterID);
	
	return true;
}

bool	NetLogic_SendChangeAvatar(TID nCharID, const char *szPhotoName)
{
	NetLogic_log(Log_detail,"NetLogic_SendChangeAvatar: nCharID = %d szPhoto = %s", nCharID, szPhotoName);
	
	return true;
}

bool	NetLogic_SendChangeName(const char *szName)
{
	NetLogic_log(Log_detail,"NetLogic_SendChangeName: szNmae = %s", szName);

	return true;
}

bool	NetLogic_SendAskRankingInfo()
{
	NetLogic_log(Log_detail,"NetLogic_SendAskRankingInfo");

	return true;
}

bool	NetLogic_SendChipsToFriend(TID nFriendDBID, TCASH fCash)
{
	NetLogic_log(Log_detail,"NetLogic_SendChipsToFriend");
	
	return true;
}

bool	NetLogic_SendAskFriendInfo(TID nFriendDBID)
{
	return true;
}

bool	NetLogic_SendTestLocalStartGame()
{
	return true;
}

//9.21
bool	NetLogic_IsMyFriend(TID nDBID)
{
	TFriendList::iterator it = m_OnlineFriendList.begin(), itEnd = m_OnlineFriendList.end();
	for (; it != itEnd; it++) {
		if (it->nFriendDBID == nDBID) {
			return true;
		}
	}
	it = m_OfflineFriendList.begin(), itEnd = m_OfflineFriendList.end();
	for (; it != itEnd; it++) {
		if (it->nFriendDBID == nDBID) {
			return true;
		}
	}
	return false;
}


bool	NetLogic_SendVersion(const char *szVersion) {
    int nVersion = STRING_VERSION;
    //int nVersion = 110;
    //NetLogic_send(M_CS_VERSION, "d", &nVersion);
	return true;
}

void    NetLogic_SetVersion(const char *szVersion)
{
    strcpy(m_szVersion, szVersion);
}

char*   NetLogic_GetVersion()
{
    return m_szVersion;
}

void    NetLogic_SendReqUpload(const char *szFileName)
{
}


void NetLogic_Sit( int pos, GE::Player player)
{
	m_GameTable.sit(pos, player);
}
