#ifndef _PLAYER_H
#define _PLAYER_H
#include "NetCommon.h"

#define SAFE_DELETE(p) if(p)\
	{\
		delete p;\
		p = NULL;\
	}

#define SAFE_DELETE_ARRAY(p) if(p)\
	{\
	delete[] p;\
	p = NULL;\
	}

#ifdef HIWORD
#undef HIWORD
#endif
#define HIWORD(X) X>>16
#ifdef LOWORD
#undef LOWORD
#endif
#define LOWORD(X) X & 0xffff

namespace GE {
//////////////////////////////////////////////////////////////////////////
//---------------Global Functions and DataTypes---------------------------
enum EngineEvent
{
	EngineEvent_Sit,			//if player sit the seat, return it. lParam = SUCCESS ? TRUE : FALSE wParam = SUCCESS ? nSeatID : nPlayerID
	EngineEvent_Out,			//if player sit out the seat, return it. wParam = nSeatID lParam = SUCCESS ? TRUE : FALSE
	EngineEvent_StartGame,		//if hand started, return it. wParam = success? true :false lParam = FirstPlayerSeatID 
	EngineEvent_ActionPlayed,	//if player set action, return it. wParam = playerID lParam = Actioned ? 1 : 0
	EngineEvent_FinishGame,		//if the game ended, return it. wParam = nWinerID lParam = &fMoney;
	EngineEvent_ViewTable,
	EngineEvent_AutoOut,
};
enum Suit
{
	DIAMOND = 0,
	CLUB = 1,
	HEART = 2,
	SPADE = 3,
};


//state of CardGroup state of card group
enum CardGroupState
{
	CARDGROUP_NONE = 0 ,
	CARDGROUP_SINGLE = 1,
	CARDGROUP_PAIR = 2,
	CARDGROUP_TRIPLE = 3,
	CARDGROUP_STRAIGHT = 4,
	CARDGROUP_FLUSH = 5,
	CARDGROUP_FULLHOUSE = 6,
	CARDGROUP_QUAD = 7,
	CARDGROUP_STRAIGHTFLUSH = 8,
	CARDGROUP_COUNT = 9,
};

class Player
{
public:
	void buyChip(TCASH fMoney){ m_fEmployedMoney += fMoney; }

	int		getPlayerID()const {return m_nPlayerID;}
	void	setPlayerID (int nPlayerID) { m_nPlayerID = nPlayerID ; }

	const char*	getPlayerName() const { return m_sName; }
	void	setPlayerName(const char* sName);

	const char* getPlayerCHIDURL() const {return m_sCHIDURL; }
	void	setPlayerCHIDURL(const char *sCHIDURL);

	int		getCharID() const { return m_nCharID; }
	void	setCharID(int nCharID) { m_nCharID = nCharID; }	

	//employed money for currrent player
	TCASH	getEmployedMoney() const {return m_fEmployedMoney;}
	void	setEmployedMoney(TCASH fEmployedMoney);
	void	addEmployedMoney(TCASH fAddMoney);
	
	//position fo card, when there isn't the card, return -1
	int getCardPos(int nCardNumber) const;
	
	bool setCards(char* cards, int nCardCount);
	bool addCard(int nCardNumber);
	bool removeCard(int nIndex);
	bool removeCardbyCardNumber(char nCardNumber);
	const char*	getCards() const { return m_pCards; }
	char	getCard(int nIndex) const { return m_pCards[nIndex]; }

	int	getCurCardCount() const{ return m_nCurCardCount;}

	void setPlaying(bool bPlaying = true ) { m_bPlaying = bPlaying ; }
	bool isPlaying() { return m_bPlaying; }
	
	void setEarnMoney(TCASH fEarnMoney) { m_fEarnMoney = fEarnMoney;}
	TCASH getEarnMoney()const  { return m_fEarnMoney;}
protected:
	//whether player is playing or not
	bool	m_bPlaying;

	//Player's ID, it is unique.
	int		m_nPlayerID;

	//name of player
	char	m_sName[MAX_USERNAME_LEN];

	//charactor id of player
	int 	m_nCharID;

	//character id of player
	char	m_sCHIDURL[MAX_USERCHIDURL_LEN];

	//employed money of player
	TCASH	m_fEmployedMoney;
	
	//employed card count
	int m_nCurCardCount;
	//employed card
	char m_pCards[13];
	
	TCASH	m_fEarnMoney;
public:
	Player();

	Player(int nPlayerID, int nCharID, char *sCHIDURL, char* sName, TCASH fMoneyInHand);
	Player(const Player& player);
	virtual ~Player();

	void initPlayer(int nPlayerID, int nCharID, char *sCHIDURL, char* sName, TCASH FEmployedMoney);
	const Player& operator= (const Player& player);
};

}// end of Namespace GE

#endif