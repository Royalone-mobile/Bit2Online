#include "RankingLayer.h"
#include "SimpleAudioEngine.h"
#include "Global.h"
#include "ViewSetting.h"
USING_NS_CC;
using namespace CocosDenshion;


extern bool				g_bFriendImageLoaded;

// image name
static CCString* strBackground = new CCString("ranking_dilog.png");
static CCString* strBtnMyNml = new CCString("my_ranking-01.png");
static CCString* strBtnMyAct = new CCString("my_ranking-02.png");
static CCString* strBtnTopnml = new CCString("top_01.png");
static CCString* strBtnTopact = new CCString("top_02.png");
static CCString* strCloseBtnnml = new CCString("btn_x_0.png");
static CCString* strCloseBtnact = new CCString("btn_x_1.png");

static const CCRect rtRankingTable = CCRectMake(-106, -55, 210, 140);
static const CCPoint ptMyRankingBtn = CCPointMake(-29, 67);
static const CCPoint ptTopRankingBtn = CCPointMake(-82, 67);
static const CCPoint ptCloseBtn = CCPointMake(93, 82);


static const CCRect rtPadRankingTable = CCRectMake(-212, -110, 420, 280);
static const CCPoint ptPadMyRankingBtn = CCPointMake(-58, 134);
static const CCPoint ptPadTopRankingBtn = CCPointMake(-164, 134);
static const CCPoint ptPadCloseBtn = CCPointMake(186, 172);

Scene* RankingLayer::createScene()
{
	// 'scene' is an autorelease object
	Scene* scene = NULL;
	do {

	scene = Scene::create();

	// 'layer' is an autorelease object
	auto layer = RankingLayer::create();

	scene->addChild(layer);
	} while (0);
	return scene;
}

// on "init" you need to initialize your instance
bool RankingLayer::init()
{
    //////////////////////////////
	do {
		if (!Layer::init())
		{
			return false;
		}
		Size size = Director::getInstance()->getWinSize();
		m_ptBackground = ccp(size.width / 2, size.height / 2);
		drawImages();
		drawButtons();
	} while (0);
    return true;
}

void RankingLayer::drawImages()
{
	Size size = Director::getInstance()->getWinSize();
    
	pSpriteBack = Sprite::create("image/iPhone/common/"+strBackground->_string);
	pSpriteBack->setPosition(Vec2(size.width * 0.5f, size.height * 0.5f ));
	this->addChild(pSpriteBack);
}



void RankingLayer::drawButtons() 
{
	Size size = Director::getInstance()->getWinSize();

	MenuItemImage* pCloseBtn = MenuItemImage::create("image/iPhone/eng/" + strCloseBtnnml->_string, "image/iPhone/eng/"+ strCloseBtnact->_string);
	pCloseBtn->setCallback(std::bind(menu_selector(RankingLayer::menuCallbackHandler), this, std::placeholders::_1));
	pCloseBtn->setPosition(m_ptBackground + ptCloseBtn);
	pCloseBtn->setTag(kMenuClose);
	

	auto rankingNml = MenuItemImage::create("image/iPhone/eng/" + strBtnMyNml->_string, "image/iPhone/eng/" + strBtnMyNml->_string);
	auto rankingAct = MenuItemImage::create("image/iPhone/eng/" + strBtnMyAct->_string, "image/iPhone/eng/" + strBtnMyAct->_string);

	Vector<MenuItem*> toggleItems;
	toggleItems.pushBack(rankingNml);
	toggleItems.pushBack(rankingAct);

	auto rankingToggle = MenuItemToggle::createWithCallback(std::bind(menu_selector(ViewSetting::menuCallbackHandler), this, std::placeholders::_1), toggleItems);
	rankingToggle->setPosition(m_ptBackground + ptMyRankingBtn);
	rankingToggle->setTag(kMenuRanking);

	toggleItems.clear();
	auto topRankingNml = MenuItemImage::create("image/iPhone/eng/" + strBtnMyNml->_string, "image/iPhone/eng/" + strBtnMyNml->_string);
	auto topRankingAct = MenuItemImage::create("image/iPhone/eng/" + strBtnMyAct->_string, "image/iPhone/eng/" + strBtnMyAct->_string);

	auto topRankingToggle = MenuItemToggle::createWithCallback(std::bind(menu_selector(ViewSetting::menuCallbackHandler), this, std::placeholders::_1), toggleItems);
	topRankingToggle->setPosition(m_ptBackground + ptMyRankingBtn);
	topRankingToggle->setTag(kMenuTopRanking);

	Vector<MenuItem*> items;
	items.pushBack(pCloseBtn);
	items.pushBack(rankingToggle);
	items.pushBack(topRankingToggle);
	auto pMenu = Menu::createWithArray(items);
	pMenu->setPosition(Vec2::ZERO);
	pSpriteBack->addChild(pMenu);
}

void RankingLayer::menuCallbackHandler(Ref * pSender)
{
	CallFunc * callFunc = NULL;
	int tag = ((MenuItem*)pSender)->getTag();
	switch (tag)
	{
		case kMenuPlay:
			MessageBox("Congrats on completing the game!", "Victory");
			break;
		case kMenuLogOut:
			App->changeSceneWithState(TGAME_LOGIN);
			break;
		case kMenuBuyChips:
			
			break;
		case kMenuFindUser:
			break;
		case kMenuFriend:
			break;
		case kMenuLobby:
			App->changeSceneWithState(TGAME_SELTABLE);
			break;
		case kMenuHelp:
			Application::getInstance()->openURL("http://www.vweeter.com");
			break;
		case kMenuTutorial:
			Application::getInstance()->openURL("http://www.vweeter.com");
			break;
	}

}

