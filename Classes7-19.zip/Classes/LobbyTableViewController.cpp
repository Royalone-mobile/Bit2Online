#include "LobbyTableViewController.h"

#include "ui/CocosGUI.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include "SelTableScene.h"
using namespace cocostudio::timeline;


Scene* LobbyTableViewController::createScene()
{
	// 'scene' is an autorelease object
	auto scene = Scene::create();

	// 'layer' is an autorelease object
	auto layer = LobbyTableViewController::create();

	// add layer as a child to scene
	scene->addChild(layer);

	// return the scene
	return scene;
}

// on "init" you need to initialize your instance
bool LobbyTableViewController::init()
{
	//////////////////////////////
	// 1. super init first
	if (!Layer::init())
	{
		return false;
	}

	tableView = TableView::create(this, Size(300, 250));
	tableView->setDirection(ScrollView::Direction::VERTICAL);
	tableView->setPosition(Point(0, 0));
	tableView->setDelegate(this);
	
	tableView->setTag(200);
	tableView->setColor(Color3B(255, 0, 0));
	tableView->setVerticalFillOrder(TableView::VerticalFillOrder::TOP_DOWN);
	this->addChild(tableView);
	tableView->reloadData();

	return true;
}

void LobbyTableViewController::setTableWidthHeight(float width, float height)
{
	tableView->setContentSize(CCSize(width, height));
}

void LobbyTableViewController::reloadData()
{
	tableView->reloadData();
}
void LobbyTableViewController::tableCellTouched(TableView* table, TableViewCell* cell)
{	
	int id = (int)cell->getIdx();
	CCString *strID = CCString::createWithFormat("id = %d", id);
	MessageBox(strID->getCString(), "");
	cell->setColor(Color3B(200, 200, 200));

	cell->setOpacity(0.5);
	
	TCASH cash = CGameSetting::getInstance()->getCash();
	
	TABLE_INFO tableInfo = CGameSetting::getInstance()->g_TableList[id];
	if (cash >= tableInfo.stake)
	{
		SelTableScene *selTableScene = (SelTableScene *)this->getParent();
		selTableScene->joinTable(id);
	}
}

Size LobbyTableViewController::tableCellSizeForIndex(TableView *table, ssize_t idx)
{
	return Size(table->getContentSize().width, 20);
}

TableViewCell* LobbyTableViewController::tableCellAtIndex(TableView *table, ssize_t idx)
{
	auto string = String::createWithFormat("%ld", idx);
	LobbyTableViewCell* cell = (LobbyTableViewCell*)table->dequeueCell();
	if (!cell)
	{
		TABLE_INFO tableInfo = CGameSetting::getInstance()->g_TableList[(int)idx];

		cell = new LobbyTableViewCell();
		cell->autorelease();

		cell->setCellInfo((char*)tableInfo.szName->getCString(), tableInfo.stake, 0);

		//auto sprite = Sprite::create("image/iPhone/common/pan_lobbypersonback.png");
		//sprite->setAnchorPoint(Point::ZERO);
		//sprite->setPosition(Point(0, 0));
		//sprite->setContentSize(this->getContentSize());
		//cell->addChild(sprite);

	}
	else
	{

	}

	return cell;
}

ssize_t LobbyTableViewController::numberOfCellsInTableView(TableView *table)
{
	return CGameSetting::getInstance()->g_TableList.size();
}


LobbyTableViewController::LobbyTableViewController()
{
}


LobbyTableViewController::~LobbyTableViewController()
{
}
LobbyTableViewCell::~LobbyTableViewCell()
{

}


LobbyTableViewCell::LobbyTableViewCell()
{
	m_pTableNameLbl = CCLabelTTF::create("", g_FontName->_string, 12, Size(140, 20), TextHAlignment::CENTER, TextVAlignment::CENTER);
	m_pTableNameLbl->setColor(ccc3(0, 0, 0));
	m_pTableNameLbl->setPosition(CCPoint(0, 0));

	m_pTableStakeLbl = CCLabelTTF::create("", g_FontName->_string, 12, Size(120, 20), TextHAlignment::CENTER, TextVAlignment::CENTER);
	m_pTableStakeLbl->setColor(ccc3(0, 0, 0));

	m_pTableStakeLbl->setPosition(CCPoint(30, 0));

	m_pTableStateLbl = CCLabelTTF::create("", g_FontName->_string, 12, Size(120, 20), TextHAlignment::CENTER, TextVAlignment::CENTER);
	m_pTableStateLbl->setColor(ccc3(0, 0, 0));

	m_pTableStateLbl->setPosition(CCPoint(60, 0));

	this->addChild(m_pTableNameLbl);
	this->addChild(m_pTableStakeLbl);
	this->addChild(m_pTableStateLbl);
}

void LobbyTableViewCell::setCellInfo(char *szTableName, TCASH fStake, float fState)
{
	CCString *tableName = new CCString(szTableName);
	CCString *stateName = new CCString("Normal");
	m_pTableNameLbl->setString(tableName->_string);
	m_pTableStakeLbl->setString(getMoneyString(fStake)->_string);
	m_pTableStateLbl->setString(stateName->_string);
}

void LobbyTableViewCell::clearCellInfo()
{
	m_pTableNameLbl->setString("");
	m_pTableStakeLbl->setString("");
	m_pTableStateLbl->setString("");
}
