#ifndef __HELLOWORLD_SCENE_H__
#define __HELLOWORLD_SCENE_H__

#include "cocos2d.h"
#include "Global.h"
#include "cocos-ext.h"
#include "network/HttpClient.h"

using namespace cocos2d;
class MainMenuScene : public cocos2d::Layer, public cocos2d::ui::EditBoxDelegate

{
public:
    static cocos2d::Scene* createScene();
    virtual bool init();
    
	void logInUser();
	void onHttpRequestCompleted(cocos2d::network::HttpClient *sender, cocos2d::network::HttpResponse *response);
    // a selector callback
    
    void menuCloseCallback(cocos2d::Ref* pSender);
	void drawImages();
	void drawButtons();
	void initTextFields();
	void menuCallbackHandler(Ref * pSender);
	void setRememberImage();
    // implement the "static create()" method manually
    CREATE_FUNC(MainMenuScene);
private:
    ui::EditBox*			useremail;
    ui::EditBox*			password;
    CCSprite* pSpriteBack;
	bool	m_bRememberMe;
	MenuItemImage *m_pLoginBtn;
	MenuItemToggle *m_pRememberBtn;
    virtual void editBoxEditingDidBegin(cocos2d::ui::EditBox* editBox)override;
    virtual void editBoxEditingDidEnd(cocos2d::ui::EditBox* editBox)override;
    virtual void editBoxTextChanged(cocos2d::ui::EditBox* editBox, const std::string& text)override;
    virtual void editBoxReturn(cocos2d::ui::EditBox* editBox)override;
};

#endif // __HELLOWORLD_SCENE_H__
