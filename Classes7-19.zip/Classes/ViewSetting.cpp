#include "ViewSetting.h"
#include "SimpleAudioEngine.h"
#include "Global.h"

USING_NS_CC;
using namespace CocosDenshion;


// image rect
static const CCRect rtBackground = CCRectMake(110, 28, 241, 137); //ViewTableSettingPos
static const CCRect rtBackgroundwelcome = CCRectMake(46, 115, 241, 137); //ViewWelcomeSettingPos

// button rect
/*
static const CCRect rtSoundBtn = CCRectMake(95, 21, 19, 9);
static const CCRect rtVibrationBtn = CCRectMake(95, 40, 19, 9);
static const CCRect rtBlockChatBtn = CCRectMake(95, 59, 19, 9);
static const CCRect rtFriendStateBtn = CCRectMake(95, 78, 19, 9);
*/
static const CCRect rtSoundBtn = CCRectMake(162, 27, 28, 14);
static const CCRect rtVibrationBtn = CCRectMake(162, 55, 28, 14);
static const CCRect rtBlockChatBtn = CCRectMake(162, 83, 28, 14);
static const CCRect rtFriendStateBtn = CCRectMake(162, 111, 28, 14);

// label rect
/*static const CCRect rtSoundLabel = CCRectMake(20, 20, 60, 10);
static const CCRect rtVibrationLabel = CCRectMake(20, 39, 60, 10);
static const CCRect rtBlockChatLabel = CCRectMake(20, 58, 60, 10);
static const CCRect rtFriendStateLabel = CCRectMake(20, 77, 60, 10);
*/
static const CCRect rtSoundLabel = CCRectMake(40, 24, 90, 15);
static const CCRect rtVibrationLabel = CCRectMake(40, 52, 90, 15);
static const CCRect rtBlockChatLabel = CCRectMake(40, 80, 90, 15);
static const CCRect rtFriendStateLabel = CCRectMake(40, 108, 90, 15);

// image name
static CCString* strBackground = new CCString("pan_boardsetting.png");

// button name
static CCString* strOnBtn = new CCString("btn_on_e.png");
static CCString* strOffBtn = new CCString("btn_off_e.png");

// label value
static CCString* strSound = new CCString("Sound");
static CCString* strVibration = new CCString("Vibration");
static CCString* strBlockChat = new CCString("Block chat");
static CCString* strFriendState = new CCString("Friend status");


//iPad Position
static const CCPoint ptPadBackground = CCPointMake(672, 615); //ViewTableSettingPos
static const CCPoint ptPadBackgroundWelcome = CCPointMake(277, 280); //ViewWelcomeSettingPos
static const CCPoint ptPadSoundLbl = CCPointMake(-12, 35);
static const CCPoint ptPadVibrationLbl = CCPointMake(-12, 1);
static const CCPoint ptPadBlockChatLbl = CCPointMake(-12, -33);
static const CCPoint ptPadFriendStateLbl = CCPointMake(-12, -67);
static const CCPoint ptPadSoundBtn = CCPointMake(72, 35);
static const CCPoint ptPadVibrationBtn = CCPointMake(72, 1);
static const CCPoint ptPadBlockChatBtn = CCPointMake(72, -33);
static const CCPoint ptPadFriendStateBtn = CCPointMake(72, -67);

Scene* ViewSetting::createScene()
{
	// 'scene' is an autorelease object
	Scene* scene = NULL;
	do {

		scene = Scene::create();

		// 'layer' is an autorelease object
		auto layer = ViewSetting::create();

		scene->addChild(layer);
	} while (0);
	return scene;
}


ViewSetting::~ViewSetting()
{
	CGameSetting::getInstance()->saveGameSetting();
}



bool ViewSetting::init()
{
	do {
		if (!Layer::init())
			return false;


		drawImages();
		drawButtons();
		drawLabels();
		
	} while (0);
	return true;
}

void ViewSetting::drawImages()
{
	Size size = Director::getInstance()->getWinSize();
	pSpriteBack = Sprite::create("image/iPhone/common/" + strBackground->_string);
	Point ptBack = getCenterPoint(rtBackground, size.height);
	pSpriteBack->setPosition(ptBack.x , ptBack.y );
	this->addChild(pSpriteBack);
}



void ViewSetting::drawButtons()
{
	Size size = Director::getInstance()->getWinSize();
	Vector<MenuItem*> items;

	auto soundOn = MenuItemImage::create("image/iPhone/eng/" + strOnBtn->_string, "image/iPhone/eng/" + strOnBtn->_string);
	auto soundOff = MenuItemImage::create("image/iPhone/eng/" + strOffBtn->_string, "image/iPhone/eng/" + strOffBtn->_string);

	Vector<MenuItem*> toggleItems;
	toggleItems.pushBack(soundOn);
	toggleItems.pushBack(soundOff);

	soundToggle = MenuItemToggle::createWithCallback(std::bind(menu_selector(ViewSetting::menuCallbackHandler), this, std::placeholders::_1), toggleItems);
	soundToggle->setTag(kMenuSound);
	soundToggle->setPosition(getPointWithBackFrom3GRect(rtSoundBtn, rtBackground, size.height));
	items.pushBack(soundToggle);
	 
	auto vibrationOn = MenuItemImage::create("image/iPhone/eng/" + strOnBtn->_string, "image/iPhone/eng/" + strOnBtn->_string);
	auto vibrationOff = MenuItemImage::create("image/iPhone/eng/" + strOffBtn->_string, "image/iPhone/eng/" + strOffBtn->_string);

	toggleItems.clear();
	toggleItems.pushBack(vibrationOn);
	toggleItems.pushBack(vibrationOff);

	vibrationToggle = MenuItemToggle::createWithCallback(std::bind(menu_selector(ViewSetting::menuCallbackHandler), this, std::placeholders::_1), toggleItems);
	vibrationToggle->setPosition(getPointWithBackFrom3GRect(rtVibrationBtn, rtBackground, size.height));
	vibrationToggle->setTag(kMenuVibration);
	items.pushBack(vibrationToggle);


	auto blockChatOn = MenuItemImage::create("image/iPhone/eng/" + strOnBtn->_string, "image/iPhone/eng/" + strOnBtn->_string);
	auto blockChatOff = MenuItemImage::create("image/iPhone/eng/" + strOffBtn->_string, "image/iPhone/eng/" + strOffBtn->_string);

	toggleItems.clear();
	toggleItems.pushBack(blockChatOn);
	toggleItems.pushBack(blockChatOff);

	blockChatToggle = MenuItemToggle::createWithCallback(std::bind(menu_selector(ViewSetting::menuCallbackHandler), this, std::placeholders::_1), toggleItems);
	blockChatToggle->setTag(kMenuBlockChat);
	blockChatToggle->setPosition(getPointWithBackFrom3GRect(rtBlockChatBtn, rtBackground, size.height));
	items.pushBack(blockChatToggle);

	auto friendStateOn = MenuItemImage::create("image/iPhone/eng/" + strOnBtn->_string, "image/iPhone/eng/" + strOnBtn->_string);
	auto friendStateOff = MenuItemImage::create("image/iPhone/eng/" + strOffBtn->_string, "image/iPhone/eng/" + strOffBtn->_string);

	toggleItems.clear();
	toggleItems.pushBack(friendStateOn);
	toggleItems.pushBack(friendStateOff);

	friendStateToggle = MenuItemToggle::createWithCallback(std::bind(menu_selector(ViewSetting::menuCallbackHandler), this, std::placeholders::_1), toggleItems);
	friendStateToggle->setPosition(getPointWithBackFrom3GRect(rtFriendStateBtn, rtBackground, size.height));
	friendStateToggle->setTag(kMenuFriendState);
	items.pushBack(friendStateToggle);
	

	//String *debugString = new String();
	//debugString->initWithFormat("Soundbutton x = %f , Soundbutton y = %f", getPointWithBackFrom3GRect(rtSoundBtn, rtBackground, size.height).x, getPointWithBackFrom3GRect(rtSoundBtn, rtBackground, size.height).y);
	//
	//MessageBox(debugString->getCString(), "debug");
	auto pMenu = Menu::createWithArray(items);
	pMenu->setPosition(Vec2::ZERO);
	//pSpriteBack->addChild(pMenu);
	this->addChild(pMenu);


	if (!CGameSetting::getInstance()->IsSoundOn()) {
		soundToggle->setSelectedIndex(1);
	}
	else {
		soundToggle->setSelectedIndex(0);
	}
	if (!CGameSetting::getInstance()->IsVibration()) {
		vibrationToggle->setSelectedIndex(1);
	}
	else {
		vibrationToggle->setSelectedIndex(0);
	}

	if (!CGameSetting::getInstance()->IsChatBlock()) {
		blockChatToggle->setSelectedIndex(1);
	}
	else {
		blockChatToggle->setSelectedIndex(0);
	}

	if (!CGameSetting::getInstance()->IsFriendState()) {
		friendStateToggle->setSelectedIndex(1);
	}
	else {
		friendStateToggle->setSelectedIndex(0);
	}

}



void ViewSetting::drawLabels()
{
	Size size = Director::getInstance()->getWinSize();
	auto soundLabel = CCLabelTTF::create(strSound->_string, g_FontName->_string, 16, getRectFrom3GRect(rtSoundLabel).size);
	soundLabel->setPosition(Vec2(getPointWithBackFrom3GRect(rtSoundLabel,rtBackground,size.height)));
	soundLabel->setColor(ccc3(82, 66, 30));
	this->addChild(soundLabel);

	auto *vibrationLabel = CCLabelTTF::create(strVibration->_string, g_FontName->_string, 16, getRectFrom3GRect(rtVibrationLabel).size);
	vibrationLabel->setPosition(Vec2(getPointWithBackFrom3GRect(rtVibrationLabel, rtBackground, size.height)));
	vibrationLabel->setColor(ccc3(82, 66, 30));
	this->addChild(vibrationLabel);

	auto *blockChatLabel = CCLabelTTF::create(strBlockChat->_string, g_FontName->_string, 16, getRectFrom3GRect(rtBlockChatLabel).size);
	blockChatLabel->setPosition(Vec2(getPointWithBackFrom3GRect(rtBlockChatLabel, rtBackground, size.height)));
	blockChatLabel->setColor(ccc3(82, 66, 30));
	this->addChild(blockChatLabel);

	auto *friendStateLabel = CCLabelTTF::create(strFriendState->_string, g_FontName->_string, 16, getRectFrom3GRect(rtFriendStateLabel).size);
	friendStateLabel->setPosition(Vec2(getPointWithBackFrom3GRect(rtFriendStateLabel, rtBackground, size.height)));
	friendStateLabel->setColor(ccc3(82, 66, 30));
	this->addChild(friendStateLabel);
}

void ViewSetting::menuCallbackHandler(Ref * pSender)
{
	CallFunc * callFunc = NULL;
	int tag = ((MenuItem*)pSender)->getTag();
	switch (tag)
	{
		case kMenuSound:
			onSound();
			break;
		case kMenuVibration:
			onVibration();
			break;
		case kMenuBlockChat:
			onBlockChat();
			break;
		case kMenuFriendState:
			onFriendStatus();
			break;
	}

}

void ViewSetting::onSound()
{
	bool bMute = CGameSetting::getInstance()->IsSoundOn();

	CGameSetting::getInstance()->setSound(!bMute);
	
	if (CGameSetting::getInstance()->IsSoundOn()) {
		soundToggle->setSelectedIndex(1);
	}
	else {
		soundToggle->setSelectedIndex(0);
	}
}

void ViewSetting::onVibration()
{
	bool bVibration = CGameSetting::getInstance()->IsVibration();
	CGameSetting::getInstance()->setVibration(!bVibration);
	if (!CGameSetting::getInstance()->IsVibration()) {
		vibrationToggle->setSelectedIndex(1);
	}
	else {
		vibrationToggle->setSelectedIndex(0);
	}
}
void ViewSetting::onBlockChat()
{
	bool bChatBlock = CGameSetting::getInstance()->IsChatBlock();
	CGameSetting::getInstance()->setChatBlock(!bChatBlock);
	if (!CGameSetting::getInstance()->IsChatBlock()) {
		blockChatToggle->setSelectedIndex(1);
	}
	else {
		blockChatToggle->setSelectedIndex(0);
	}
}
void ViewSetting::onFriendStatus()
{
	bool bFriendStatus = CGameSetting::getInstance()->IsFriendState();
	CGameSetting::getInstance()->setFriendState(!bFriendStatus);
	if (!CGameSetting::getInstance()->IsFriendState()) {
		friendStateToggle->setSelectedIndex(1);
	}
	else {
		friendStateToggle->setSelectedIndex(0);
	}
}
