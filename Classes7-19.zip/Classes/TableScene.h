#ifndef __TABLE_SCENE_H__
#define __TABLE_SCENE_H__

#include "cocos2d.h"
#include "Global.h"
#include "AppDelegate.h"
#include "TextureManager.h"
#include "cocos-ext.h"
#include "UIPlayer.h"
#include "PlayController.h"
#include "TimerCtrl.h"

using namespace cocos2d;

class CardManager;
class TableScene : public cocos2d::Layer, public cocos2d::ui::EditBoxDelegate
{
public:
    static cocos2d::Scene* createScene();

    virtual bool init();
    virtual void onEnter();
    virtual void onExit();
    
	TableScene() {};
	~TableScene() {};
	CCLabelTTF*				m_pChatContent[MAX_CHAT_COUNT];
	CCLabelTTF*				m_pChatHistory[2];

    PlayController *          m_playController;
	CardManager*			m_pCardManager;

	void showTimerCtrl(bool bShow);
    void setAction(int nPlayerID, char*cards, int nCardCount, bool bFromServer);
    void startGame(bool bFromServer);
	void menuCallbackHandler(Ref* pSender);
	void drawChatCtrls();
	void drawImages();
	void drawButtons();
	void drawLabels();
	void initTextField();
	void showActionButtons(bool bShow);
	void updateUIPlayer(int nSeatID, bool bWhenSit);
	void sit(int nSeatID, int nPlayerID, bool bFromServer);
	CCPoint getPlayerPos(int nPos);
	bool sitAuto();
	int getSelectedCardsCount(int nPos);
	void finishGame(TID nWinnerID, bool bFromServer);
	void drawTimerCtrl();
	void changeTableState();
public:
	void onMenu();
    void onBtnOK();
	void onBtnPass();
    // implement the "static create()" method manually
    CREATE_FUNC(TableScene);
private:
	ui::EditBox*			textChatMessage;
	UIPlayer* 				m_pPlayers;
	double					m_fClearCardsDelayTime;

	CCMenuItemImage*				m_pFriendBtn;
	CCMenuItemImage*				m_pMenuBtn;
	CCMenuItemImage*				m_pOKBtn;
	CCMenuItemImage*				m_pPassBtn;
	CCMenuItemImage*				m_pChatBtn;
	CCLabelTTF * m_pStackLabel;
	CCLabelTTF * m_pTableNameLabel;
	TimerCtrl*				m_pTimerCtrl;
	CCSprite*				m_pChatBack;
	CCSprite*				m_pChatBackground;


	virtual void editBoxEditingDidBegin(cocos2d::ui::EditBox* editBox)override;
	virtual void editBoxEditingDidEnd(cocos2d::ui::EditBox* editBox)override;
	virtual void editBoxTextChanged(cocos2d::ui::EditBox* editBox, const std::string& text)override;
	virtual void editBoxReturn(cocos2d::ui::EditBox* editBox)override;

    CCSprite *pSpriteBack;
};

#endif //__TABLE_SCENE_H__
