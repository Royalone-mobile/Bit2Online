#ifndef __UIBLINDBAR_H__
#define __UIBLINDBAR_H__

#include "cocos2d.h"
#include "base\Common.h"

using namespace cocos2d;
class SelTableScene;

class UIBlindBar : public cocos2d::Layer
{
public:
	UIBlindBar(void) {};
	virtual ~UIBlindBar(void) {};

    static cocos2d::Scene* createScene();

    virtual bool init();

	void initBlindBar(SelTableScene*pView);
	void displayStake();
	void setStake(TCASH fStake);
	void setAnimation(bool bLeft);
	void enableBlindBar(bool bEnable);

	CREATE_FUNC(UIBlindBar);
private:	
	CCLabelTTF*			m_pBlindLabel[3];
	CCImage*			m_pSplitImage;
	CCPoint				m_ptFirstPos;
	SelTableScene*		m_pParent;
	int	m_nCurDispIndex;
	int	m_nBlindTouchMoveCount;
	bool				m_bEnable;



	void menuCallbackHandler(Ref * pSender);

    // implement the "static create()" method manually

};

#endif // __UIBLINDBAR_H__
