#ifndef __PLAYCONTROLLER_H__
#define __PLAYCONTROLLER_H__

#include "cocos2d.h"
#include "Global.h"
#include "AppDelegate.h"

using namespace cocos2d;
class PlayController : public cocos2d::Layer

{
public:
    static cocos2d::Scene* createScene();
    
    
    bool	setPlayerAction(int nPlayerID, char* cards, unsigned long nCardCount);
    
    void sitAutoAIPlayer();
    void playAICards(float dt);
    virtual bool init();
    virtual void onExit();
    virtual void onEnter();
    
    // implement the "static create()" method manually
    CREATE_FUNC(PlayController);
};

#endif // __PLAYCONTROLLER_H__
