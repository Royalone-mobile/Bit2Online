#ifndef __TIMER_CTRL_H__
#define __TIMER_CTRL_H__

#include "cocos2d.h"
#include "Global.h"
#include "AppDelegate.h"

class TableScene;

#define STICK_COUNT 25

using namespace cocos2d;
class TimerCtrl : public cocos2d::Layer

{
public:
	static cocos2d::Scene* createScene();
	virtual bool init();

	void initTimerCtrl(TableScene *pView, float fTotalTime);
	void refreshTimerCtrl(TCASH fMaxTime, CCPoint pos);
	void closeTimerCtrl();
	void drawSticks();
	void moveWindow(CCRect rt);
	void onTimer(double cur_time);


	// implement the "static create()" method manually
	CREATE_FUNC(TimerCtrl);
private:

	CCRect				m_rtMainWindow;
	TableScene*			m_pParent;

	CCSprite*			m_pRemainStickImage[STICK_COUNT];
	CCSprite*			m_pUsedStickImage[STICK_COUNT];
	CCSprite*			m_pClockImage;

	double				m_fTotalTime;
	double				m_fRemainTime;
	double				m_timeStart;

	CCLabelTTF*			m_pMinLabel;
	CCLabelTTF*			m_pMaxLabel;

    CCSprite *pSpriteBack;
	double m_fStartTime;
	double m_fEndTime;
};

#endif // __RESULT_SCENE_H__
