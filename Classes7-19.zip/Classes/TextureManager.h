#ifndef __TEXTURE_MANAGER_H__
#define __TEXTURE_MANAGER_H__

#include <map>
#include "cocos2d.h"
#include "Global.h"
USING_NS_CC;

struct TextureRect {
	CCRect rt[3];
};



enum ObjectPicture {
	Pic_Table_card1 = 0,
	Pic_Table_cardback = Pic_Table_card1 + 52,
	Pic_Table_Pan_Menu,
	Pic_Table_Btn_Menu0,
	Pic_Table_Btn_Menu1,
	Pic_Table_Btn_Friend0,
	Pic_Table_Btn_Friend1,
	Pic_Table_Btn_Ok0,
	Pic_Table_Btn_Ok1,
	Pic_Table_Btn_Ok2,
	Pic_Table_Btn_Pass0,
	Pic_Table_Btn_Pass1,
	Pic_Table_Btn_Pass2,
	Pic_Table_Btn_sit,
	Pic_Table_Pan_Player,
	Pic_Table_Pan_Waitting,
	Pic_Table_Btn_Chat0,
	Pic_Table_Btn_Chat1,
	Pic_Table_Chat_Ballon,
	Pic_Table_Img_Win,
};

typedef std::map<int, TextureRect>  TTextureRect;

class TextureManager
{
	TTextureRect m_TextureRect;
	int m_nDeviceType;
public:
	TextureManager();
	~TextureManager();
	
	void setDeviceType(int nDevType);
	CCRect getTextureRect(int nObjName);
};

#endif //__TEXTURE_MANAGER_H__