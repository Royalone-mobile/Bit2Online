#include "UITableCards.h"
#include "TextureManager.h"
#include "base/NetLogic.h"

#define VIEW_WIDTH 100
#define VIEW_HEIGHT 60

extern TextureManager g_TextureManager;

static const CCRect rt_Card = CCRectMake(0, 0, 48, 60);
static const int nInterval_Card_Table = 13;
static const int nInterval_Card_Main = 22;
static const int nInterval_Card_Other = 11;
static const int nUpPoint = 10;

CCPoint ptPlayerCardPos[] =
{
	{ 94, 240 },
	{ 320, 192 },
	{ 179, 97 },
	{ 2, 192 },
};

CCSize sizeCard[] =
{
	{ 48, 72 },
	{ 21, 28 },
};

static const CCPoint ptTableCardPos[] = {
	{ 213, 177 },
	{ 264, 143 },
	{ 213, 119 },
	{ 162, 143 },
};

PlayerCard::PlayerCard()
	:nPlayerCardCount(0)
	, nTableCardCount(0)
{
	int i = 0;
	for (i = 0; i < CARD_COUNT_PER_PLAYER; i++) {
		playerCards[i] = 0;
		selected[i] = false;
		ctrlPlayerCards[i] = NULL;
		ctrlTableCards[i] = NULL;
	}
	for (i = 0; i < MAX_CARD_COUNT; i++) {
		tableCards[i] = 0;
	}
}

//iPad Position
CCPoint ptPadMainPlayerCardPos = CCPointMake(78, 232);





Scene* CardManager::createScene()
{
	// 'scene' is an autorelease object
	Scene* scene = NULL;
	do {

	scene = Scene::create();

	// 'layer' is an autorelease object
	auto layer = CardManager::create();

	scene->addChild(layer);
	} while (0);
	return scene;
}

// on "init" you need to initialize your instance
bool CardManager::init()
{
    //////////////////////////////
	do {
		if (!Layer::init())
		{
			return false;
		}
		addEvents();
	} while (0);
    return true;
}


void CardManager::initCardManager(TableScene *pParent)
{
	CCTexture2D * texture = CCTextureCache::getInstance()->addImage("image/iPhone/common/table_res.png");
	CCRect rt;
	for (int i = 0; i < CARD_COUNT; i++) {
		m_FrontCards[i] = Sprite::createWithTexture(texture);
		rt = g_TextureManager.getTextureRect(Pic_Table_card1 + i);
		m_FrontCards[i]->setTextureRect(rt);
        
        CCSprite * btnSprite0 = Sprite::createWithTexture(texture);
			
		rt = g_TextureManager.getTextureRect(Pic_Table_Btn_Menu0);
		btnSprite0->setTextureRect(rt);

		m_BackCards[i] = Sprite::createWithTexture(texture);
		
		rt = g_TextureManager.getTextureRect(Pic_Table_cardback);
		m_BackCards[i]->setTextureRect(rt);

		m_BackCards[i]->setScale(0.5);
		//m_FrontCards[i]->setVisible(false);
		m_BackCards[i]->setVisible(false);
        

		int z = i;
		if (i < 8)
			z += CARD_COUNT;
		this->addChild(m_FrontCards[i]);
		this->addChild(m_BackCards[i]);
	}
	this->setTouchEnabled(true);
}

void CardManager::setParent(TableScene *parent)
{
    m_pParent = parent;
    
}
void CardManager::clearCardManager()
{
	for (int i = 0; i < CARD_COUNT; i++)
	{
		m_FrontCards[i]->setVisible(false);
		m_BackCards[i]->setVisible(false);
	}
	for (int nPlayerPos = 0; nPlayerPos < MAX_PLAYER_COUNT; nPlayerPos++)
	{
		PlayerCard& player = m_player[nPlayerPos];
		int nCardPos = 0;
		for (nCardPos = 0; nCardPos < CARD_COUNT_PER_PLAYER; nCardPos++) {
			player.playerCards[nCardPos] = 0;
			player.selected[nCardPos] = false;
			player.ctrlPlayerCards[nCardPos] = NULL;

		}
		for (nCardPos = 0; nCardPos < MAX_CARD_COUNT; nCardPos++) {
			player.tableCards[nCardPos] = 0;
			player.ctrlTableCards[nCardPos] = NULL;
		}
		player.nPlayerCardCount = 0;
		player.nTableCardCount = 0;
	}
}

PlayerCard* CardManager::getPlayer(int nID)
{
	return &(m_player[nID]);
}

void CardManager::click(int nCardID)
{
	if (m_bSelectable == false)
		return;
	PlayerCard& mainPlayer = m_player[0];
	int nCardPos = this->getCardPos(0, nCardID);
		
	mainPlayer.selected[nCardPos] = !mainPlayer.selected[nCardPos];
	this->drawClickedCard(nCardID);
	if (m_pParent) {
		m_pParent->showActionButtons(true);
	}
	return;
}

void CardManager::setCardCount(int nID, int nCardCount)
{
	m_player[nID].nPlayerCardCount = nCardCount;
}


int CardManager::getCardCount(int nID)
{
	return m_player[nID].nPlayerCardCount;
}


void CardManager::setCards(int nID, const char *cards)
{
	PlayerCard& player = m_player[nID];
	player.nPlayerCardCount = 0;
	for (int i = 0; i < CARD_COUNT_PER_PLAYER; i++)
	{
		player.playerCards[i] = cards[i];
		if (cards[i] != 0)
			player.nPlayerCardCount++;
	}
	this->drawPlayerCards(nID);
}


char* CardManager::getCards(int nID)
{
	return m_player[nID].playerCards;
}


char CardManager::getCard(int nID, int nCardID)
{
	return m_player[nID].playerCards[nCardID];
}


bool CardManager::isSelected(int nID, int nCardID)
{
	return m_player[nID].selected[nCardID];
}

void CardManager::setTableCards(int nID, char* cards, int nCardCount)
{
	PlayerCard& player = m_player[nID];

	player.nTableCardCount = nCardCount;
	for (int i = 0; i < nCardCount; i++)
	{
		player.tableCards[i] = cards[i];
		for (int j = 0; j < CARD_COUNT_PER_PLAYER; j++) {
			if (m_player[nID].playerCards[j] == cards[i])
				m_player[nID].playerCards[j] = 0;
		}
	}

	this->drawTableCards(nID);
}

void CardManager::refreshSelect()
{
	for (int i = 0; i < CARD_COUNT_PER_PLAYER; i++) {
		m_player[0].selected[i] = false;
		
		if (m_player[0].playerCards[i] > 0)
			this->drawClickedCard(i);
	}
}

void CardManager::drawPlayerCards(int nID)
{
	CCSize size = Director::getInstance()->getWinSize();

	int i = 0;
	PlayerCard* player = &(m_player[nID]);
	for (i = 0; i < CARD_COUNT_PER_PLAYER; i++) {
		if (player->ctrlPlayerCards[i] != NULL)
		{
			player->ctrlPlayerCards[i]->setVisible(false);
			player->ctrlPlayerCards[i] = NULL;
		}
	}
	int nCardPos = -1;
	for (i = 0; i < CARD_COUNT_PER_PLAYER; i++) {
		if (player->playerCards[i] != 0) {
			nCardPos++;
            
			//int nCardPos = [self getCardPos:nID nCardID:i];
			CCRect rt;
			if (nID == 0) {
				if (NetLogic_GetUserState() == stateTableSeat)
					player->ctrlPlayerCards[nCardPos] = m_FrontCards[player->playerCards[i] - 1];
				else {
					player->ctrlPlayerCards[nCardPos] = m_BackCards[player->playerCards[i] - 1];
				}

				rt = CCRectMake(ptPlayerCardPos[nID].x + nInterval_Card_Main * nCardPos
					, ptPlayerCardPos[nID].y
					, sizeCard[0].width
					, sizeCard[0].height);
				if (player->selected[nCardPos] == true)
					rt.origin.y -= nUpPoint;
				player->ctrlPlayerCards[nCardPos]->setScale(1.0);
			}
			else {
				player->ctrlPlayerCards[nCardPos] = m_BackCards[player->playerCards[i] - 1];
				rt = CCRectMake(ptPlayerCardPos[nID].x + nInterval_Card_Other * nCardPos
					, ptPlayerCardPos[nID].y
					, sizeCard[1].width
					, sizeCard[1].height);
				player->ctrlPlayerCards[nCardPos]->setScale(0.5);
			}
			player->ctrlPlayerCards[nCardPos]->setPosition(getPointFrom3GRect(rt, size.height)); 

			m_FrontCards[player->playerCards[i] - 1]->setPosition(getPointFrom3GRect(rt, size.height));
			m_FrontCards[player->playerCards[i] - 1]->setScale(1.0);
			

			player->ctrlPlayerCards[nCardPos]->setVisible(true); 
			player->ctrlPlayerCards[nCardPos]->getParent()->reorderChild(player->ctrlPlayerCards[nCardPos], nCardPos);
		}
	}
}


void CardManager::drawTableCards(int nID)
{
	CCSize size = Director::getInstance()->getWinSize();

	int i = 0;
	PlayerCard* player = &(m_player[nID]);
	for (; i < MAX_CARD_COUNT; i++) {
		if (player->ctrlTableCards[i] != NULL)
		{
			player->ctrlTableCards[i]->setVisible(false);
			player->ctrlTableCards[i] = NULL;
		}
	}
	for (i = 0; i < player->nTableCardCount; i++) {
		player->ctrlTableCards[i] = m_FrontCards[player->tableCards[i] - 1];

		CCRect rt = CCRectMake(ptTableCardPos[nID].x + nInterval_Card_Main * i,
			ptTableCardPos[nID].y,
			sizeCard[1].width,
			sizeCard[1].height);

		rt = getRectFrom3GRect(rt);

		auto action1 = CCMoveTo::create(0.5, getCenterPoint(rt, size.height));
		auto action2 = CCScaleTo::create(0.5, 1.0);
		
		auto action = CCSpawn::createWithTwoActions(action1, action2);
		player->ctrlTableCards[i]->runAction(action);
		player->ctrlTableCards[i]->setVisible(true);

		static int z = 100;
		z++;

		player->ctrlTableCards[i]->getParent()->reorderChild(player->ctrlTableCards[i], z);
	}
}


void CardManager::drawClickedCard(int nCardID)
{
	CCSize size = Director::getInstance()->getWinSize();
	PlayerCard* player = &m_player[0];
	if (player->playerCards[nCardID] <= 0)
		return;
	int nCardPos = this->getCardPos(0, nCardID);

		
	CCRect rt = CCRectMake(ptPlayerCardPos[0].x + nInterval_Card_Main * nCardPos
		, ptPlayerCardPos[0].y
		, sizeCard[0].width
		, sizeCard[0].height);
	if (player->selected[nCardPos] == true)
		rt.origin.y -= nUpPoint;
	player->ctrlPlayerCards[nCardPos]->setPosition(getPointFrom3GRect(rt, size.height));
}
int CardManager::getCardPos(int nPlayerPos, int nCardID)
{
	int nCardPos = 0;
	PlayerCard& player = m_player[nPlayerPos];
	for (int i = 0; i < nCardID; i++)
	{
		if (player.playerCards[i] != 0)
			nCardPos++;
	}
	return nCardPos;
}
int CardManager::getCardID(int nPlayerPos, int nCardPos)
{
	PlayerCard& player = m_player[nPlayerPos];
	int i = 0;
	for (; i <CARD_COUNT_PER_PLAYER; i++) {
		if (player.playerCards[i] == 0)
			continue;
		if (nCardPos == 0)
			break;
		if (player.playerCards[i] != 0)
			nCardPos--;
	}
	return i;

}
void CardManager::setSelectable(bool bSelectable)
{
	m_bSelectable = bSelectable;
}


void CardManager::addEvents()
{
	auto listener = cocos2d::EventListenerTouchOneByOne::create();
	listener->setSwallowTouches(true);

	listener->onTouchBegan = [&](cocos2d::Touch* touch, cocos2d::Event* event)
	{
		return true; // we did not consume this event, pass thru.
	};

	listener->onTouchEnded = [=](cocos2d::Touch* touch, cocos2d::Event* event)
	{
		int nSeatID = NetLogic_GetSeatID();
		int nPos = getPosfromSeatID(nSeatID);
		int nCardCount = this->getCardCount(0);
        
		cocos2d::Vec2 location = touch->getLocationInView();

		for (int i = 0; i < nCardCount; i++) {
			CCRect rt;
			if (i != nCardCount - 1) {
				rt = CCRectMake(ptPlayerCardPos[0].x + nInterval_Card_Main * i
					, ptPlayerCardPos[0].y
					, nInterval_Card_Main
					, sizeCard[0].height);

			}
			else {
				rt = CCRectMake(ptPlayerCardPos[0].x + nInterval_Card_Main * i
					, ptPlayerCardPos[0].y
					, rt_Card.size.width
					, sizeCard[0].height);

			}
            
			rt = getRectFrom3GRect(rt);
            
           
            int width = rt.getMaxX()-rt.getMinX();
            int height = rt.getMaxY() - rt.getMinY();
            auto glview = Director::getInstance()->getOpenGLView();
            auto frameSize = glview->getVisibleSize();
            auto visibleSize = glview->getDesignResolutionSize();
            
            float g_scale = CGameSetting::getInstance()->g_scaleFactor;
            

            float heightRate = frameSize.height/visibleSize.height;
            
            
            rt = CCRectMake(rt.getMinX(), rt.getMinY()*heightRate, width, height);

			if (rt.containsPoint(location)) {
				PlayerCard& mainPlayer = m_player[0];
				int nCardID = this->getCardID(0, i);
				if (mainPlayer.playerCards[nCardID] != 0) {
					this->click(nCardID);
					break;
				}
			}
		}
		return true; // we did not consume this event, pass thru.
	};

	cocos2d::Director::getInstance()->getEventDispatcher()->addEventListenerWithFixedPriority(listener, 30);
}

void CardManager::touchEvent(cocos2d::Touch* touch)
{

}

void CardManager::menuCallbackHandler(Ref * pSender)
{
	
}

