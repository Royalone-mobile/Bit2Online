#include "SelTableScene.h"
#include "SimpleAudioEngine.h"
#include "Global.h"
#include "ViewSetting.h"
#include "CreateTableScene.h"
#include "UIBlindBar.h"


USING_NS_CC_EXT;
using namespace CocosDenshion;
using namespace network;

enum {
	kTagFriendLayer,
	kTagInviteLayer,
	kTagHelpLayer,
	kTagCreateTableLayer,
	kTagRegisterLayer,
	kTagRankingLayer,
	kTagFindUserLayer,
	kTagLayerCount,
};


#define TOP_LAYER_ZORDER		1001
#define NAME_WIDTH				75
#define TABLE_NAME_WIDTH		60

extern char m_UserPhoto[MAX_USERNAME_LEN];
extern int nArrangeOption;
extern bool bArrangeAscending;
extern int nViewOption;

extern int nCurGroupType;
extern int nCurLang;

CCPoint ptChaImgPos[] = {
	{ 351, 115 },
	{ 351, 200 },
	{ 166, 200 },
	{ 166, 115 },
};

static const CCRect rtBackBtn = CCRectMake(426, 12, 37, 17);
static const CCRect rtRankingBtn = CCRectMake(350, 15, 30, 14);
static const CCRect rtFindUserBtn = CCRectMake(350, 36, 30, 14);
static const CCRect rtCreateRoomBtn = CCRectMake(4, 154, 116, 30);
static const CCRect rtFriendBtn = CCRectMake(4, 186, 116, 30);
static const CCRect rtPlayNowBtn = CCRectMake(4, 218, 116, 30);
static const CCRect rtMainMenu = CCRectMake(4, 250, 116, 30);
static const CCRect rtHelpBtn = CCRectMake(4, 283, 116, 30);
static const CCRect rtHideFullBtn = CCRectMake(340, 292, 63, 14);
static const CCRect rtShowAllBtn = CCRectMake(406, 292, 63, 14);
static const CCRect rtArrangeNameBtn = CCRectMake(16, 119, 55, 7);
static const CCRect rtArrangeblindBtn = CCRectMake(16, 133, 50, 7);
static const CCRect rtdrawChaImage = CCRectMake(410, 51, 45, 45);
static const CCRect rtdrawArrangeImage = CCRectMake(14, 102, 55, 9);
static const CCRect rtNameLabel = CCRectMake(339, 66, 64, 14);
static const CCRect rtBalanceLabel = CCRectMake(339, 87, 64, 9);
static const CCRect rtLobbyTable = CCRectMake(204, 117, 164, 160);
static const CCRect rtTableNameLbl = CCRectMake(273, 173, 32, 8);
static const CCRect rtTableStakeLbl = CCRectMake(273, 188, 32, 8);
static const CCRect rtTableStateLbl = CCRectMake(273, 198, 32, 8);
static const CCRect rtBlindBar = CCRectMake(128, 292, 212, 16);
static const CCRect rtLobbyInfoPan = CCRectMake(259, 170, 61, 41);

// friendlayer rect
static const CCRect rtOnlineFriendTable = CCRectMake(6, 34, 72, 84);
static const CCRect rtOfflineFriendTable = CCRectMake(83, 34, 72, 84);

static const CCRect rtPadOnlineFriendTable = CCRectMake(11, 68, 148, 170);
static const CCRect rtPadOfflineFriendTable = CCRectMake(163, 68, 148, 170);

static const CCRect rtFriendLayer = CCRectMake(215, 130, 162, 145);
static const CCRect rtPadFriendLayer = CCRectMake(698, 513, 323, 290);

//FindUser rect
static const CCRect rtFindUserLayer = CCRectMake(154, 30, 189, 254);
static const CCRect rtPadFindUserLayer = CCRectMake(308, 60, 378, 507);

static CCString* strBKImageName = new CCString("lobbyback.png");
static CCString* strExitImageNml = new CCString("btn_exit_0_e.png");
static CCString* strExitImageAct = new CCString("btn_exit_1_e.png");
static CCString* strCreateImageNml = new CCString("btn_creatroom_nml_e.png");
static CCString* strCreateImageAct = new CCString("btn_creatroom_act_e.png"); 
static CCString* strFriendImageNml = new CCString("btn_friendlobby_0_e.png");
static CCString* strFriendImageAct = new CCString("btn_friendlobby_1_e.png");
static CCString* strPlayNowImageNml = new CCString("btn_playnow_0_e.png");
static CCString* strPlayNowImageAct = new CCString("btn_playnow_1_e.png");
static CCString* strMainMenuImageNml = new CCString("btn_mainmenu_0_e.png");
static CCString* strMainMenuImageAct = new CCString("btn_mainmenu_1_e.png");
static CCString* strHelpImageNml = new CCString("btn_help_0_e.png");
static CCString* strHelpImageAct = new CCString("btn_help_1_e.png");
static CCString* strLobbyTableImage = new CCString("lobbytable.png");
static CCString* strArrangeImageName = new CCString("arrangeby_e.png");
static CCString* strHideFullImageNml = new CCString("btn_hidefulltables_0.png");
static CCString* strHideFullImageAct = new CCString("btn_hidefulltables_1.png");
static CCString* strShowAllImageNml = new CCString("btn_viewalltables_0.png");
static CCString* strShowAllImageAct = new CCString("btn_viewalltables_1.png");
static CCString* strLobbyInfoPan = new CCString("pan_info_lobby.png");
static CCString* strRankingBtnNml = new CCString("ranking-0.png");
static CCString* strRankingBtnAct = new CCString("ranking-1.png");
static CCString* strFindUserBtn1 = new CCString("btn_finduser_00.png");
static CCString* strFindUserBtn2 = new CCString("btn_finduser_01.png");

static CCString* strArrangeBtnFontName = new CCString("American Typewriter");
static CCString* strNameLblFontName = new CCString("Arial");
static CCString* strArrangeBlind = new CCString("Bet Money");
static CCString* strArrangeName = new CCString("Room Name");

static CCString* strArrowUpImage = new CCString("btn_arrow_up.png");
static CCString* strArrowDownImage = new CCString("btn_arrow_down.png");

static CCString* strViewFailAlert = new CCString("Watch table failed.");

//iPad Position
static const CCPoint ptPadCreateBtn = CCPointMake(122, 225);
static const CCPoint ptPadPlayNowBtn = CCPointMake(122, 161);
static const CCPoint ptPadMainMenuBtn = CCPointMake(122, 98);
static const CCPoint ptPadHelpBtn = CCPointMake(122, 37);
static const CCPoint ptPadHideFullBtn = CCPointMake(488, 235);
static const CCPoint ptPadShowAllBtn = CCPointMake(619, 235);
static const CCPoint ptPadChaImage = CCPointMake(943, 622);
static const CCPoint ptPadNameLabel = CCPointMake(800, 620);
static const CCPoint ptPadBalanceLabel = CCPointMake(800, 584);
static const CCPoint ptPadTableNameLbl = CCPointMake(504, 446);
static const CCPoint ptPadTableStateLbl = CCPointMake(504, 421);
static const CCPoint ptPadTableStakeLbl = CCPointMake(504, 394);
static const CCPoint ptPadTableImage = CCPointMake(504, 396);
static const CCPoint ptPadLobbyInfoPan = CCPointMake(504, 421);

static const CCPoint ptPadArrangeNameBtn = CCPointMake(356, 206);
static const CCPoint ptPadArrangeBlindBtn = CCPointMake(514, 206);

static const CCRect rtPadLobbyTableAni = CCRectMake(193, 235, 623, 223);
static const CCRect rtPadLobbyTableView = CCRectMake(393, 235, 223, 223);


static const CCRect rtTableViewController = CCRectMake(120, -100, 162, 145);

//static const CCRect rtFriendLayer = CCRectMake(215, 130, 162, 145);


static const CCPoint ptPadTableAniPos[] = {
	CCPointMake(504, 396),
	CCPointMake(404, 396),
	CCPointMake(324, 396),
	CCPointMake(274, 396),
	CCPointMake(234, 396),
	CCPointMake(774, 396),
	CCPointMake(734, 396),
	CCPointMake(684, 396),
	CCPointMake(604, 396)
};

static const int nTableAniZValue[] = { 5, 4, 3, 2, 1, 1, 2, 3, 4 };

CCPoint ptPadChaImgPos[] = {
	{ 504, 517 },
	{ 403, 426 },
	{ 504, 325 },
	{ 605, 426 },
};


Scene* SelTableScene::createScene()
{
	// 'scene' is an autorelease object
	Scene* scene = NULL;
	do {

	scene = Scene::create();

	// 'layer' is an autorelease object
	auto layer = SelTableScene::create();

	scene->addChild(layer);
	} while (0);
	return scene;
}

// on "init" you need to initialize your instance
bool SelTableScene::init()
{
    //////////////////////////////
	do {
		if (!Layer::init())
		{
			return false;
		}
		
		drawImages();
		drawButtons();
		drawLabels();

		m_pBlindBar = UIBlindBar::create();
		m_pBlindBar->initBlindBar(this);
		this->addChild(m_pBlindBar);

		getTables();

	} while (0);
    return true;
}

void SelTableScene::getTables()
{
	std::vector<std::string> headers;
	headers.push_back("Content-Type: application/json; charset=utf-8");
	HttpRequest *request = new HttpRequest();
	request->setUrl(GET_TABLES_URL);
	request->setRequestType(HttpRequest::Type::GET);
	request->setResponseCallback(this, httpresponse_selector(SelTableScene::onHttpRequestCompleted));
	HttpClient::getInstance()->send(request);
	request->release();
}
void SelTableScene::joinTable(int id)
{
	TABLE_INFO tableInfo = CGameSetting::getInstance()->g_TableList[id];

	//Creating a URL
	HttpRequest *request = new HttpRequest();
	request->setUrl(JOIN_TABLE_URL);
	request->setRequestType(HttpRequest::Type::POST);
	char szUserEmail[MAX_EMAILADDR_LEN];
	CGameSetting::getInstance()->getUserEmail(szUserEmail);

	CCString *playerEmail = new CCString(szUserEmail);
	CCString *str = CCString::createWithFormat("_gameId=%s&playerEmail=%s", tableInfo.tableID->getCString(), playerEmail->getCString());

	const char* postData = str->getCString();
	MessageBox(postData, "");

	request->setRequestData(postData, strlen(postData));
	request->setResponseCallback(this, httpresponse_selector(SelTableScene::onHttpRequestCompleted));
	HttpClient::getInstance()->send(request);
	request->release();
}
void SelTableScene::parseGetTables(Json::Value root)
{
	CCString *strGameName;
	CCString *strStatus;
	double stake = 0.0f;
	TABLE_INFO tableInfo;
	CGameSetting::getInstance()->g_TableList.clear();
	for (int i = 0; i < root.size(); i++)
	{
		Json::Value item = root[i];
		Json::Value data = item["gameName"];
		char *szGameName = (char*)data.asCString();

		strGameName = new CCString(szGameName);
		data = item["stake"];
		stake = data.asDouble();

		data = item["status"];
		char *szStatus = (char*)data.asCString();

		strStatus = new CCString(szStatus);

		//data = item["gameCreator"];
		//char *szGameCreator = (char*)data.asCString();

		data = item["_id"];
		char *_id = (char*)data.asCString();
		CCString *strTableID = new CCString(_id);
		data = item["playerCount"];
		int playerCount = (int)data.asInt();
		tableInfo.nCurPlayerCount = playerCount;
		tableInfo.szName = strGameName;
		tableInfo.tableID = strTableID;
		tableInfo.stake = stake;
		CGameSetting::getInstance()->g_TableList.push_back(tableInfo);
	}
	m_pTableViewController->reloadData();
}
void SelTableScene::parseJoinTable(Json::Value root)
{
	Json::Value data = root["response"];
	int responseCode = (int)data.asInt();
	if (responseCode == 200)
	{
		MessageBox("Joining Game...", "Notice");
		App->changeSceneWithState(TGAME_TABLE);
	}
}

void SelTableScene::onHttpRequestCompleted(cocos2d::network::HttpClient *sender, cocos2d::network::HttpResponse *response) {
	if (!response) {
		return;
	}

	int statusCode = response->getResponseCode();
	char statusString[64] = {};
	int requestType = 0;
	if (strcmp(response->getHttpRequest()->getUrl(), GET_TABLES_URL) == 0)
		requestType = 1;
	else if (strcmp(response->getHttpRequest()->getUrl(), JOIN_TABLE_URL) == 0)
		requestType = 2;
	switch (statusCode) {
	case 409:
		switch (requestType)
		{
		case 1:
			MessageBox("Email already exists. Please try again", "Notice");
			break;
		case 2:
			MessageBox("Email already exists. Please try again", "Notice");
			break;
		}
		break;
	case 422:
		switch (requestType)
		{
		case 1:
			MessageBox("Failed to get tables", "Notice");
			break;
		case 2:
			MessageBox("Failed to join Table", "Notice");
			break;
		}
		break;
	}

	// A connection failure
	if (!response->isSucceed())
	{
		return;
	}

	std::vector<char> * buffer = response->getResponseData();
	char * strResponse = (char *)malloc(buffer->size() + 1);
	std::string s2(buffer->begin(), buffer->end());
	strcpy(strResponse, s2.c_str());

	Json::Reader reader;
	Json::Value root;
	
	bool res = reader.parse(strResponse, root, false);
	if (res) {
		switch (requestType)
		{
		case 1:
			parseGetTables(root);
			break;
		case 2:
			parseJoinTable(root);
			break;
		}
	}
	else
	{
		return;
	}
}


void SelTableScene::drawImages()
{
	Size size = Director::getInstance()->getWinSize();
	
	pSpriteBack = Sprite::create("image/iPhone/common/"+ strBKImageName->_string);
	pSpriteBack->setPosition(Vec2(size.width * 0.5f, size.height * 0.5f ));
    pSpriteBack->setScale(CGameSetting::getInstance()->g_scaleFactor);
	this->addChild(pSpriteBack);
	
	if (isDeviceIPAD() == false) {
		m_pTableImage[0] = CCSprite::create("image/iPhone/common/" + strLobbyTableImage->_string);
		this->addChild(m_pTableImage[0]);
		m_pTableImage[0]->setPosition(getPointFrom3GRect(rtLobbyTable));
	}
	else {
		for (int i = 0; i < 9; i++) {
			m_pTableImage[i] = CCSprite::create("image/iPhone/common/" + strLobbyTableImage->_string);
			this->addChild(m_pTableImage[i], nTableAniZValue[i]);
		}
		m_pTableImage[0]->setPosition(ptPadTableImage);
	}

	Sprite * m_pPanLobbyInfo = Sprite::create("image/iPhone/common/" + strLobbyInfoPan->_string);

	if (isDeviceIPAD() == false)
		m_pPanLobbyInfo->setPosition(getPointFrom3GRect(rtLobbyInfoPan));
	else
		m_pPanLobbyInfo->setPosition(ptPadLobbyInfoPan);

 	m_pTableViewController = LobbyTableViewController::create();
	m_pTableViewController->setPosition(CCPoint(rtTableViewController.origin.x, rtTableViewController.origin.y));
	m_pTableViewController->setContentSize(CCSize(rtTableViewController.size.width, rtTableViewController.size.height));
	m_pTableViewController->setTableWidthHeight(rtTableViewController.size.width, rtTableViewController.size.height);
	m_pTableViewController->setColor(Color3B(255, 293, 196));
	
	pSpriteBack->addChild(m_pTableViewController);
	pSpriteBack->addChild(m_pPanLobbyInfo,6);
}

void SelTableScene::drawButtons()
{
    Size size = Director::getInstance()->getOpenGLView()->getVisibleSize();

	// Setting Button
	MenuItemImage* m_pBackBtn = MenuItemImage::create("image/iPhone/eng/" + strExitImageNml->_string, "image/iPhone/eng/"+ strExitImageAct->_string);
	m_pBackBtn->setCallback(std::bind(menu_selector(SelTableScene::menuCallbackHandler), this, std::placeholders::_1));
	m_pBackBtn->setPosition(Vec2(getPointFrom3GRect(rtBackBtn, size.height)));
	m_pBackBtn->setTag(kMenuBack);
	// Friends Button
	MenuItemImage* pRankingBtn = MenuItemImage::create("image/iPhone/eng/" + strRankingBtnNml->_string, "image/iPhone/eng/" + strRankingBtnAct->_string);
	pRankingBtn->setCallback(std::bind(menu_selector(SelTableScene::menuCallbackHandler), this, std::placeholders::_1));
	pRankingBtn->setPosition(Vec2(getPointFrom3GRect(rtRankingBtn, size.height)));
	pRankingBtn->setTag(kMenuRanking);
	// Buy Chips Button
    
	MenuItemImage* pFindUserBtn = MenuItemImage::create("image/iPhone/eng/" + strFindUserBtn1->_string, "image/iPhone/eng/" + strFindUserBtn2->_string);
	pFindUserBtn->setCallback(std::bind(menu_selector(SelTableScene::menuCallbackHandler), this, std::placeholders::_1));
	pFindUserBtn->setPosition(Vec2(getPointFrom3GRect(rtFindUserBtn, size.height)));
	pFindUserBtn->setTag(kMenuBuyChips);
	// Lobby Button

	MenuItemImage* m_pCreateRoomBtn = MenuItemImage::create("image/iPhone/eng/" + strCreateImageNml->_string, "image/iPhone/eng/" + strCreateImageAct->_string);
	m_pCreateRoomBtn->setCallback(std::bind(menu_selector(SelTableScene::menuCallbackHandler), this, std::placeholders::_1));
	m_pCreateRoomBtn->setPosition(Vec2(getPointFrom3GRect(rtCreateRoomBtn, size.height)));
	m_pCreateRoomBtn->setTag(kMenuCreateRoom);
	// Play Button

	MenuItemImage* m_pPlayNowBtn = MenuItemImage::create("image/iPhone/eng/" + strPlayNowImageNml->_string, "image/iPhone/eng/" + strPlayNowImageAct->_string);
	m_pPlayNowBtn->setCallback(std::bind(menu_selector(SelTableScene::menuCallbackHandler), this, std::placeholders::_1));
	m_pPlayNowBtn->setPosition(Vec2(getPointFrom3GRect(rtPlayNowBtn, size.height)));
	m_pPlayNowBtn->setTag(kMenuPlay);
	// Tutorial Button

	MenuItemImage* m_pMainMenuBtn = MenuItemImage::create("image/iPhone/eng/" + strMainMenuImageNml->_string, "image/iPhone/eng/" + strMainMenuImageAct->_string);
	m_pMainMenuBtn->setCallback(std::bind(menu_selector(SelTableScene::menuCallbackHandler), this, std::placeholders::_1));
	m_pMainMenuBtn->setPosition(Vec2(getPointFrom3GRect(rtMainMenu, size.height)));
	m_pMainMenuBtn->setTag(kMenuMain);
	// Help Button

	MenuItemImage* m_pHelpBtn = MenuItemImage::create("image/iPhone/eng/" + strHelpImageNml->_string, "image/iPhone/eng/" + strHelpImageAct->_string);
	m_pHelpBtn->setCallback(std::bind(menu_selector(SelTableScene::menuCallbackHandler), this, std::placeholders::_1));
	m_pHelpBtn->setPosition(Vec2(getPointFrom3GRect(rtHelpBtn, size.height)));
	m_pHelpBtn->setTag(kMenuHelp);
	
	MenuItemImage* m_pFriendsBtn = MenuItemImage::create("image/iPhone/eng/" + strFriendImageNml->_string, "image/iPhone/eng/" + strFriendImageAct->_string);
	m_pFriendsBtn->setCallback(std::bind(menu_selector(SelTableScene::menuCallbackHandler), this, std::placeholders::_1));
	m_pFriendsBtn->setPosition(Vec2(getPointFrom3GRect(rtFriendBtn, size.height)));
	m_pFriendsBtn->setTag(kMenuFriend);

	Vector<MenuItem*> items;
	items.pushBack(m_pBackBtn);
	items.pushBack(pRankingBtn);
	items.pushBack(pFindUserBtn);
	items.pushBack(m_pCreateRoomBtn);
	items.pushBack(m_pFriendsBtn);
	items.pushBack(m_pPlayNowBtn);
	items.pushBack(m_pMainMenuBtn);
	items.pushBack(m_pHelpBtn);

	auto viewAllNml = MenuItemImage::create("image/iPhone/eng/" + strShowAllImageNml->_string, "image/iPhone/eng/" + strShowAllImageNml->_string);
	auto viewAllAct = MenuItemImage::create("image/iPhone/eng/" + strShowAllImageAct->_string, "image/iPhone/eng/" + strShowAllImageAct->_string);

	Vector<MenuItem*> toggleItems;
	toggleItems.pushBack(viewAllNml);
	toggleItems.pushBack(viewAllAct);

	auto viewAllToggle = MenuItemToggle::createWithCallback(std::bind(menu_selector(ViewSetting::menuCallbackHandler), this, std::placeholders::_1), toggleItems);
	viewAllToggle->setTag(kMenuShowAll);
	viewAllToggle->setPosition(getPointFrom3GRect(rtShowAllBtn));
	items.pushBack(viewAllToggle);

	auto hideAllNml = MenuItemImage::create("image/iPhone/eng/" + strHideFullImageNml->_string, "image/iPhone/eng/" + strHideFullImageNml->_string);
	auto hideAllAct = MenuItemImage::create("image/iPhone/eng/" + strHideFullImageAct->_string, "image/iPhone/eng/" + strHideFullImageAct->_string);

	toggleItems.clear();
	toggleItems.pushBack(hideAllNml);
	toggleItems.pushBack(hideAllAct);

	auto hideAllToggle = MenuItemToggle::createWithCallback(std::bind(menu_selector(ViewSetting::menuCallbackHandler), this, std::placeholders::_1), toggleItems);
	hideAllToggle->setTag(kMenuHideAll);
	hideAllToggle->setPosition(getPointFrom3GRect(rtHideFullBtn));
	items.pushBack(hideAllToggle);

	hideAllToggle->setSelectedIndex(1);
	viewAllToggle->setSelectedIndex(0);

	auto pMenu = Menu::createWithArray(items);
	pMenu->setPosition(Vec2::ZERO);
	pSpriteBack->addChild(pMenu);
}



void SelTableScene::drawLabels()
{
	Size size = Director::getInstance()->getWinSize();

	// User Name Label
	char szUserName[MAX_USERNAME_LEN];
	CGameSetting::getInstance()->getUserName(szUserName);
	CCLabelTTF * m_pNameLabel = CCLabelTTF::create(szUserName, g_FontName->_string, 14);
	m_pNameLabel->setPosition(getPointFrom3GRect(rtNameLabel));
	m_pNameLabel->setColor(ccc3(0,0,0));
	pSpriteBack->addChild(m_pNameLabel,1);

    TCASH cash = CGameSetting::getInstance()->getCash();
	// Title Label
	CCLabelTTF *m_pBalanceLabel = CCLabelTTF::create(CCString::createWithFormat("%f", cash)->getCString(), g_FontName->_string, 14);
	m_pBalanceLabel->setPosition(Vec2(getPointFrom3GRect(rtBalanceLabel)));
	m_pBalanceLabel->setColor(ccc3(0,0,0));
	pSpriteBack->addChild(m_pBalanceLabel,1);

	CCLabelTTF *m_pTableNameLabel = CCLabelTTF::create("123123", g_FontName->_string, 11);
	m_pTableNameLabel->setPosition(Vec2(getPointFrom3GRect(rtTableNameLbl, size.height)));
	//m_pCurBalanceLabel->setColor(ccc3(0,0,0));
	pSpriteBack->addChild(m_pTableNameLabel,6);


	CCLabelTTF* m_pTableStakeLabel = CCLabelTTF::create("123321", g_FontName->_string, 11);
	//m_pTableStakeLabel->setPosition(Vec2(getPointFrom3GRect(rtTableStakeLbl, size.height)));
	pSpriteBack->addChild(m_pTableStakeLabel,6);

	CCLabelTTF* m_pTableStateLabel = CCLabelTTF::create("1232", g_FontName->_string, 11);
	//m_pTableStateLabel->setPosition(Vec2(getPointFrom3GRect(rtTableStateLbl, size.height)));
	pSpriteBack->addChild(m_pTableStateLabel,6);

}

void SelTableScene::menuCallbackHandler(Ref * pSender)
{
	CallFunc * callFunc = NULL;
	int tag = ((MenuItem*)pSender)->getTag();
	CCNode *node = this->getChildByTag(kTagCreateTableLayer);
	switch (tag)
	{
		case kMenuPlay:
			MessageBox("Congrats on completing the game!", "Victory");
			break;
		case kMenuLogOut:
			App->changeSceneWithState(TGAME_LOGIN);
			break;
		case kMenuBuyChips:
			
			break;
		case kMenuFindUser:
			break;
		case kMenuFriend:
			break;
		case kMenuLobby:
			App->changeSceneWithState(TGAME_SELTABLE);
			break;
		case kMenuBack:
			App->changeSceneWithState(TGAME_WELCOME);
			break;
		case kMenuCreateRoom:
			if (node == NULL)
				this->addChild(CreateTableScene::create(), TOP_LAYER_ZORDER, kTagCreateTableLayer);
			else
				this->removeChild(node, true);
			break;
		case kMenuHelp:
			Application::getInstance()->openURL("http://www.vweeter.com");
			break;
		case kMenuTutorial:
			Application::getInstance()->openURL("http://www.vweeter.com");
			break;
	}
}

