#ifndef __FINDUSER_LAYER_H__
#define __FINDUSER_LAYER_H__

#include "cocos2d.h"
#include "Global.h"
#include "AppDelegate.h"
#include "cocos-ext.h"

using namespace cocos2d;
class FindUserLayer : public cocos2d::Layer, public cocos2d::ui::EditBoxDelegate

{
public:
    static cocos2d::Scene* createScene();

    virtual bool init();
   
	Sprite *			pSpriteBack;
	
	CCRect m_rtBackground;
	CCPoint	m_ptBackground;
	int m_nSelectedItem;
	CCMenuItemImage* m_pFindBtn;
	CCMenuItemImage* m_pRegisterBtn;
	CCMenuItemImage* m_pCancelBtn;
	bool			m_bDataUpgraded;

	void menuCallbackHandler(Ref * pSender);


	void setItemID(int nItemID);
	void initTextFields();
	void onFind();
	void onRegister();
	void onCancel();
	void updateTable();
	void drawImages();
	void drawButtons();

    // implement the "static create()" method manually
    CREATE_FUNC(FindUserLayer);
public:
	ui::EditBox*            textUserName;

	virtual void editBoxEditingDidBegin(cocos2d::ui::EditBox* editBox)override;
	virtual void editBoxEditingDidEnd(cocos2d::ui::EditBox* editBox)override;
	virtual void editBoxTextChanged(cocos2d::ui::EditBox* editBox, const std::string& text)override;
	virtual void editBoxReturn(cocos2d::ui::EditBox* editBox)override;
};

#endif // __FINDUSER_LAYER_H__
