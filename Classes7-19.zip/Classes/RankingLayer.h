#ifndef __RANKING_LAYER_H__
#define __RANKING_LAYER_H__

#include "cocos2d.h"
#include "Global.h"
#include "AppDelegate.h"
using namespace cocos2d;
class RankingLayer : public cocos2d::Layer

{
public:
	static cocos2d::Scene* createScene();
	virtual bool init();
	void menuCallbackHandler(Ref * pSender);
	void drawImages();
	void drawButtons();
	CCPoint	m_ptBackground;
	// implement the "static create()" method manually
	CREATE_FUNC(RankingLayer);
private:
    CCSprite *pSpriteBack;
};

#endif // __RANKING_LAYER_H__
