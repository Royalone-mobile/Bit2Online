#include "FindUserLayer.h"
#include "SimpleAudioEngine.h"
#include "Global.h"
#include "ViewSetting.h"
USING_NS_CC_EXT;
using namespace CocosDenshion;
static CCString* strBackground = new CCString("pan_Find.png");

static const CCRect rtEditUserName = CCRectMake(-68, -78, 86, 24);
static const CCRect rtPadEditUserName = CCRectMake(-135, -152, 172, 32);

static const CCRect rtFindUserTable = CCRectMake(-95, -48, 195, 125);
static const CCRect rtPadFindUserTable = CCRectMake(-190, -96, 390, 250);

static const CCPoint ptFindBtn = CCPointMake(61, 67);
static const CCPoint ptPadFindBtn = CCPointMake(122, 135);

static const CCPoint ptRegisterBtn = CCPointMake(-56, -91);
static const CCPoint ptPadRegisterBtn = CCPointMake(-112, -185);

static const CCPoint ptCancelBtn = CCPointMake(52, -91);
static const CCPoint ptPadCancelBtn = CCPointMake(104, -185);

static CCString* strFindBtn1 = new CCString("btn_search_0.png");
static CCString* strFindBtn2 = new CCString("btn_search_1.png");
static CCString* strRegisterBtn1 = new CCString("btn_register_0.png");
static CCString* strRegisterBtn2 = new CCString("btn_register_1.png");
static CCString* strCancelBtn1 = new CCString("btn_cancel_0.png");
static CCString* strCancelBtn2 = new CCString("btn_cancel_1.png");




Scene* FindUserLayer::createScene()
{
	// 'scene' is an autorelease object
	Scene* scene = NULL;
	do {

	scene = Scene::create();

	// 'layer' is an autorelease object
	auto layer = FindUserLayer::create();

	scene->addChild(layer);
	} while (0);
	return scene;
}

// on "init" you need to initialize your instance
bool FindUserLayer::init()
{
    //////////////////////////////
	do {
		if (!Layer::init())
		{
			return false;
		}

		m_nSelectedItem = -1;

		drawImages();
		drawButtons();
		initTextFields();
	} while (0);
    return true;
}

void FindUserLayer::drawImages()
{
	Size size = Director::getInstance()->getWinSize();
	
	MenuItemImage* background = MenuItemImage::create("image/iPhone/common/" + strBackground->_string, "image/iPhone/common/" + strBackground->_string);
	background->setCallback(std::bind(menu_selector(FindUserLayer::menuCallbackHandler), this, std::placeholders::_1));

	m_ptBackground = Vec2(size.width * 0.5f, size.height * 0.5f);
	background->setPosition(Vec2(size.width * 0.5f, size.height * 0.5f));

	Vector<MenuItem*> items;
	items.pushBack(background);

	auto pMenu = Menu::createWithArray(items);
	pMenu->setPosition(Vec2::ZERO);
	this->addChild(pMenu);
}

void FindUserLayer::drawButtons() 
{
	Size size = Director::getInstance()->getWinSize();

	m_pFindBtn = MenuItemImage::create("image/iPhone/eng/" + strFindBtn1->_string, "image/iPhone/eng/"+ strFindBtn2->_string);
	m_pFindBtn->setCallback(std::bind(menu_selector(FindUserLayer::menuCallbackHandler), this, std::placeholders::_1));
	m_pFindBtn->setPosition(m_ptBackground + ptFindBtn);
	m_pFindBtn->setTag(kMenuFindUser);
	m_pCancelBtn = MenuItemImage::create("image/iPhone/eng/" + strCancelBtn1->_string, "image/iPhone/eng/" + strCancelBtn2->_string);
	m_pCancelBtn->setCallback(std::bind(menu_selector(FindUserLayer::menuCallbackHandler), this, std::placeholders::_1));
	m_pCancelBtn->setPosition(m_ptBackground + ptCancelBtn);
	m_pCancelBtn->setTag(kMenuCancel);

	m_pRegisterBtn = MenuItemImage::create("image/iPhone/eng/" + strRegisterBtn1->_string, "image/iPhone/eng/" + strRegisterBtn2->_string);
	m_pRegisterBtn->setCallback(std::bind(menu_selector(FindUserLayer::menuCallbackHandler), this, std::placeholders::_1));
	m_pRegisterBtn->setPosition(m_ptBackground + ptRegisterBtn);
	m_pRegisterBtn->setTag(kMenuSignUp);

	Vector<MenuItem*> items;
	items.pushBack(m_pFindBtn);
	items.pushBack(m_pCancelBtn);
	items.pushBack(m_pRegisterBtn);

	auto pMenu = Menu::createWithArray(items);
	pMenu->setPosition(Vec2::ZERO);
	this->addChild(pMenu);
}


void FindUserLayer::initTextFields()
{
	Size size = Director::getInstance()->getWinSize();
	CCRect rt = CCRectMake(m_ptBackground.x + rtEditUserName.origin.x,
		size.height - m_ptBackground.y + rtEditUserName.origin.y,
		rtEditUserName.size.width,
		rtEditUserName.size.height);

	textUserName = EditBox::create(CCSize(rt.size.width, rt.size.height), Scale9Sprite::create());
	textUserName->setPosition(getPointFrom3GRect(rt));
	textUserName->setReturnType(ui::EditBox::KeyboardReturnType::DONE);
	textUserName->setMaxLength(20);
	textUserName->setFontSize(16);
	textUserName->setColor(Color3B::WHITE);
	textUserName->setInputMode(ui::EditBox::InputMode::ANY);
	textUserName->setPlaceHolder("<enter email>");
	textUserName->setDelegate(this);//Open client
	textUserName->setFontColor(Color3B::BLACK);//Sets the text color
	this->addChild(textUserName);
}

void FindUserLayer::menuCallbackHandler(Ref * pSender)
{
	CallFunc * callFunc = NULL;
	int tag = ((MenuItem*)pSender)->getTag();
	switch (tag)
	{
		case kMenuFindUser:
			onFind();
			break;
		case kMenuCancel:
			onCancel();
			break;
		case kMenuSignUp:
			onRegister();
			break;
	}
}


void FindUserLayer::setItemID(int nItemID)
{
	m_nSelectedItem = nItemID;
}

void FindUserLayer::onFind()
{
	m_pFindBtn->setEnabled(false);
	if (!textUserName->getText())
		return;
	if(strlen(textUserName->getText())==0){
		m_pFindBtn->setEnabled(true);
		return;
	}
	NetLogic_SendFindUser(textUserName->getText());
}

void FindUserLayer::onRegister()
{
	if (m_nSelectedItem == -1)
		return;

	if (m_bDataUpgraded == false)
		return;

	if (m_FindUserList.size() <= (unsigned int)m_nSelectedItem)
		return;

	USER_INFO_T receiveInfo;
	strcpy(receiveInfo.m_UserID, m_FindUserList[m_nSelectedItem].szName);
	receiveInfo.m_UserDBID = m_FindUserList[m_nSelectedItem].nUserDBID;
	receiveInfo.m_nCharacterID = INVALID_ID;
	m_SendRequestList[receiveInfo.m_UserDBID] = receiveInfo;

	USER_INFO_T& userInfo = NetLogic_GetUserInfo();
	if (receiveInfo.m_UserDBID == userInfo.m_UserDBID) {
		return;
	}
	TFriendList::iterator it = m_OnlineFriendList.begin(), itEnd = m_OnlineFriendList.end();
	for (; it != itEnd; it++) {
		if (it->nFriendDBID == receiveInfo.m_UserDBID) {
			return;
		}
	}
	it = m_OfflineFriendList.begin(), itEnd = m_OfflineFriendList.end();
	for (; it != itEnd; it++) {
		if (it->nFriendDBID == receiveInfo.m_UserDBID) {
		
			return;
		}
	}

	NetLogic_SendRegisterFriend(receiveInfo.m_UserDBID);
	this->removeFromParentAndCleanup(true);
}
void FindUserLayer::onCancel()
{
	this->removeFromParentAndCleanup(true);
}
void FindUserLayer::updateTable()
{
	m_bDataUpgraded = true;
	m_pFindBtn->setEnabled(true);
}


void FindUserLayer::editBoxEditingDidBegin(cocos2d::ui::EditBox* editBox)
{
}

void FindUserLayer::editBoxEditingDidEnd(cocos2d::ui::EditBox* editBox)
{

}

void FindUserLayer::editBoxTextChanged(cocos2d::ui::EditBox* editBox, const std::string& text)
{

}

void FindUserLayer::editBoxReturn(ui::EditBox* editBox)
{

}