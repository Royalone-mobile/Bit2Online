#include "UIPlayer.h"
#include "Global.h"
#include "ViewSetting.h"
#include "TextureManager.h"
#include "base/NetLogic.h"
USING_NS_CC;

#define VIEW_WIDTH		71
#define VIEW_HEIGHT		83
#define VIEW_PAN_LEFT	104
#define MAIN_VIEW_WIDTH		287
#define MAIN_VIEW_HEIGHT	73

#define CHAT_BALLOON_WIDTH	250
#define NAME_WIDTH			70

static const CCRect rt_Char = CCRectMake(0, 0, VIEW_WIDTH, VIEW_HEIGHT);
static const CCRect rt_Char_Main = CCRectMake (327,28,38,43);
static const CCRect rt_Card = CCRectMake(0, 85, 20, 29);
static const int nInterval_Card = 9;
static const CCRect rt_Card_Main = CCRectMake(0, 0, 47, MAIN_VIEW_HEIGHT);
static const int nInterval_Card_Main = 22;

static const CCRect rt_Label_Name = CCRectMake(3, 2, 65, 12);
static const CCRect rt_Label_CardCount = CCRectMake(8, 69, 53, 10);
static const CCRect rt_Label_Action = CCRectMake( 3, 70, 70, 10);
static const CCRect rt_Win = CCRectMake(45, 19, 50, 42);
static const CCRect rt_Win_Main = CCRectMake(-70, 19, 50, 42);
static const CCRect rt_Action = CCRectMake(45, 19, 42, 36);
static const CCRect rt_Chat_Label = CCRectMake(0, 8, VIEW_WIDTH, 0);

static CCString* strTableRes = new CCString("table_res.png");

//iPad Position
static const CCPoint pt_Pad_Label_Name = CCPointMake(288, 16.8);
static const CCPoint pt_Pad_Label_CardCount = CCPointMake(282, 177);

extern TextureManager g_TextureManager;


Scene* UIPlayer::createScene()
{
	// 'scene' is an autorelease object
	Scene* scene = NULL;
	do {

	scene = Scene::create();

	// 'layer' is an autorelease object
	auto layer = UIPlayer::create();

	scene->addChild(layer);
	} while (0);
	return scene;
}

// on "init" you need to initialize your instance
bool UIPlayer::init()
{
    //////////////////////////////
	do {
		if (!Layer::init())
		{
			return false;
		}

	} while (0);
    return true;
}


void UIPlayer::initView(CCPoint ptViewPos, CCLayer* pParent , int nPos)
{
	
	Size size = Director::getInstance()->getWinSize();

	m_pParent = pParent;
	CCTexture2D * texture = CCTextureCache::getInstance()->addImage("image/iPhone/common/" + strTableRes->_string);
	CCRect rtSprite;
	m_nPosInTable = nPos;

	CCSprite * btnSprite0 = Sprite::createWithTexture(texture);
	rtSprite = g_TextureManager.getTextureRect(Pic_Table_Pan_Player);
	btnSprite0->setTextureRect(rtSprite);

	CCSprite * btnSprite1 = Sprite::createWithTexture(texture);
	rtSprite = g_TextureManager.getTextureRect(Pic_Table_Pan_Player);
	btnSprite1->setTextureRect(rtSprite);


	m_pBackImage = MenuItemImage::create();
	m_pBackImage->setCallback(std::bind(menu_selector(UIPlayer::menuCallbackHandler), this, std::placeholders::_1));
	m_rtMainWindow = CCRectMake(ptViewPos.x, ptViewPos.y, VIEW_WIDTH, VIEW_HEIGHT);
	m_pBackImage->setPosition(getPointFrom3GRect(m_rtMainWindow));
	m_pBackImage->setSelectedImage(btnSprite1);
	m_pBackImage->setNormalImage(btnSprite0);
	m_pBackImage->setTag(kMenuSit);
	m_pBackImage->setVisible(false);
	m_pBackImage->setEnabled(false);


	btnSprite0 = Sprite::createWithTexture(texture);
	rtSprite = g_TextureManager.getTextureRect(Pic_Table_Btn_sit);
	btnSprite0->setTextureRect(rtSprite);

	btnSprite1 = Sprite::createWithTexture(texture);
	rtSprite = g_TextureManager.getTextureRect(Pic_Table_Btn_sit);
	btnSprite1->setTextureRect(rtSprite);

	m_pSitBtn = MenuItemImage::create("image/iPhone/common/" + strTableRes->_string, "image/iPhone/common/" + strTableRes->_string);
	m_pSitBtn->setCallback(std::bind(menu_selector(UIPlayer::menuCallbackHandler), this, std::placeholders::_1));
	m_rtMainWindow = CCRectMake(ptViewPos.x, ptViewPos.y, VIEW_WIDTH, VIEW_HEIGHT);
	m_pSitBtn->setPosition(ccp(m_pSitBtn->getPosition().x + 5, m_pSitBtn->getPosition().y));
	m_pSitBtn->setSelectedImage(btnSprite1);
	m_pSitBtn->setNormalImage(btnSprite0);

	m_pSitBtn->setVisible(false);
	m_pSitBtn->setEnabled(false);

	Vector<MenuItem*> items;
	items.pushBack(m_pBackImage);
	items.pushBack(m_pSitBtn);

	Menu* pMenu = Menu::createWithArray(items);
	pMenu->setPosition(Vec2::ZERO);
	this->addChild(pMenu);

	pMenu->reorderChild(m_pSitBtn, 10);
	m_ptPos = ptViewPos;


	m_pNameLabel = CCLabelTTF::create("", g_FontName->_string, 11);
	CCRect rt = rt_Label_Name;
	rt.origin.x += m_rtMainWindow.origin.x;
	rt.origin.y += m_rtMainWindow.origin.y;
	CCPoint pt = getPointFrom3GRect(rt, size.height);
	m_pNameLabel->setPosition(pt);
	m_pNameLabel->setColor(Color3B::WHITE);
	this->addChild(m_pNameLabel,1);


	m_pCardsCountLable = CCLabelTTF::create("", "Arial", 9);
	m_pCardsCountLable->setColor(Color3B::WHITE);
	rt = rt_Label_CardCount;
	rt.origin.x += m_rtMainWindow.origin.x;
	rt.origin.y += m_rtMainWindow.origin.y;
	pt = getPointFrom3GRect(rt, size.height);
	m_pCardsCountLable->setPosition(pt);
	this->addChild(m_pCardsCountLable, 1);


	m_pActionLabel = CCLabelTTF::create("", "Arial", 11);
	rt = rt_Label_Action;
	rt.origin.x += m_rtMainWindow.origin.x;
	rt.origin.y += m_rtMainWindow.origin.y;
	m_pActionLabel->setPosition(getPointFrom3GRect(rt, size.height));
	m_pActionLabel->setColor(Color3B::BLACK);
	this->addChild(m_pActionLabel, 1000);

	m_UIWinImage = Sprite::createWithTexture(texture);
	rtSprite = g_TextureManager.getTextureRect(Pic_Table_Btn_sit);
	m_UIWinImage->setTextureRect(rtSprite);

	if (m_nPosInTable == 0) {
		rt = rt_Win_Main;
	}
	else {
		rt = rt_Win;
	}
	rt.origin.x += m_rtMainWindow.origin.x;
	rt.origin.y += m_rtMainWindow.origin.y;
	m_UIWinImage->setPosition(getPointFrom3GRect(rt, size.height));
	m_UIWinImage->setVisible(false);
	this->addChild(m_UIWinImage, 1000);


	//chat 
	rt = rt_Chat_Label;
	rt.origin.x += m_rtMainWindow.origin.x;
	rt.origin.y += m_rtMainWindow.origin.y;
	if (m_nPosInTable == 0) {
		rt.origin.x -= 20;
	}
	if (m_nPosInTable == 2) {
		rt.origin.y += 10;
	}
	m_pChatBalloon = Sprite::create("image/iPhone/common/chat_balloon.png");
	m_pChatBalloon->setPosition(getPointFrom3GRect(rt));
	this->addChild(m_pChatBalloon, 2);

	m_pChatBalloon->setScaleX(1.3f);
	m_pChatBalloon->setScaleX(1.5f);
	m_pChatBalloon->setVisible(false);

	rt.origin.y -= 5;

	CCSize chatLblSize;
	//if (getScaleFactor() == 2) {
		//chatLblSize = CCSizeMake(190, 90);
	//}
	//else
	
	chatLblSize = CCSizeMake(95, 45);
	m_pChatLabel = CCLabelTTF::create("", "Arial", 12, chatLblSize);
	m_pChatLabel->setPosition(getPointFrom3GRect(rt));
	m_pChatLabel->setColor(Color3B::BLACK);
	this->addChild(m_pChatLabel, 3);
	m_pChatLabel->setVisible(false);



	m_pWaittingImage = Sprite::createWithTexture(texture);
	rtSprite = g_TextureManager.getTextureRect(Pic_Table_Pan_Waitting);
	m_pWaittingImage->setTextureRect(rtSprite);
	m_pWaittingImage->setPosition(getPointFrom3GRect(m_rtMainWindow));
	this->addChild(m_pWaittingImage);
	m_pWaittingImage->setVisible(false);

	this->setMainPlayer(false);

}

void UIPlayer::refreshView(CCPoint ptViewPos, CCLayer* pParent, int nPos)
{
	m_pParent = pParent;

	m_nPosInTable = nPos;
	if (nPos == 0) {
		float fdelta = 310;
		ptViewPos.x += fdelta;
	}
	Size size = Director::getInstance()->getWinSize();


	m_rtMainWindow = CCRectMake(ptViewPos.x, ptViewPos.y, VIEW_WIDTH, VIEW_HEIGHT);
	m_pBackImage->setPosition(getPointFrom3GRect(m_rtMainWindow));
	m_pBackImage->setVisible(false);
	m_pBackImage->setEnabled(false);


	m_pSitBtn->setPosition(getPointFrom3GRect(m_rtMainWindow));
	m_pSitBtn->setPosition(ccp(m_pSitBtn->getPosition().x + 5, m_pSitBtn->getPosition().y));
	m_pSitBtn->setVisible(false);
	m_pSitBtn->setEnabled(false);

	m_ptPos = ptViewPos;

	m_rtChaRect = getRectFrom3GRect(rt_Char);

	m_pNameLabel->setColor(Color3B::WHITE);

		
	CCRect rt = rt_Label_Name;
	rt.origin.x += m_rtMainWindow.origin.x;
	rt.origin.y += m_rtMainWindow.origin.y;
	CCPoint pt = getPointFrom3GRect(rt, size.height);
	m_pNameLabel->setPosition(pt);
	
	m_pCardsCountLable->setColor(Color3B::WHITE);
		
	rt = rt_Label_CardCount;
	rt.origin.x += m_rtMainWindow.origin.x;
	rt.origin.y += m_rtMainWindow.origin.y;
	pt = getPointFrom3GRect(rt, size.height);
	m_pCardsCountLable->setPosition(pt);

	rt = rt_Label_Action;
	rt.origin.x += m_rtMainWindow.origin.x;
	rt.origin.y += m_rtMainWindow.origin.y;
	m_pActionLabel->setPosition(getPointFrom3GRect(rt, size.height));
	m_pActionLabel->setColor(Color3B::BLACK);

	if (m_nPosInTable == 0) {
		rt = rt_Win_Main;
	}
	else {
		rt = rt_Win;
	}
	rt.origin.x += m_rtMainWindow.origin.x;
	rt.origin.y += m_rtMainWindow.origin.y;
	m_UIWinImage->setPosition(getPointFrom3GRect(rt, size.height));
		
	m_UIWinImage->setVisible(false);

	//chat 
	rt = rt_Chat_Label;
	rt.origin.x += m_rtMainWindow.origin.x;
	rt.origin.y += m_rtMainWindow.origin.y;
	if (m_nPosInTable == 0) {
		rt.origin.x -= 20;
	}
	if (m_nPosInTable == 2) {
		rt.origin.y += 10;
	}
	m_pChatBalloon->setPosition(getPointFrom3GRect(rt));
	m_pChatBalloon->setVisible(false);
	
	rt.origin.y -= 5;
	m_pChatLabel->setPosition(getPointFrom3GRect(rt));
	m_pChatLabel->setColor(Color3B::BLACK);
	m_pChatLabel->setVisible(false);

	m_pWaittingImage->setPosition(getPointFrom3GRect(m_rtMainWindow));
	m_pWaittingImage->setVisible(false);
	this->setMainPlayer(false);
}

void UIPlayer::drawRect() 
{
	switch (m_nSeatState) {
		case TGAME_SEAT_EMPTY:
			m_bImageLoaded = true;
			m_UIWinImage->setVisible(false);
			if (NetLogic_GetUserState() == stateTableView) {
				m_pSitBtn->setVisible(true);
				m_pSitBtn->setEnabled(true);
				m_pWaittingImage->setVisible(true);
				m_pBackImage->setVisible(true);
				m_pBackImage->setEnabled(false);
			}
			if (NetLogic_GetUserState() == stateTableSeat) {
				m_pBackImage->setVisible(false);
				m_pBackImage->setEnabled(false);
				m_pWaittingImage->setVisible(true);
			}
			m_pActionLabel->setString("");
			m_pNameLabel->setString("");
			m_pCardsCountLable->setString("");
			if (m_UICharacter)
			{
				this->removeChild(m_UICharacter,true);
				m_UICharacter = NULL;
			}
			break;
		case TGAME_SEAT_SIT:
			m_pSitBtn->setVisible(false);
			m_pSitBtn->setEnabled(false);
			m_pWaittingImage->setVisible(false);
			m_pBackImage->setVisible(true);
			m_pBackImage->setEnabled(true);
			if (m_bMainPlayer) {
				if (m_UICharacter && NetLogic_GetUserState() == stateTableSeat) {
					m_UICharacter->setVisible(false);
					m_pBackImage->setVisible(false);
					m_pBackImage->setEnabled(false);
				}
			}
			m_UIWinImage->setVisible(false);
			break;
		default:
			break;
	}
}

void UIPlayer::setPlayerInfo(int nPlayerID, int nCharID, const char *szUrl, const char*szName)
{
	m_nPlayerID = nPlayerID;
	m_nCharID = nCharID;
	m_pNameLabel->setString(szName);
	m_pNameLabel->setFontName("Arial");
	m_pNameLabel->setFontSize(13);
	this->createCharacter(m_nCharID, szUrl);
	this->drawRect();
}

int UIPlayer::getCharID() 
{
	return m_nCharID;
}

void UIPlayer::setSeatState(int nstate)
{
	m_nSeatState = nstate;
}

bool UIPlayer::isImageLoaded()
{
	return m_bImageLoaded;
}

void UIPlayer::setCardCount(int nCardCount)
{
	m_nCardCount = nCardCount;
	m_pCardsCountLable->setString(String::createWithFormat("%d Cards", m_nCardCount)->getCString());
}


int UIPlayer::getPosInTable()
{
	return getSeatIDfromPos(m_nPosInTable);
}
void UIPlayer::setPosInTable(int nPos)
{
	m_nPosInTable = nPos;
}

void UIPlayer::chatBalloonAnimation(char *szChat)
{
	CCString *str = new CCString(szChat);
	CCSize size = CCSizeMake(0, 0);
	char szStr[256];
	szStr[0] = 0;
	int nLength = str->length();
	for (int k = 1; k < nLength; k++)
	{
		CCString *subString = new CCString(str->_string.substr(0, k));
		const char *szChar = subString->getCString();
		size = sizeWithFont(szChar, "Arial", 12);
		if (size.width > CHAT_BALLOON_WIDTH)
		{
			strcpy(szStr, szChar);
			strcat(szStr, "...");
			break;
		}
	}
	if (szStr[0] == 0)
		strcpy(szStr, szChat);
	m_pChatLabel->setVisible(true);
	m_pChatBalloon->setVisible(true);
	m_pChatLabel->setString(szStr);

	m_pChatBalloon->runAction(CCSequence::create(CCFadeIn::create(0.1), CCDelayTime::create(3.0f), CCFadeOut::create(0.5f), NULL));
	m_pChatLabel->runAction(CCSequence::create(CCFadeIn::create(0.1), CCDelayTime::create(3.0f), CCFadeOut::create(0.5f), NULL));
}
void UIPlayer::menuCallbackHandler(Ref * pSender)
{
	CallFunc * callFunc = NULL;
	int tag = ((MenuItem*)pSender)->getTag();
	switch (tag)
	{
		case kMenuPlay:
			MessageBox("Congrats on completing the game!", "Victory");
			break;
		case kMenuLogOut:
			App->changeSceneWithState(TGAME_LOGIN);
			break;
		case kMenuBuyChips:
			
			break;
		case kMenuFindUser:
			break;
		case kMenuFriend:
			break;
		case kMenuLobby:
			App->changeSceneWithState(TGAME_SELTABLE);
			break;
		case kMenuHelp:
			Application::getInstance()->openURL("http://www.vweeter.com");
			break;
		case kMenuTutorial:
			Application::getInstance()->openURL("http://www.vweeter.com");
			break;
		
	}
}
bool UIPlayer::isMainPlayer()
{
	return m_bMainPlayer;
}

void UIPlayer::setMainPlayer(bool bMainPlayer)
{
	m_bMainPlayer = bMainPlayer;

	if (m_bMainPlayer) {
		if (NetLogic_GetUserState() == stateTableSeat) {
            m_pBackImage->setVisible(false);
            m_pBackImage->setEnabled(false);
            m_pNameLabel->setVisible(false);
            m_pActionLabel->setVisible(false);
            m_pCardsCountLable->setVisible(false);
            //m_UICharacter->setVisible(false);
		}
		CCRect rt = rt_Win_Main;
		rt.origin.x += m_rtMainWindow.origin.x;
		rt.origin.y += m_rtMainWindow.origin.y;
        m_UIWinImage->setPosition(getPointFrom3GRect(rt));
	}
	else {
		if (NetLogic_GetUserState() == stateTableSeat) {
            m_pBackImage->setVisible(true);
            m_pBackImage->setEnabled(true);
            m_pNameLabel->setVisible(true);
            m_pActionLabel->setVisible(true);
            m_pCardsCountLable->setVisible(true);
		}
	}
}
void UIPlayer::setWinner(bool bWin)
{
	if (!bWin) {

		if (m_UIWinImage->isVisible() == true) {
			m_UIWinImage->setVisible(false);
		}
		return;
	}
	m_UIWinImage->setVisible(true);
	auto action1 = CCFadeIn::create(0.5f);
	auto action2 = CCDelayTime::create(2.0f);
	auto action3 = CCFadeOut::create(0.5f);
	Vector<FiniteTimeAction*> items;
	items.pushBack(action1);
	items.pushBack(action2);
	items.pushBack(action3);
	auto action = CCSequence::create(items);
	m_UIWinImage->runAction(action);
}


void UIPlayer::createCharacter(int nCharID, const char* szUrl)
{
	if (m_UICharacter) 
	{
		m_pBackImage->removeChild(m_UICharacter, true);
		m_UICharacter = NULL;
	}
	Size size = Director::getInstance()->getWinSize();
	m_UICharacter = getCharacterImage(m_nPlayerID, nCharID, szUrl, m_bImageLoaded);
	CCRect rt = m_rtChaRect;
	rt.origin.x += getRectFrom3GRect(m_rtMainWindow).origin.x;
	rt.origin.y += getRectFrom3GRect(m_rtMainWindow).origin.y;
	m_UICharacter->setPosition(getCenterPoint(rt, size.height));
	m_pBackImage->addChild(m_UICharacter, 4);
}
