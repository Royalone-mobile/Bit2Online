#include "ViewSetting.h"
#include "TableScene.h"
#include "ViewMenu.h"
#include "TextureManager.h"
#include "SimpleAudioEngine.h"
#include "Global.h"
#include "FindUserLayer.h"
USING_NS_CC;
using namespace CocosDenshion;

extern TextureManager g_TextureManager;
enum {
	kTagSettingLayer,
	kTagFindUserLayer,
	kTagLayerCount,
};


// image rect
static const CCRect rtBackground = CCRectMake(354, 32, 120, 170);

// button rect
static const CCRect rtSitOutBtn = CCRectMake(2, 2, 77, 24);
static const CCRect rtStandUpBtn = CCRectMake(2, 26, 77, 24);
static const CCRect rtSettingsBtn = CCRectMake(2, 50, 77, 24);
static const CCRect rtMainMenuBtn = CCRectMake(2, 74, 77, 24);
static const CCRect rtFindUserBtn = CCRectMake(2, 98, 77, 24);

// image name
static CCString* strTableRes = new CCString("table_res.png");

// menu name
static CCString* strSitOutBtn = new CCString("Lobby");
static CCString* strStandUpBtn = new CCString("Stand Up");
static CCString* strSitDownBtn = new CCString("Sit Down");
static CCString* strSettingsBtn = new CCString("Setting");
static CCString* strMainMenuBtn = new CCString("Main menu");
static CCString* strFindUserBtn = new CCString("Find user");

//iPad Position
static const CCPoint ptPadBackground = CCPointMake(929, 597);
static const CCPoint ptPadSitOutBtn = CCPointMake(929, 677);
static const CCPoint ptPadStandUpBtn = CCPointMake(929, 630);
static const CCPoint ptPadSettingBtn = CCPointMake(929, 583);
static const CCPoint ptPadMainMenuBtn = CCPointMake(929, 536);
static const CCPoint ptPadFindUserBtn = CCPointMake(929, 489);

//FindUser rect
static const CCRect rtFindUserLayer = CCRectMake(140, 30, 189, 254);
static const CCRect rtPadFindUserLayer = CCRectMake(308, 60, 378, 507);



Scene* MenuLayer::createScene()
{
	// 'scene' is an autorelease object
	Scene* scene = NULL;
	do {

		scene = Scene::create();

		// 'layer' is an autorelease object
		auto layer = MenuLayer::create();

		scene->addChild(layer);
	} while (0);
	return scene;
}

bool MenuLayer::init()
{
	do {
		if (!Layer::init())
			return false;


		drawImages();
		drawButtons();
		
	} while (0);
	return true;
}

void MenuLayer::drawImages()
{
	Size size = Director::getInstance()->getWinSize();

	CCTexture2D * texture = CCTextureCache::getInstance()->addImage("image/iPhone/common/" + strTableRes->_string);
	CCRect rt;
	pSpriteBack = Sprite::createWithTexture(texture);
	rt = g_TextureManager.getTextureRect(Pic_Table_Pan_Menu);
	pSpriteBack->setTextureRect(rt);

	Point ptBack = getPointFrom3GRect(rtBackground, size.height);
	pSpriteBack->setPosition(ptBack.x , ptBack.y );
	this->addChild(pSpriteBack);
}
void MenuLayer::drawButtons()
{
	Size size = Director::getInstance()->getWinSize();

	auto labelSitOut = CCLabelTTF::create(strSitOutBtn->_string, g_FontName->_string, 16, getRectFrom3GRect(rtSitOutBtn).size);
	m_pSitOutBtn = CCMenuItemLabel::create(labelSitOut, std::bind(menu_selector(MenuLayer::menuCallbackHandler), this, std::placeholders::_1));

	m_pSitOutBtn->setColor(Color3B::BLACK);
	m_pSitOutBtn->setDisabledColor(ccc3(32, 32, 64));
	m_pSitOutBtn->setTag(kMenuSitOut);


	auto labelStandUp = CCLabelTTF::create(strStandUpBtn->_string, g_FontName->_string, 16, getRectFrom3GRect(rtStandUpBtn).size);
	m_pStandUpBtn = CCMenuItemLabel::create(labelStandUp, std::bind(menu_selector(MenuLayer::menuCallbackHandler), this, std::placeholders::_1));

	m_pStandUpBtn->setColor(Color3B::BLACK);
	m_pStandUpBtn->setDisabledColor(ccc3(32, 32, 64));
	m_pStandUpBtn->setTag(kMenuStandUp);

	auto labelSettings = CCLabelTTF::create(strSettingsBtn->_string, g_FontName->_string, 16, getRectFrom3GRect(rtSettingsBtn).size);
	m_pSettingsBtn = CCMenuItemLabel::create(labelSettings, std::bind(menu_selector(MenuLayer::menuCallbackHandler), this, std::placeholders::_1));

	m_pSettingsBtn->setColor(Color3B::BLACK);
	m_pSettingsBtn->setDisabledColor(ccc3(32, 32, 64));
	m_pSettingsBtn->setTag(kMenuSetting);


	auto labelFindUser = CCLabelTTF::create(strFindUserBtn->_string, g_FontName->_string, 16, getRectFrom3GRect(rtMainMenuBtn).size);
	m_pFindUserBtn = CCMenuItemLabel::create(labelFindUser, std::bind(menu_selector(MenuLayer::menuCallbackHandler), this, std::placeholders::_1));

	m_pFindUserBtn->setColor(Color3B::BLACK);
	m_pFindUserBtn->setDisabledColor(ccc3(32, 32, 64));
	m_pFindUserBtn->setTag(kMenuFindUser);

	auto labelMainMenu = CCLabelTTF::create(strMainMenuBtn->_string, g_FontName->_string, 16, getRectFrom3GRect(rtMainMenuBtn).size);
	m_pMainMenuBtn = CCMenuItemLabel::create(labelMainMenu, std::bind(menu_selector(MenuLayer::menuCallbackHandler), this, std::placeholders::_1));

	m_pMainMenuBtn->setColor(Color3B::BLACK);
	m_pMainMenuBtn->setDisabledColor(ccc3(32, 32, 64));
	m_pMainMenuBtn->setTag(kMenuMainMenu);

	m_pSitOutBtn->setPosition(getPointWithBackFrom3GRect(rtSitOutBtn, rtBackground, size.height));
	m_pStandUpBtn->setPosition(getPointWithBackFrom3GRect(rtStandUpBtn, rtBackground, size.height));
	m_pSettingsBtn->setPosition(getPointWithBackFrom3GRect(rtSettingsBtn, rtBackground, size.height));
	m_pMainMenuBtn->setPosition(getPointWithBackFrom3GRect(rtMainMenuBtn, rtBackground, size.height));
	m_pFindUserBtn->setPosition(getPointWithBackFrom3GRect(rtFindUserBtn, rtBackground, size.height));

	Vector<MenuItem*> items;

	items.pushBack(m_pSitOutBtn);
	items.pushBack(m_pStandUpBtn);
	items.pushBack(m_pSettingsBtn);
	items.pushBack(m_pMainMenuBtn);
	items.pushBack(m_pFindUserBtn);

	auto pMenu = Menu::createWithArray(items);
	pMenu->setPosition(Vec2::ZERO);
	this->addChild(pMenu);
}

void MenuLayer::onSitout()
{
	m_pSitOutBtn->setColor(Color3B::YELLOW);
	m_pStandUpBtn->setColor(Color3B::BLACK);
	m_pSettingsBtn->setColor(Color3B::BLACK);
	m_pMainMenuBtn->setColor(Color3B::BLACK);
	m_pFindUserBtn->setColor(Color3B::BLACK);


	CCNode *node = this->getChildByTag(kTagSettingLayer);
	if (node) {
		this->removeChild(node, true);
	}

	if (NetLogic_GetUserState() == stateTableSeat) {
		App->changeSceneWithState(TGAME_SELTABLE);
	}

	if (NetLogic_GetUserState() == stateTableView) {
		App->changeSceneWithState(TGAME_SELTABLE);	
	}

	this->removeFromParentAndCleanup(true);
}
void MenuLayer::onStandUp()
{
	m_pSitOutBtn->setColor(Color3B::BLACK);
	m_pStandUpBtn->setColor(Color3B::YELLOW);
	m_pSettingsBtn->setColor(Color3B::BLACK);
	m_pMainMenuBtn->setColor(Color3B::BLACK);
	m_pFindUserBtn->setColor(Color3B::BLACK);

	if (NetLogic_GetUserState() == stateTableSeat) {
		NetLogic_SendStandUp();
	}
	else
	{
		m_pParent->sitAuto();
	}

}
void MenuLayer::onSetting()
{
	if (NetLogic_GetUserState() == stateTableSeat) {
		m_pSitOutBtn->setColor(Color3B::BLACK);
		m_pStandUpBtn->setColor(Color3B::BLACK);
	}

	m_pSettingsBtn->setColor(Color3B::YELLOW);
	m_pMainMenuBtn->setColor(Color3B::BLACK);
	m_pFindUserBtn->setColor(Color3B::BLACK);

	CCNode *node = this->getChildByTag(kTagSettingLayer);

	if (node)
		this->removeChild(node, true);
	else
	{
		this->closeAllSubWindows();
		CCRect rt;
		this->addChild(ViewSetting::create(), 0, kTagSettingLayer);
	}

}
void MenuLayer::onMainMenu()
{
	if (NetLogic_GetUserState() == stateTableSeat) {
		m_pSitOutBtn->setColor(Color3B::BLACK);
		m_pStandUpBtn->setColor(Color3B::BLACK);
	}

	m_pSettingsBtn->setColor(Color3B::BLACK);
	m_pMainMenuBtn->setColor(Color3B::YELLOW);
	m_pFindUserBtn->setColor(Color3B::BLACK);
	this->closeAllSubWindows();

	App->changeSceneWithState(TGAME_WELCOME);
}
void MenuLayer::onFindUser()
{
	CCNode *node = this->getChildByTag(kTagFindUserLayer);
	if(node)
		this->removeChild(node, true);
	else
	{
		this->closeAllSubWindows();
		CCRect rt;

		this->addChild(FindUserLayer::create(), 1001, kTagFindUserLayer);
	}
}

void MenuLayer::closeAllSubWindows()
{
	//Director::getInstance()->getWinSize();
	for (int i = 0; i < kTagLayerCount; i++) {
		CCNode *node = this->getChildByTag(i);
		if (node)
		{
			this->removeChild(node, true);
		}
	}
}
void MenuLayer::setParent(TableScene *pParent)
{
	m_pParent = pParent;
}
void MenuLayer::setStandUp(bool bStandUp)
{
	if (bStandUp)
		m_pStandUpBtn->setString(strStandUpBtn->_string);
	else
		m_pStandUpBtn->setString(strSitDownBtn->_string);
}


void MenuLayer::menuCallbackHandler(Ref * pSender)
{
	CallFunc * callFunc = NULL;
	int tag = ((MenuItem*)pSender)->getTag();
	switch (tag)
	{
		case kMenuSitOut:
			onSitout();
			break;
		case kMenuStandUp:
			onStandUp();
			break;
		case kMenuSetting:
			onSetting();
			break;
		case kMenuFindUser:
			onFindUser();
			break;
		case kMenuMainMenu:
			onMainMenu();
			break;
	}
}

