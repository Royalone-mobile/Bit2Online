#ifndef __SOUNDMANAGER_H__
#define __SOUNDMANAGER_H__

#include "Global.h"


class SoundManager
{
public:
	SoundManager() {};
	~SoundManager();
	
	void initWithResource(CCString *path);
	void play();
	void setVolume(float value);

private:
	char	m_strSoundFileName[100];

};

#endif // __SOUNDMANAGER_H__
