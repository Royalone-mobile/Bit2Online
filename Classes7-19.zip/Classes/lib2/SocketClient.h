#pragma once
#include <string>
#include "CircularBuffer.h"
class Message;

#ifndef _WIN32
#include <netdb.h>
#include <unistd.h>
#else
#include <winsock2.h>
#endif

#define BUF_SIZE	32768

class SocketClient
{
public:
	static SocketClient* getInstance();
	static void destroyInstance();

	bool connect(const char* serverAddr, int port);
	

	/// request test 
	void loginRequest();
	void chatRequest(const char* chat);
	void moveRequest(float x, float y);

	void sendMessage(Message* msg);
	Message* constructMessage(const char* data, int commandId);
private:
	SocketClient();
	virtual ~SocketClient();

	bool initialize();
	bool send(const char* data, int length);

	void networkThread();
	void processPacket();
	bool isStop;
private:

	SOCKET			m_sock;
	CircularBuffer	m_recvBuffer;

	int m_loginId;

};

