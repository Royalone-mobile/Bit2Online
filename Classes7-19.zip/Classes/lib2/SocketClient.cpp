﻿#include <thread>
#include "SocketClient.h"
#include "platform/CCFileUtils.h"
#include "base/CCDirector.h"
#include "base/CCScheduler.h"
#include "2d/CCLabel.h"
#include "../PacketType.h"
#include "config.h"
#include "ByteBuffer.h"
#include "Message.h"
#include "cocos2d.h"
#include "GameData.h"
#include "Protocol.h"
USING_NS_CC;

#ifdef _WIN32
#pragma comment(lib,"ws2_32.lib")
#define sleep(x) Sleep(x)
#endif

static SocketClient* s_TcpClient = nullptr;

SocketClient::SocketClient() : m_recvBuffer(BUF_SIZE), m_sock(NULL), m_loginId(-1)
{
	isStop = false;
}

SocketClient::~SocketClient()
{
#ifndef _WIN32
	close(m_sock);
#else
	closesocket(m_sock);
	WSACleanup();
#endif

}

bool SocketClient::initialize()
{

#ifdef _WIN32
	WSADATA wsa;
	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
		return false;
#endif


	m_sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (m_sock == INVALID_SOCKET)
		return false;

	/// thread start
	auto t = std::thread(CC_CALLBACK_0(SocketClient::networkThread, this));
	t.detach();

	return true;
}


SocketClient* SocketClient::getInstance()
{
	if (nullptr == s_TcpClient)
	{
		s_TcpClient = new SocketClient();
		if (false == s_TcpClient->initialize())
			return nullptr;

		std::string ipaddr = SERVER_ADDRESS;
		int port =  SERVER_PORT;

		if (s_TcpClient->connect(ipaddr.c_str(), port))
		{

		}
	}
		

	return s_TcpClient;
}

void SocketClient::destroyInstance()
{
	s_TcpClient->isStop = true;
	CC_SAFE_DELETE(s_TcpClient);
}

bool SocketClient::connect(const char* serverAddr, int port)
{
	struct hostent* host;
	struct sockaddr_in hostAddr;

	if ((host = gethostbyname(serverAddr)) == 0) 
		return false;

	memset(&hostAddr, 0, sizeof(hostAddr));
	hostAddr.sin_family = AF_INET;
	hostAddr.sin_addr.s_addr = ((struct in_addr *)(host->h_addr_list[0]))->s_addr;
	hostAddr.sin_port = htons(port);

	if (SOCKET_ERROR == ::connect(m_sock, (struct sockaddr*)&hostAddr, sizeof(hostAddr)))
	{
		return false;
	}
	
	//u_long arg = 1;
	//ioctlsocket(mSocket, FIONBIO, &arg);

	/// nagle ¾Ë°í¸®Áò ²ô±â
	int opt = 1;
	setsockopt(m_sock, IPPROTO_TCP, TCP_NODELAY, (const char*)&opt, sizeof(int));

	return true;
}

bool SocketClient::send(const char* data, int length)
{
	int count = 0;
	while (count < length) 
	{
		int n = ::send(m_sock, data + count, length - count, 0);
		if (n == SOCKET_ERROR)
		{
			return false;
		}
		count += n;
	
	}

	return true;
}

void SocketClient::sendMessage(Message* msg)
{
	int length = msg->datalength();
	send(msg->data, length);
}

void SocketClient::networkThread()
{
	ByteBuffer* recvBuff = new ByteBuffer(2048);
	while ( !isStop ) 
	{
		int iRetCode = 0;
		if (recvBuff->remaining() > 0) {
			iRetCode = recv(
				m_sock,
				recvBuff->getBuffer() + recvBuff->getPosition(),
				recvBuff->remaining(),
				0);
		}
		if (iRetCode == -1) {
			//connection terminated
			log("Connection terminated!");
			//auto message = Message::create();
			//message->retain();

			//GameData::getInstance()->dic->setObject(message, CONNECTION_CLOSED);
			
		}
		else if (iRetCode == 0 && recvBuff->remaining() > 0) {
			//server close connection!
			log("Server closed connection!");
			//auto message = Message::create();
			//message->retain();

			//GameData::getInstance()->dic->setObject(message, CONNECTION_CLOSED);
		}
		else {
			recvBuff->setPosition(recvBuff->getPosition() + iRetCode);
			recvBuff->flip();

			log("message length : %d", recvBuff->remaining());

			int tmpOffset = 16;
			while (recvBuff->remaining() >= tmpOffset) {
				int pos = recvBuff->position;
				int length = recvBuff->getLength(12);

				log("data length : %d", length);

				if (recvBuff->remaining() + tmpOffset >= length) {
					auto message = Message::create();
					message->retain();

					message->HEAD0 = recvBuff->getByte();
					message->HEAD1 = recvBuff->getByte();
					message->HEAD2 = recvBuff->getByte();
					message->HEAD3 = recvBuff->getByte();

					recvBuff->getAsBytes(message->serverVersion);
					recvBuff->getAsBytes(message->commandId);
					recvBuff->getAsBytes(message->length);

					int commandId = Message::bytesToInt(message->commandId);

					recvBuff->get(message->data, 0, length - 4);

					log("commandId : %d, data length : %d \n", commandId, length);
					log("%s", message->data);
					GameData::getInstance()->dic->setObject(message, commandId);

				}
				else if (length > recvBuff->getCapacity()) {
					log("message size(%d) great capacity(%d),  : %X", length, recvBuff->getCapacity(), TYPE_SELF_DEINE_MESSAGE_CONNECT_TERMINATE);

					return;
				}
				else {
					recvBuff->position = pos;
					break;
				}
				
			}
			recvBuff->compact();
		}
	}
}

void SocketClient::processPacket()
{
	auto scheduler = cocos2d::Director::getInstance()->getScheduler();


	while (true)
	{
		PacketHeader header;
		
		if (false == m_recvBuffer.Peek((char*)&header, sizeof(PacketHeader)))
			break;
			

		if (header.mSize > m_recvBuffer.GetStoredSize())
			break;
	

		switch (header.mType)
		{
		/*case PKT_SC_LOGIN:
			{
				LoginResult recvData;
				bool ret = m_recvBuffer.Read((char*)&recvData, recvData.mSize);
				assert(ret && recvData.mPlayerId != -1);
				CCLOG("LOGIN OK: ID[%d] Name[%s] POS[%.4f, %.4f]", recvData.mPlayerId, recvData.mName, recvData.mPosX, recvData.mPosY);
	
				m_loginId = recvData.mPlayerId;
			}
			break;

		case PKT_SC_CHAT:
			{
				ChatBroadcastResult recvData;
				bool ret = m_recvBuffer.Read((char*)&recvData, recvData.mSize);
				assert(ret && recvData.mPlayerId != -1);
			
				auto layer = cocos2d::Director::getInstance()->getRunningScene()->getChildByName(std::string("base_layer"));
				scheduler->performFunctionInCocosThread(CC_CALLBACK_0(HelloWorld::chatDraw, dynamic_cast<HelloWorld*>(layer), std::string(recvData.mName), std::string(recvData.mChat)));
			}
			break;

		case PKT_SC_MOVE:
			{
				MoveBroadcastResult recvData;
				bool ret = m_recvBuffer.Read((char*)&recvData, recvData.mSize);
				assert(ret && recvData.mPlayerId != -1);
				auto layer = cocos2d::Director::getInstance()->getRunningScene()->getChildByName(std::string("base_layer"));

				if ( recvData.mPlayerId == m_loginId ) ///< in case of me
					scheduler->performFunctionInCocosThread(CC_CALLBACK_0(HelloWorld::updateMe, dynamic_cast<HelloWorld*>(layer), recvData.mPosX, recvData.mPosY));
				else
					scheduler->performFunctionInCocosThread(CC_CALLBACK_0(HelloWorld::updatePeer, dynamic_cast<HelloWorld*>(layer), recvData.mPlayerId, recvData.mPosX, recvData.mPosY));

			}
			break;
			*/
		default:
			assert(false);
		}

	}
}

void SocketClient::loginRequest()
{
	if (m_loginId > 0)
		return;

	srand(time(NULL));

	/// ´ë·« ¾Æ·¡ÀÇ id·Î ·Î±×ÀÎ Å×½ºÆ®..
	LoginRequest sendData;
	sendData.mPlayerId = 1000 + rand() % 101;

	send((const char*)&sendData, sizeof(LoginRequest));

}

void SocketClient::chatRequest(const char* chat)
{
	if (m_loginId < 0)
		return;

	ChatBroadcastRequest sendData;

	sendData.mPlayerId = m_loginId;
	memcpy(sendData.mChat, chat, strlen(chat));

	send((const char*)&sendData, sizeof(ChatBroadcastRequest));
}


void SocketClient::moveRequest(float x, float y)
{
	if (m_loginId < 0)
		return;

	MoveRequest sendData;
	sendData.mPlayerId = m_loginId;
	sendData.mPosX = x;
	sendData.mPosY = y;

	send((const char*)&sendData, sizeof(MoveRequest));
}


Message* SocketClient::constructMessage(const char* data, int commandId)
{
	Message * msg = new Message();

	msg->HEAD0 = 'P';
	msg->HEAD1 = 'E';
	msg->HEAD2 = 'P';
	msg->HEAD3 = 'H';

	int a = 1;
	msg->serverVersion[3] = (byte)(0xff & a);
	msg->serverVersion[2] = (byte)((0xff00 & a) >> 8);
	msg->serverVersion[1] = (byte)((0xff0000 & a) >> 16);
	msg->serverVersion[0] = (byte)((0xff000000 & a) >> 24);

	int b = commandId;
	msg->commandId[3] = (byte)(0xff & b);
	msg->commandId[2] = (byte)((0xff00 & b) >> 8);
	msg->commandId[1] = (byte)((0xff0000 & b) >> 16);
	msg->commandId[0] = (byte)((0xff000000 & b) >> 24);

	int c = strlen(data) + 4;
	msg->length[3] = (byte)(0xff & c);
	msg->length[2] = (byte)((0xff00 & c) >> 8);
	msg->length[1] = (byte)((0xff0000 & c) >> 16);
	msg->length[0] = (byte)((0xff000000 & c) >> 24);

	memset(msg->data, 0x00, sizeof(char) * Message::MAX_LENGTH);
	memcpy(msg->data + 0, &msg->HEAD0, 1);
	memcpy(msg->data + 1, &msg->HEAD1, 1);
	memcpy(msg->data + 2, &msg->HEAD2, 1);
	memcpy(msg->data + 3, &msg->HEAD3, 1);
	memcpy(msg->data + 4, &msg->serverVersion, 4);
	memcpy(msg->data + 8, &msg->commandId, 4);
	memcpy(msg->data + 12, &msg->length, 4);
	memcpy(msg->data + 16, data, strlen(data));

	return msg;
}
