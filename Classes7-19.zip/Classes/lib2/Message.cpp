/*
*  message.cpp
*
*  Created by HELEN on 15-1-1.
*  Copyright 2015 JDRX. All rights reserved.
*
*/

#include "message.h"

Message::Message()
{
	memset(data, 0x00, sizeof(char) * Message::MAX_LENGTH);

	HEAD0 = 'H';
	HEAD1 = 'E';
	HEAD2 = 'A';
	HEAD3 = 'D';

	int a = 1;
	serverVersion[3] = (byte)(0xff & a);
	serverVersion[2] = (byte)((0xff00 & a) >> 8);
	serverVersion[1] = (byte)((0xff0000 & a) >> 16);
	serverVersion[0] = (byte)((0xff000000 & a) >> 24);
}

Message::~Message()
{
}

int Message::datalength()
{
	return bytesToInt(length) + 12;
}

Message * Message::create()
{
	Message *ret = new (std::nothrow) Message();
	if (ret) {
		ret->autorelease();
		return ret;
	}
	else {
		CC_SAFE_DELETE(ret);
		return nullptr;
	}
}


int Message::bytesToInt(byte* bytes)
{
	int addr = bytes[3] & 0xFF;

	addr |= ((bytes[2] << 8) & 0xFF00);

	addr |= ((bytes[1] << 16) & 0xFF0000);

	addr |= ((bytes[0] << 24) & 0xFF000000);

	return addr;
}

byte* Message::intToByte(int i)
{
	byte* abyte0 = new byte[4];

	abyte0[3] = (byte)(0xff & i);

	abyte0[2] = (byte)((0xff00 & i) >> 8);

	abyte0[1] = (byte)((0xff0000 & i) >> 16);

	abyte0[0] = (byte)((0xff000000 & i) >> 24);

	return abyte0;
}