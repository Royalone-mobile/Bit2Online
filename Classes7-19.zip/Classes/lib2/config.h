#ifndef _NET_CONFIG_H
#define _NET_CONFIG_H

#define SERVER_ADDRESS "142.4.3.183"
#define SERVER_PORT		2253

#endif