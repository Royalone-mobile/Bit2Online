#ifndef __SELTABLE_SCENE_H__
#define __SELTABLE_SCENE_H__

#include "cocos2d.h"
#include "Global.h"
#include "AppDelegate.h"

#include "LobbyTableViewController.h"
#include "cocos-ext.h"
#include "extensions/cocos-ext.h"
#include "network/HttpClient.h"


using namespace cocos2d;

class UIBlindBar;

class SelTableScene : public cocos2d::Layer

{
public:
    static cocos2d::Scene* createScene();

    virtual bool init();
	Sprite*					m_pTableImage[9];
	Sprite *			pSpriteBack;
	Sprite *			_title;
	UIBlindBar*					m_pBlindBar;

	void joinTable(int);
	void getTables();

	void parseGetTables(Json::Value root);
	void parseJoinTable(Json::Value root);

	CCLabelTTF *m_pUserNameLabel;
	CCLabelTTF *m_pCurBalanceLabel;
	void onHttpRequestCompleted(cocos2d::network::HttpClient *sender, cocos2d::network::HttpResponse *response);
	void menuCallbackHandler(Ref * pSender);
	LobbyTableViewController*	m_pTableViewController;
	void drawImages();
	void drawButtons();
	void drawLabels();

    // implement the "static create()" method manually
    CREATE_FUNC(SelTableScene);
};

#endif //__SELTABLE_SCENE_H__
