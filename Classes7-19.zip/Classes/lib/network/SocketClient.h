/*
 *  SocketClient.h
 *
 *  Created by HELEN on 15-1-1.
 *  Copyright 2015 JDRX. All rights reserved.
 *
 */

#ifndef _CDATA_NETSOCKET_H_
#define _CDATA_NETSOCKET_H_

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/time.h>

#include <string.h>
#include <stdlib.h>
#include <queue>

#include "cocos2d.h"
#include "ByteBuffer.h"
#include "message.h"

const int	SocketClient_WAIT_CONNECT = 0;
const int	SocketClient_OK = 1;
const int	SocketClient_DESTROY = 2;

using namespace std;

class SocketClient
{
public:
	int m_hSocket;

	char m_serverId;
	char m_clientId;
	std::string m_host;
	int m_iport;

	// 收到服务端消息
	queue<Message*> m_receivedMessageQueue;
	
	// 需要发送到服务端的消息
	queue<Message*> m_sendMessageQueue;
	
	int m_iState;
	
	// 接收线程
	bool m_bThreadRecvCreated;
	pthread_t pthread_t_receive;
	
	// 发送线程
	bool m_bThreadSendCreated;
	pthread_t pthread_t_send;
	pthread_mutex_t m_thread_cond_mutex;
	pthread_cond_t m_threadCond;
	
    // 发送队列同步锁
	pthread_mutex_t m_sendqueue_mutex;
	
private:
	// 连接服务器
	bool  connectServer();
	
	static void* ThreadReceiveMessage(void *p);
	static void* ThreadSendMessage(void *p);
	
public:
	SocketClient(std::string host, int port, byte clientId, byte serverId);
	~SocketClient();

	bool dxflag;

	void start();
	void stop(boolean b);
	void reconnect();
	bool isWaitConnect();

	// 发送数据
	void sendMessage_(Message* msg, bool b);
	
	void destory();
	
    Message* constructMessage(const char* data,int commandId);

    static int bytesToInt(byte* data);
    static byte* intToByte(int i);
};

#endif
