#include "Util.h"
#include <stdlib.h>
#include "ByteBuffer.h"
#include "cocos2d.h"
#include <sys/stat.h>
using namespace cocos2d;

string byteToHexStr(unsigned char *byte_arr, int arr_len)
{
	string  hexstr;
	for (int i = 0; i < arr_len; i++) {
		char hex1;
		char hex2;
		int value = byte_arr[i];
		int v1 = value / 16;
		int v2 = value % 16;

		if (v1 >= 0 & v1 <= 9)
			hex1 = (char)(48 + v1);
		else
			hex1 = (char)(55 + v1);

		if (v2 >= 0 && v2 <= 9)
			hex2 = (char)(48 + v2);
		else
			hex2 = (char)(55 + v2);

		hexstr += hex1;
		hexstr += hex2;
	}

	return hexstr;

}

static int randC = 0;
std::string createRandString(int len, boolean filter)
{
	string s;
	s.resize(len+10);
	char c;
	for (int i = 0; i < len; i++) {
		randC = 1;//(int) ((System::currentTimeMillis() >> (i * ((randC % 4) + 1))) % 36);
		
		sleep(randC);
			
		if (randC < 10) {
			randC = 48 + randC;
		} else {
			randC = 97 + (randC - 10);
		}
		c = (char)randC;
		if( filter){
			if( c == 'g' || c=='G') c = '9';
			else if( c == 'm' || c=='M') c = '5';
		}            
		if (randC % 2 == 0)
			s.push_back(c);				
		else
			s.insert( s.begin(),1,c);
	}
	return s;
}

MyLock::MyLock(pthread_mutex_t* _mutex_t)
{
	log("[MyLock(pthread_mutex_t* mutex_t), mutex_address:%p][begin...] \n", _mutex_t);
	this->mutex_t = _mutex_t;
	pthread_mutex_lock(mutex_t);
}

MyLock::~MyLock()
{
	pthread_mutex_unlock(mutex_t);
	log("[MyLock::~MyLock(), mutex_address:%p] \n", this->mutex_t);
}



