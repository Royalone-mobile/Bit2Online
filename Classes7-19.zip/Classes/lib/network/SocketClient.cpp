
#include "SocketClient.h"
#include "MSAutoReleasePool.h"
#include "message.h"
#include <errno.h>
#include <signal.h>
#include "GameData.h"
#include "../../Common.h"

SocketClient::SocketClient(std::string host, int port, byte clientid, byte serverid):
		m_iState(SocketClient_WAIT_CONNECT)
{
    pthread_mutex_init(&m_sendqueue_mutex, NULL);
	pthread_mutex_init(&m_thread_cond_mutex, NULL);
	pthread_cond_init(&m_threadCond, NULL);
	
	m_hSocket = -1;
	
	this->m_host = host;
	this->m_iport = port;
	this->m_clientId = clientid;
	this->m_serverId = serverid;
	
	m_bThreadRecvCreated = false;	
	m_bThreadSendCreated = false;

    dxflag=false;
}

void SocketClient::reconnect()
{
    MyLock lock(&m_thread_cond_mutex);
    m_iState = SocketClient_WAIT_CONNECT;

    m_hSocket = -1;
    m_bThreadRecvCreated = false;
	m_bThreadSendCreated = false;
    this->start();
}

void SocketClient::start()
{
	if (!m_bThreadSendCreated) {
		pthread_create(&pthread_t_send, NULL, ThreadSendMessage, this);
		m_bThreadSendCreated = true;
	}
}

bool SocketClient::isWaitConnect()
{
	return m_iState == SocketClient_WAIT_CONNECT;
}

void SocketClient::destory()
{
    m_iState = SocketClient_DESTROY;
	if (m_hSocket != -1)
		close(m_hSocket);
	
	pthread_mutex_destroy(&m_sendqueue_mutex);
	pthread_mutex_destroy(&m_thread_cond_mutex);
	pthread_cond_destroy(&m_threadCond);
    
	while (!m_receivedMessageQueue.empty()) {
		Message * m = m_receivedMessageQueue.front();
		m_receivedMessageQueue.pop();
		SAFE_DELETE_ELEMENT(m);
	}
	
	while (!m_sendMessageQueue.empty()) {
		Message * m = m_sendMessageQueue.front();
		m_sendMessageQueue.pop();
		SAFE_DELETE_ELEMENT(m);
	}
}

SocketClient::~SocketClient()
{
    log("SocketClient::~SocketClient");
	m_iState = SocketClient_DESTROY;

	if (m_hSocket != -1)
		close(m_hSocket);
	
	pthread_mutex_destroy(&m_sendqueue_mutex);
	pthread_mutex_destroy(&m_thread_cond_mutex);
	pthread_cond_destroy(&m_threadCond);

	while (!m_receivedMessageQueue.empty()) {
		Message * m = m_receivedMessageQueue.front();
		m_receivedMessageQueue.pop();

		SAFE_DELETE_ELEMENT(m);
	}
	
	while (!m_sendMessageQueue.empty()) {
		Message * m = m_sendMessageQueue.front();
		m_sendMessageQueue.pop();

		SAFE_DELETE_ELEMENT(m);
	}
}

int SocketClient::bytesToInt(byte* bytes)
{
    int addr = bytes[3] & 0xFF;
    
    addr |= ((bytes[2] << 8) & 0xFF00);
    
    addr |= ((bytes[1] << 16) & 0xFF0000);
    
    addr |= ((bytes[0] << 24) & 0xFF000000);
    
    return addr;
}

byte* SocketClient::intToByte(int i)
{
    byte* abyte0 = new byte[4];
    
    abyte0[3] = (byte) (0xff & i);
    
    abyte0[2] = (byte) ((0xff00 & i) >> 8);
    
    abyte0[1] = (byte) ((0xff0000 & i) >> 16);
    
    abyte0[0] = (byte) ((0xff000000 & i) >> 24);
    
    return abyte0;
}

Message* SocketClient::constructMessage(const char* data, int commandId)
{
    Message * msg = new Message();
    
    msg->HEAD0 = 'P';
    msg->HEAD1 = 'E';
    msg->HEAD2 = 'P';
    msg->HEAD3 = 'H';

    int a = 1;
    msg->serverVersion[3] = (byte)(0xff&a);
    msg->serverVersion[2] = (byte)((0xff00&a) >> 8);
    msg->serverVersion[1] = (byte)((0xff0000&a) >> 16);
    msg->serverVersion[0] = (byte)((0xff000000&a) >> 24);

    int b = commandId;
    msg->commandId[3] = (byte)(0xff & b);
    msg->commandId[2] = (byte)((0xff00 & b) >> 8);
    msg->commandId[1] = (byte)((0xff0000 & b) >> 16);
    msg->commandId[0] = (byte)((0xff000000 & b) >> 24);

    int c = strlen(data) + 4;
    msg->length[3] = (byte)(0xff & c);
    msg->length[2] = (byte)((0xff00 & c) >> 8);
    msg->length[1] = (byte)((0xff0000 & c) >> 16);
    msg->length[0] = (byte)((0xff000000 & c) >> 24);

    memset(msg->data, 0x00, sizeof(char) * Message::MAX_LENGTH);
    memcpy(msg->data + 0, &msg->HEAD0, 1);
    memcpy(msg->data + 1, &msg->HEAD1, 1);
    memcpy(msg->data + 2, &msg->HEAD2, 1);
    memcpy(msg->data + 3, &msg->HEAD3, 1);
    memcpy(msg->data + 4, &msg->serverVersion, 4);
    memcpy(msg->data + 8, &msg->commandId, 4);
    memcpy(msg->data + 12, &msg->length, 4);
    memcpy(msg->data + 16, data, strlen(data));

	return msg;
}

void SocketClient:: stop(boolean b)
{
    if (m_hSocket != -1)
		close(m_hSocket);
    
	m_iState = SocketClient_DESTROY;
	
	{
		MyLock lock(&m_thread_cond_mutex);
		pthread_cond_signal(&m_threadCond);
	}

	pthread_join(pthread_t_receive, NULL);
	pthread_join(pthread_t_send, NULL);
    
    pthread_mutex_destroy(&m_sendqueue_mutex);
	pthread_mutex_destroy(&m_thread_cond_mutex);
	pthread_cond_destroy(&m_threadCond);
    
	while (!m_receivedMessageQueue.empty()) {
		Message* m = m_receivedMessageQueue.front();
		m_receivedMessageQueue.pop();

		SAFE_DELETE_ELEMENT(m);
	}
	
	while (!m_sendMessageQueue.empty()) {
		Message* m = m_sendMessageQueue.front();
		m_sendMessageQueue.pop();

		SAFE_DELETE_ELEMENT(m);
	}
}

bool SocketClient::connectServer()
{
	if (m_host.length() < 1 || m_iport == 0)
		return false;

	log("[SocketClient::Connect()] [ host:%s,port:%d ] \n", m_host.c_str(), m_iport);

	int dwServerIP = inet_addr(m_host.c_str());
	unsigned short wPort = m_iport;

    if (m_hSocket != -1) {
		close(m_hSocket);

		m_hSocket = -1;
	}

	m_hSocket = socket(AF_INET, SOCK_STREAM, 0);
    log("m_hSocket : %d", m_hSocket);
    
	if (m_hSocket == -1) {
		return false;
	}

	sockaddr_in SocketAddr;
	memset(&SocketAddr, 0, sizeof(SocketAddr));

	SocketAddr.sin_family = AF_INET;
	SocketAddr.sin_port = htons(wPort);
	SocketAddr.sin_addr.s_addr = dwServerIP;

    memset(&(SocketAddr.sin_zero), 0, sizeof(SocketAddr.sin_zero));

	int iErrorCode = 0;
	iErrorCode = connect(m_hSocket, (sockaddr*)&SocketAddr, sizeof(SocketAddr));
    log("Error code : %d", iErrorCode);
	if (iErrorCode == -1) {
		printf("socket connect error:%d\n", errno);
		return false;
	}

	log("%d", m_bThreadRecvCreated);

	if (!m_bThreadRecvCreated ) {
		if (pthread_create(&pthread_t_receive, NULL, ThreadReceiveMessage, this) != 0)
			return false;

		m_bThreadRecvCreated = true;
	}

	m_iState = SocketClient_OK;
	
	log("socket connected success[ %s,%d], %p , %d, %d \n", m_host.c_str(), m_iport, this, m_iState, SocketClient_OK);
	
	return true;
}

void SocketClient::sendMessage_(Message* msg, bool b)
{
	if (m_iState == SocketClient_DESTROY) {
		delete msg;
		return;
	}

	{
		MyLock lock(&m_sendqueue_mutex);
		m_sendMessageQueue.push(msg);
	}

	if (m_iState == SocketClient_OK) {
		MyLock lock(&m_thread_cond_mutex);
		pthread_cond_signal(&m_threadCond);
	}
}

void* SocketClient::ThreadSendMessage(void *p)
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)	
	MSAutoReleasePool POOL;
#endif
	SocketClient * This = static_cast<SocketClient*>(p);
	log("%d", This->m_iState);

	if (This->dxflag) {
       This->m_iState = SocketClient_OK;
    }
    
	if (This->m_iState == SocketClient_WAIT_CONNECT && !This->connectServer()) {
		This->m_iState = SocketClient_DESTROY;

		log("连网失败,请检查网络设置 : %X", TYPE_SELF_DEINE_MESSAGE_CONNECT_FAIL);

		return ((void *)0);
	}

	ByteBuffer * sendBuff = new ByteBuffer(2048);
	int socket = This->m_hSocket;
	
	while (This->m_iState != SocketClient_DESTROY) {
		if (This->m_iState == SocketClient_OK) {
			// 发送缓冲器有遗留的数据要发送
			if (sendBuff->getPosition() > 0) {
				sendBuff->flip();
				int ret = send(socket, (char*)sendBuff->getBuffer(), sendBuff->getLimit(), 0);
				if (ret == -1) {
					This->m_iState = SocketClient_DESTROY;

					log("发送数据，网络异常！: %X", TYPE_SELF_DEINE_MESSAGE_CANNOT_SEND_MESSAGE);

					return ((void*)0);
				} else {
					log("SocketClient::ThreadSendMessage(), send message to server, size = %d\n", ret);
				}

				sendBuff->setPosition(sendBuff->getPosition() + ret);
				sendBuff->compact();
			}
		
			Message* msg = NULL;
			while (This->m_iState != SocketClient_DESTROY && This->m_sendMessageQueue.size() > 0) {
				{
					MyLock lock(&This->m_sendqueue_mutex);
					msg = This->m_sendMessageQueue.front();
					This->m_sendMessageQueue.pop();
				}

				log("sendData length: %d  %u", msg->datalength(), sizeof(char));

				if (msg->datalength() + sendBuff->getPosition() > sendBuff->getLimit()) {
					This->m_iState = SocketClient_DESTROY;

					log("发送缓冲器已满，您的网络环境好像出现了问题！: %X", TYPE_SELF_DEINE_MESSAGE_CANNOT_SEND_MESSAGE);

					return ((void*)0);
				}

				sendBuff->put(msg->data, 0, msg->datalength());
				sendBuff->flip();

				int ret = send(socket, (char *)sendBuff->getBuffer(), sendBuff->getLimit(), 0);
				if (ret == -1) {
					This->m_iState = SocketClient_DESTROY;

					log("发送数据，网络异常！: %X", TYPE_SELF_DEINE_MESSAGE_CANNOT_SEND_MESSAGE);

					return ((void *)0);
				}
				else {
					log("SocketClient::ThreadSendMessage(), send message to server, size = %d\n", ret);
				}

				sendBuff->setPosition(sendBuff->getPosition() + ret);
				sendBuff->compact();

				delete msg;
			}
		}
		
		if (This->m_iState != SocketClient_DESTROY && This->m_sendMessageQueue.size() == 0) {
			// sleep
			struct timeval tv;
			struct timespec ts;
			gettimeofday(&tv, NULL);
			ts.tv_sec = tv.tv_sec + 5;
			ts.tv_nsec = 0;
			
			MyLock lock(&(This->m_thread_cond_mutex));
			if (This->m_iState != SocketClient_DESTROY && This->m_sendMessageQueue.size() == 0) {
				pthread_cond_timedwait(&(This->m_threadCond), &(This->m_thread_cond_mutex), &ts);
			}
		}
	}

	log("SocketClient::ThreadSendMessage(), send thread stop!\n");

	return (void*)0;
}

bool g_bcheckReceivedMessage = false;
void* SocketClient::ThreadReceiveMessage(void *p)
{
#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)	
	MSAutoReleasePool POOL;
#endif
	fd_set fdRead;
	
	struct timeval	aTime;
	aTime.tv_sec = 1;
	aTime.tv_usec = 0;

	// 最大多少秒，连接上收不到数据就提示用户，重新登录
	int maxIdleTimeInSeconds = 60 * 3;
	
	// 最大多少秒，连接上收不到数据就提示用户，选择重连
	int hint2TimeInSeconds = 60;
	
	// 多长时间没有收到任何数据，提示用户
	int hintTimeInSeconds = 30;
	
	struct timeval lastHintUserTime;
	struct timeval lastReceiveDataTime;
	struct timeval now;
	
	gettimeofday(&lastReceiveDataTime, NULL);
	lastHintUserTime = lastReceiveDataTime;
	
	SocketClient* This = static_cast<SocketClient*>(p);
	
	ByteBuffer* recvBuff = new ByteBuffer(2048);

	while (This->m_iState != SocketClient_DESTROY) {
		if (This->m_iState != SocketClient_OK) {
			usleep(1000);
			continue;
		}

		FD_ZERO(&fdRead);

		FD_SET(This->m_hSocket, &fdRead);

		aTime.tv_sec = 1;
		aTime.tv_usec = 0;
		
		int ret = select(This->m_hSocket + 1, &fdRead, NULL, NULL, &aTime);
		if (ret == -1) {
			if (errno == EINTR) {
				log("＝＝＝＝＝＝＝＝ Received interrupt signal，Don't process anything ＝＝＝＝＝＝＝＝");
			} else {
				This->m_iState = SocketClient_DESTROY;

				log("连接异常中断 : %X", TYPE_SELF_DEINE_MESSAGE_CONNECT_TERMINATE);

				return ((void *)0);
			}
		}
		else if (ret == 0) {
			gettimeofday(&now, NULL);
			if (g_bcheckReceivedMessage) {
            	if (now.tv_sec - lastReceiveDataTime.tv_sec > maxIdleTimeInSeconds && now.tv_sec - lastHintUserTime.tv_sec > hintTimeInSeconds) {
                    lastHintUserTime = now;
                    
                    log("您的网络已经出问题了！: %X", TYPE_SELF_DEINE_MESSAGE_RECONNECT_FORCE);
            	} else if (now.tv_sec - lastReceiveDataTime.tv_sec > hint2TimeInSeconds && now.tv_sec - lastHintUserTime.tv_sec > hintTimeInSeconds) {
                    lastHintUserTime = now;

                    log("您的网络已经出问题了！: %X", TYPE_SELF_DEINE_MESSAGE_RECONNECT_HINT);
                }else if (now.tv_sec - lastReceiveDataTime.tv_sec > hintTimeInSeconds && now.tv_sec - lastHintUserTime.tv_sec > hintTimeInSeconds) {
                    lastHintUserTime = now;

                    log("您的网络已经出问题了！: %X", TYPE_SELF_DEINE_MESSAGE_IDLE_TIMEOUT);
                }
            } else {
                lastHintUserTime = now;
                lastReceiveDataTime = now;
            }
		}
		else if (ret > 0) {
			if (FD_ISSET(This->m_hSocket, &fdRead)) {
				int iRetCode = 0;

				if (recvBuff->remaining() > 0) {
					iRetCode = recv(
								This->m_hSocket,
								recvBuff->getBuffer() + recvBuff->getPosition(),
								recvBuff->remaining(),
								0);
				}
                
                log("received data length  %d(remain %d)", iRetCode, recvBuff->remaining());
				if (iRetCode == -1) {
					This->m_iState = SocketClient_DESTROY;

					log("The connection is terminated! : %X", TYPE_SELF_DEINE_MESSAGE_CONNECT_TERMINATE);

					auto message = Message::create();
					message->retain();

					GameData::getInstance()->dic->setObject(message, CONNECTION_CLOSED);

					return ((void *)0);
				} else if (iRetCode == 0 && recvBuff->remaining() > 0) {
					This->m_iState = SocketClient_DESTROY;

					log("The server close connection! : %X", TYPE_SELF_DEINE_MESSAGE_SERVER_CLOSE_CONNECTION);

					auto message = Message::create();
					message->retain();

					GameData::getInstance()->dic->setObject(message, CONNECTION_CLOSED);

					return ((void *)0);
				}
				else {
					gettimeofday(&lastReceiveDataTime, NULL);
					
					recvBuff->setPosition(recvBuff->getPosition() + iRetCode);
					recvBuff->flip();

					log("message length : %d", recvBuff->remaining());

					int tmpOffset = 16;
					while (recvBuff->remaining() >= tmpOffset) {
						int pos = recvBuff->position;
						int length = recvBuff->getLength(12);

						log("data length : %d", length);
						
						if (recvBuff->remaining() + tmpOffset >= length) {
							auto message = Message::create();
							message->retain();

							message->HEAD0 = recvBuff->getByte();
							message->HEAD1 = recvBuff->getByte();
							message->HEAD2 = recvBuff->getByte();
							message->HEAD3 = recvBuff->getByte();

							recvBuff->getAsBytes(message->serverVersion);
							recvBuff->getAsBytes(message->commandId);
							recvBuff->getAsBytes(message->length);

							int commandId = bytesToInt(message->commandId);

							recvBuff->get(message->data, 0, length - 4);

							log("commandId : %d, data length : %d \n", commandId, length);
							log("%s", message->data);

							{
								MyLock lock(&This->m_sendqueue_mutex);
								This->m_receivedMessageQueue.push(message);

								GameData::getInstance()->dic->setObject(message, commandId);
							}
						} else if (length > recvBuff->getCapacity()) {
							This->m_iState = SocketClient_DESTROY;

							log("数据包太大！: message size(%d) great capacity(%d), 连接中断 : %X", length, recvBuff->getCapacity(), TYPE_SELF_DEINE_MESSAGE_CONNECT_TERMINATE);

							return ((void *)0);
						} else {
							recvBuff->position = pos;
							break;
						}
					}

					recvBuff->compact();
				}
			} // end read
		}
	}

	log("SocketClient::ThreadReceiveMessage(), receive thread stop!\n");

	return (void*)0;
}


