#ifndef _LobbyTableViewController_H
#define _LobbyTableViewController_H

#include "Global.h"
#include "cocos2d.h"
#include "cocos-ext.h"

USING_NS_CC;
USING_NS_CC_EXT;

class LobbyTableViewCell : public TableViewCell
{
public:
	LobbyTableViewCell();
	~LobbyTableViewCell();
	CCLabelTTF*		m_pTableNameLbl;
	CCLabelTTF*		m_pTableStakeLbl;
	CCLabelTTF*		m_pTableStateLbl;
	void setCellInfo(char *szTableName, TCASH fStake, float fState);
	void clearCellInfo();
};


class LobbyTableViewController : public cocos2d::Layer, public TableViewDataSource, public TableViewDelegate
{
public:
	LobbyTableViewController();
	~LobbyTableViewController();

	static cocos2d::Scene* createScene();
	TableView* tableView;
	// Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
	virtual bool init();
	CREATE_FUNC(LobbyTableViewController);
	
	void setTableWidthHeight(float width, float height);
	void reloadData();
	virtual void scrollViewDidScroll(ScrollView* view) {};
	virtual void scrollViewDidZoom(ScrollView* view) {};
	virtual void tableCellTouched(TableView* table, TableViewCell* cell);
	virtual Size tableCellSizeForIndex(TableView* table, ssize_t idx);
	virtual TableViewCell* tableCellAtIndex(TableView *table, ssize_t idx);
	virtual ssize_t numberOfCellsInTableView(TableView *table);
};

#endif


