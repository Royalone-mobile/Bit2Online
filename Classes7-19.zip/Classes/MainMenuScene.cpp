#include "MainMenuScene.h"
#include "WelcomeScene.h"
#include "SimpleAudioEngine.h"
#include "AppDelegate.h"

USING_NS_CC_EXT;
using namespace network;

// button rect
static const CCRect rtLoginBtn = CCRectMake(355, 228, 111, 51);
static const CCRect rtSignUpBtn = CCRectMake(150, 296, 305, 11);
static const CCRect rtFaceBookBtn = CCRectMake(8, 9, 160, 22);
static const CCRect rtPlayAnonymBtn = CCRectMake(130, 220, 220, 50);
static const CCPoint ptForgetBtn = CCPointMake(286, 70);
static const CCPoint ptRememberBtn = CCPointMake(164, 70);
static const CCPoint ptPlayAnonymBtn = CCPointMake(240, 160);

// textfield rect
static const CCRect rtUserIDCtrl = CCRectMake(193, 172, 142, 26);
static const CCRect rtUserPwdCtrl = CCRectMake(193, 210, 142, 26);

// image name
static CCString * strBackground = new CCString("logo_back.png");

// button name
static CCString * strLoginBtn1 = new CCString("btn_login_0_e.png");
static CCString * strLoginBtn2 = new CCString("btn_login_1_e.png");
static CCString * strForgetBtn1 = new CCString("btn_forgotpwd_0_e.png");
static CCString * strForgetBtn2 = new CCString("btn_forgotpwd_1_e.png");
static CCString * strSignUpBtn1 = new CCString("btn_signup_0_e.png");
static CCString * strSignUpBtn2 = new CCString("btn_signup_1_e.png");
static CCString * strRememberBtn1 = new CCString("btn_remember_0_e.png");
static CCString * strRememberBtn2 = new CCString("btn_remember_1_e.png");
static CCString * strFaceBookBtn1 = new CCString("btn_facebook_0_e.png");
static CCString * strFaceBookBtn2 = new CCString("btn_facebook_1_e.png");
static CCString * strPlayAnonymBtn1 = new CCString("btn_playanonym.png");

//Sound name

//iPad Pos
static const CCPoint ptPadRememberMeBtn = CCPointMake(465, 178);
static const CCPoint ptPadForgetBtn = CCPointMake(600, 175);
static const CCPoint ptPadPlayAnonymBtn = CCPointMake(100, 200);
static const CCRect rtPadUserIDCtrl = CCRectMake(396, 495, 247, 30);
static const CCRect rtPadUserPwdCtrl = CCRectMake(396, 540, 247, 30);

static char szUserEmail[MAX_EMAILADDR_LEN];
static char szUserPwd[MAX_USERPWD_LEN];

Scene* MainMenuScene::createScene()
{
	// 'scene' is an autorelease object
	Scene* scene = NULL;
	do {

	scene = Scene::create();

	// 'layer' is an autorelease object
	auto layer = MainMenuScene::create();

	scene->addChild(layer);
	} while (0);
	return scene;
}

// on "init" you need to initialize your instance
bool MainMenuScene::init()
{
    //////////////////////////////
	do {
		// 1. super init first
		if (!Layer::init())
		{
			return false;
		}
		m_bRememberMe = CGameSetting::getInstance()->IsRemember();
		drawImages();
		drawButtons();
		initTextFields();

		setRememberImage();
	
	} while (0);
    return true;
}


void MainMenuScene::drawImages()
{
	CCSize size = Director::getInstance()->getVisibleSize();
    CCPoint origin = Director::getInstance()->getVisibleOrigin();
    
    float g_scaleFactor = CGameSetting::getInstance()->g_scaleFactor;
    
    pSpriteBack= Sprite::create("image/iPhone/common/logo_back.png");

	pSpriteBack->setPosition(Vec2(size.width * 0.5f + origin.x, size.height * 0.5f+origin.y));
    pSpriteBack->setScale(g_scaleFactor);

    auto glView = Director::getInstance()->getOpenGLView();
    CCString *str = CCString::createWithFormat("glview.framewidth = %f, glview.frameheight =%f, glview.visiblewidth=%f,glview.visibleheight = %f",glView->getFrameSize().width,glView->getFrameSize().height,glView->getVisibleSize().width,glView->getVisibleSize().height);
    
    //MessageBox(str->getCString(), "Visible Size");
    
	this->addChild(pSpriteBack,0);
}

void MainMenuScene::drawButtons()
{
	Vector<MenuItem*> items;
	//CCSize size = Director::getInstance()->getWinSize();
    Size size = pSpriteBack->getContentSize();
    
	m_pLoginBtn = MenuItemImage::create("image/iPhone/eng/"+ strLoginBtn1->_string, "image/iPhone/eng/" + strLoginBtn2->_string);
	m_pLoginBtn->setCallback(std::bind(menu_selector(MainMenuScene::menuCallbackHandler), this, std::placeholders::_1));
	m_pLoginBtn->setPosition(getPointFrom3GRect(rtLoginBtn, size.height));
	m_pLoginBtn->setTag(kMenuLogin);

	auto signupItem = MenuItemImage::create("image/iPhone/eng/" + strSignUpBtn1->_string, "image/iPhone/eng/" + strSignUpBtn2->_string);
	signupItem->setCallback(std::bind(menu_selector(MainMenuScene::menuCallbackHandler), this, std::placeholders::_1));
	signupItem->setPosition(getPointFrom3GRect(rtSignUpBtn, size.height));
	signupItem->setTag(kMenuSignUp);


	auto rememberNml = MenuItemImage::create("image/iPhone/eng/" + strRememberBtn1->_string, "image/iPhone/eng/" + strRememberBtn1->_string);
	auto rememberAct = MenuItemImage::create("image/iPhone/eng/" + strRememberBtn2->_string, "image/iPhone/eng/" + strRememberBtn2->_string);

	Vector<MenuItem*> toggleItems;
	toggleItems.pushBack(rememberNml);
	toggleItems.pushBack(rememberAct);
	m_pRememberBtn = MenuItemToggle::createWithCallback(std::bind(menu_selector(MainMenuScene::menuCallbackHandler), this, std::placeholders::_1), toggleItems);
	m_pRememberBtn->setCallback(std::bind(menu_selector(MainMenuScene::menuCallbackHandler), this, std::placeholders::_1));
	m_pRememberBtn->setPosition(ptRememberBtn);
	m_pRememberBtn->setTag(kMenuRemember);


    auto forgotItem = MenuItemImage::create("image/iPhone/eng/" + strForgetBtn1->_string, "image/iPhone/eng/" + strForgetBtn2->_string);
    forgotItem->setCallback(std::bind(menu_selector(MainMenuScene::menuCallbackHandler), this, std::placeholders::_1));
    forgotItem->setPosition(ptForgetBtn);
    forgotItem->setTag(kMenuForgot);
 
    items.pushBack(m_pLoginBtn);
    items.pushBack(signupItem);
    items.pushBack(m_pRememberBtn);
    //items.pushBack(forgotItem);
    
	auto pMenu = Menu::createWithArray(items);
	pMenu->setPosition(Vec2::ZERO);
	pSpriteBack->addChild(pMenu);
}

void MainMenuScene::initTextFields()
{
    useremail = EditBox::create(CCSize(rtUserIDCtrl.size.width,rtUserIDCtrl.size.height), Scale9Sprite::create());
    useremail->setPosition(getPointFrom3GRect(rtUserIDCtrl));
    //useremail->setReturnType(ui::EditBox::KeyboardReturnType::DONE);
	

    useremail->setMaxLength(50);
    useremail->setFontSize(15);
    useremail->setInputMode(ui::EditBox::InputMode::EMAIL_ADDRESS);
	useremail->setInputFlag(cocos2d::ui::EditBox::InputFlag::SENSITIVE);
    useremail->setPlaceHolder("<enter email>");
    useremail->setDelegate(this);//Open client
    useremail->setFontColor(Color3B::BLACK);//Sets the text color
    pSpriteBack->addChild(useremail);
	useremail->setReturnType(ui::EditBox::KeyboardReturnType::DONE);

	//#if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
//		useremail->setReturnType(ui::EditBox::KeyboardReturnType::DONE);
//	#else
		//useremail->setReturnType(ui::EditBox::KeyboardReturnType::SEND);
	//#endif

    password = EditBox::create(CCSize(rtUserPwdCtrl.size.width, rtUserPwdCtrl.size.height), Scale9Sprite::create());
    password->setPosition(getPointFrom3GRect(rtUserPwdCtrl));
    password->setInputMode(ui::EditBox::InputMode::SINGLE_LINE);
	password->setReturnType(ui::EditBox::KeyboardReturnType::DONE);
	password->setInputFlag(ui::EditBox::InputFlag::PASSWORD);
    password->setMaxLength(50);
    password->setFontSize(12);
    password->setPlaceHolder("<enter password>");
    password->setDelegate(this);//Open client
    password->setFontColor(Color3B::BLACK);//Sets the text color
    pSpriteBack->addChild(password);


	if (m_bRememberMe) {
		CGameSetting::getInstance()->getUserEmail(szUserEmail);
		CGameSetting::getInstance()->getPassword(szUserPwd);
		useremail->setText(szUserEmail);
		password->setText(szUserPwd);
	}
}


void MainMenuScene::menuCallbackHandler(Ref * pSender)
{
	CallFunc * callFunc = NULL;
	int tag = ((MenuItem*)pSender)->getTag();
	switch (tag) 
	{
	case kMenuPlay:	
		App->changeSceneWithState(TGAME_WELCOME);
		break;
	case kMenuSignUp:
		App->changeSceneWithState(TGAME_ACCOUNT);
		break;
	case kMenuRemember:
		m_bRememberMe = !m_bRememberMe;
		setRememberImage();
		break;
	case kMenuLogin:
		logInUser();
		break;
	}
}

void MainMenuScene::logInUser()
{
	std::vector<std::string> headers;

	const char *strEmail = useremail->getText();
	const char *strPassword = password->getText();

	if (!strEmail || strlen(strEmail) == 0) {
		MessageBox("Please enter email address", "Notice");
		return;
	}

	if (!strPassword || strlen(strPassword) == 0) {
		MessageBox("Please enter a password.", "Notice");
		return;
	}


	//Creating a URL
	HttpRequest *request = new HttpRequest();

	request->setRequestType(HttpRequest::Type::GET);

	CCString *str = CCString::createWithFormat("%s/%s/%s",LOGIN_URL, strEmail, strPassword);
	const char* URL = str->getCString();

	request->setUrl(URL);

	headers.push_back("Content-Type: application/json; charset=utf-8");

	request->setHeaders(headers);
	
		
	request->setResponseCallback(this, httpresponse_selector(MainMenuScene::onHttpRequestCompleted));
	HttpClient::getInstance()->send(request);
	request->release();

	m_pLoginBtn->setEnabled(false);
	
}

void MainMenuScene::onHttpRequestCompleted(cocos2d::network::HttpClient *sender, cocos2d::network::HttpResponse *response)
{
	m_pLoginBtn->setEnabled(true);

	if (!response) {
		return;
	}

	int statusCode = response->getResponseCode();
	char statusString[64] = {};
	sprintf(statusString, "HTTP Status Code: %d, tag = %s", statusCode, response->getHttpRequest()->getTag());



	switch (statusCode) {
	case 409:
		MessageBox("Email already exists. Please try again", "Notice");
		break;
	case 422:
		MessageBox("Input Valid Email Address", "Notice");
		break;

	}
	// A connection failure
	if (!response->isSucceed())
	{
		MessageBox("Invalid login credentials. Please try again.", "Notice");
		return;
	}
	std::vector<char> * buffer = response->getResponseData();
	char * strResponse = (char *)malloc(buffer->size() + 1);
	std::string s2(buffer->begin(), buffer->end());
	strcpy(strResponse, s2.c_str());


	Json::Reader reader;
	Json::Value root;
	//root["command"] = "PUT_STONE";
	char *szUserName;
	CCString *strUserName;

	CCString *strUserID;
	bool res = reader.parse(strResponse, root, false);
	double cash = 0.0f;
	if (res) {
		Json::Value data = root["name"];
		szUserName = (char*)data.asCString();
		MessageBox(szUserName, "");
		strUserName = new CCString(szUserName);
		data = root["point"];
		cash = data.asDouble();

		data = root["_id"];
		char *szUserID = (char*)data.asCString();
		strUserID = new CCString(szUserID);
	}
	else
	{
		MessageBox("Invalid login credentials. Please try again.", "Notice");
		return;
	}

	CGameSetting::getInstance()->setRemember(m_bRememberMe);
	CGameSetting::getInstance()->setUserID((char*)strUserID->getCString());
	CGameSetting::getInstance()->setUserName((char*)strUserName->getCString());
	CGameSetting::getInstance()->setUserEmail((char*)useremail->getText());
	CGameSetting::getInstance()->setPassword((char*)password->getText());
	CGameSetting::getInstance()->setSafeLogout(false);
	CGameSetting::getInstance()->setCash(cash);
	CGameSetting::getInstance()->saveGameSetting();

	App->changeSceneWithState(TGAME_WELCOME);
	MessageBox("LogIn Successful", "Notice");
}



void MainMenuScene::setRememberImage()
{
	if (m_bRememberMe) {
		m_pRememberBtn->setSelectedIndex(1);
	}
	else {
		m_pRememberBtn->setSelectedIndex(0);
	}
}
void MainMenuScene::menuCloseCallback(Ref* pSender)
{
    //Close the cocos2d-x game scene and quit the application
    Director::getInstance()->end();
    #if (CC_TARGET_PLATFORM == CC_PLATFORM_IOS)
    exit(0);
#endif
    
}

void MainMenuScene::editBoxEditingDidBegin(cocos2d::ui::EditBox* editBox)
{
}

void MainMenuScene::editBoxEditingDidEnd(cocos2d::ui::EditBox* editBox)
{
    
}

void MainMenuScene::editBoxTextChanged(cocos2d::ui::EditBox* editBox, const std::string& text)
{
    
}

void MainMenuScene::editBoxReturn(ui::EditBox* editBox)
{
    
}


