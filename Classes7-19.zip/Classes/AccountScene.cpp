#include "AccountScene.h"
#include "SimpleAudioEngine.h"
#include "Global.h"
#include "ViewSetting.h"

USING_NS_CC_EXT;
using namespace CocosDenshion;
using namespace network;
// image rect
static const CCRect rtCharacterBackImg = CCRectMake(82, 195, 47, 47);
static const CCRect rtCharacterImg = CCRectMake(83, 196, 45, 45);
static const CCRect rtPlusImg = CCRectMake(29, 132, 12, 12);

// button rect
static const CCRect rtNextChaImgBtn = CCRectMake(138, 210, 20, 20);
static const CCRect rtPrevChaImgBtn = CCRectMake(51, 210, 20, 20);
static const CCRect rtCreateBtn = CCRectMake(123, 272, 100, 27);
static const CCRect rtCancelBtn = CCRectMake(258, 272, 100, 27);

// label rect
static const CCRect rtUserNameLabel = CCRectMake(220, 163, 80, 16);
static const CCRect rtUserPwdLabel = CCRectMake(220, 190, 80, 16);
static const CCRect rtCfmPwdLabel = CCRectMake(220, 216, 100, 16);
static const CCRect rtEmailLabel = CCRectMake(220, 242, 80, 16);
static const CCRect rtTitleLabel = CCRectMake(45, 128, 180, 30);
static const CCRect rtCurBalanceLabel = CCRectMake(30, 158, 200, 24);
static const CCRect rtChaImgIndexLabel = CCRectMake(75, 243, 55, 22);
static const CCRect rtAdapterLabel = CCRectMake(80, 176, 80, 22);
static const CCRect rtDuplicateLabel = CCRectMake(295, 178, 185, 14);

// textfield rect
static const CCRect rtUserNameCtrl = CCRectMake(309, 159, 133, 24);
static const CCRect rtUserPwdCtrl = CCRectMake(309, 185, 133, 24);
static const CCRect rtCfmPwdCtrl = CCRectMake(309, 211, 133, 24);
static const CCRect rtEmailAddrCtrl = CCRectMake(309, 237, 133, 24);

// image name
static CCString* strBackground = new CCString("signup_back.png");
static CCString* strCharacterBack = new CCString("pan_myavatar.png");
static CCString* strPlus = new CCString("plus.png");

// button name
static CCString* strNextChaImgBtn1 = new CCString("arrow_right_0.png");
static CCString* strNextChaImgBtn2 = new CCString("arrow_right_1.png");
static CCString* strPrevChaImgBtn1 = new CCString("arrow_left_0.png");
static CCString* strPrevChaImgBtn2 = new CCString("arrow_left_1.png");
static CCString* strCreateBtn1 = new CCString("btn_create_0_e.png");
static CCString* strCreateBtn2 = new CCString("btn_create_1_e.png");
static CCString* strCancelBtn1 = new CCString("btn_cancel_00_e.png");
static CCString* strCancelBtn2 = new CCString("btn_cancel_01_e.png");

// label name
static CCString* strUserName_e = new CCString("My name");
static CCString* strUserPwd_e = new CCString("Password");
static CCString* strCfmPwd_e = new CCString("Confirm password");
static CCString* strEmail_e = new CCString("Email address");
static CCString* strTitle_e = new CCString("CREATE ACCOUNT");
static CCString* strChaImgIndex_e = new CCString("%d / %d");
static CCString* strAdapter_e = new CCString("My avatar");
static CCString* strCurBalance_e = new CCString("Your start balance : $%d");




Scene* AccountScene::createScene()
{
	// 'scene' is an autorelease object
	Scene* scene = NULL;
	do {

	scene = Scene::create();

	// 'layer' is an autorelease object
	auto layer = AccountScene::create();

	scene->addChild(layer);
	} while (0);
	return scene;
}

// on "init" you need to initialize your instance
bool AccountScene::init()
{
    //////////////////////////////
	do {
		if (!Layer::init())
		{
			return false;
		}
		//Character Image Number
		m_nChaImgNumber = 0;
		drawImages();
		drawButtons();
		drawLabels();
        initTextFields();
	} while (0);
    return true;
}

void AccountScene::drawImages()
{
	Size size = Director::getInstance()->getWinSize();
	
	pSpriteBack = Sprite::create("image/iPhone/common/"+ strBackground->_string);
	pSpriteBack->setPosition(Vec2(size.width * 0.5f, size.height * 0.5f ));
    pSpriteBack->setScale(CGameSetting::getInstance()->g_scaleFactor);
	this->addChild(pSpriteBack);

	Sprite * characterback = Sprite::create("image/iPhone/common/" + strCharacterBack->_string);
	characterback->setPosition(getPointFrom3GRect(rtCharacterBackImg, size.height));
	pSpriteBack->addChild(characterback);
    
    size = pSpriteBack->getContentSize();
	for (int i = 0; i < MAX_CHA_IMAGE_COUNT; i++) {
		CCString *chImgFileName = new CCString();
		chImgFileName->initWithFormat("cha_%d.png", i);
		m_pCharactImage[i] = CCSprite::create("image/iPhone/common/character/" + chImgFileName->_string);
		m_pCharactImage[i]->setPosition(getPointFrom3GRect(rtCharacterImg, size.height));
		m_pCharactImage[i]->setVisible(false);
		pSpriteBack->addChild(m_pCharactImage[i]);
	}

	m_pCharactImage[m_nChaImgNumber]->setVisible(true);

	Sprite * plus = Sprite::create("image/iPhone/common/" + strPlus->_string);
	plus->setPosition(getPointFrom3GRect(rtPlusImg, size.height));
	pSpriteBack->addChild(plus);
}



void AccountScene::drawButtons() 
{
    Size size = pSpriteBack->getContentSize();
    
	MenuItemImage* m_pNextChaImgBtn = MenuItemImage::create("image/iPhone/eng/" + strNextChaImgBtn1->_string, "image/iPhone/eng/"+ strNextChaImgBtn2->_string);
	//m_pNextChaImgBtn->setCallback(std::bind(CC_MENU_SELECTOR(AccountScene::menuCallbackHandler), this, std::placeholders::_1));
	m_pNextChaImgBtn->setCallback(std::bind(menu_selector(AccountScene::menuCallbackHandler), this, std::placeholders::_1));
	m_pNextChaImgBtn->setPosition(getPointFrom3GRect(rtNextChaImgBtn, size.height));
	m_pNextChaImgBtn->setScale(1.5f);
	m_pNextChaImgBtn->setTag(kMenuNext);


	MenuItemImage* m_pPrevChaImgBtn = MenuItemImage::create("image/iPhone/eng/" + strPrevChaImgBtn1->_string, "image/iPhone/eng/" + strPrevChaImgBtn2->_string);
	m_pNextChaImgBtn->setCallback(std::bind(menu_selector(AccountScene::menuCallbackHandler), this, std::placeholders::_1));
	m_pNextChaImgBtn->setPosition(getPointFrom3GRect(rtPrevChaImgBtn, size.height));
	m_pNextChaImgBtn->setScale(1.5f);
	m_pNextChaImgBtn->setTag(kMenuPrev);

	MenuItemImage* m_pCreateBtn = MenuItemImage::create("image/iPhone/eng/" + strCreateBtn1->_string, "image/iPhone/eng/" + strCreateBtn2->_string);
	m_pCreateBtn->setCallback(std::bind(menu_selector(AccountScene::menuCallbackHandler), this, std::placeholders::_1));
	m_pCreateBtn->setPosition(Vec2(getPointFrom3GRect(rtCreateBtn, size.height)));
	m_pCreateBtn->setTag(kMenuCreate);

	MenuItemImage* m_pCancelBtn = MenuItemImage::create("image/iPhone/eng/" + strCancelBtn1->_string, "image/iPhone/eng/" + strCancelBtn2->_string);
	m_pCancelBtn->setCallback(std::bind(menu_selector(AccountScene::menuCallbackHandler), this, std::placeholders::_1));
	m_pCancelBtn->setPosition(Vec2(getPointFrom3GRect(rtCancelBtn, size.height)));
	m_pCancelBtn->setTag(kMenuCancel);

	Vector<MenuItem*> items;
	items.pushBack(m_pNextChaImgBtn);
	items.pushBack(m_pPrevChaImgBtn);
	items.pushBack(m_pCreateBtn);
	items.pushBack(m_pCancelBtn);
	auto pMenu = Menu::createWithArray(items);
	pMenu->setPosition(Vec2::ZERO);
	pSpriteBack->addChild(pMenu);
}

void AccountScene::drawLabels()
{
	//Size size = Director::getInstance()->getWinSize();
    Size size = pSpriteBack->getContentSize();
    
	// User Name Label
	m_pUserNameLabel = CCLabelTTF::create("", g_FontName->_string, 12, getRectFrom3GRect(rtUserNameLabel).size);
	m_pUserNameLabel->setPosition(Vec2(getPointFrom3GRect(rtUserNameLabel, size.height)));
	m_pUserNameLabel->setColor(Color3B::BLACK);
	pSpriteBack->addChild(m_pUserNameLabel);

	m_pCurBalanceLabel = CCLabelTTF::create("", g_FontName->_string, 16, getRectFrom3GRect(rtCurBalanceLabel).size);
	m_pCurBalanceLabel->setPosition(Vec2(getPointFrom3GRect(rtCurBalanceLabel, size.height)));
	m_pCurBalanceLabel->setColor(Color3B::BLACK);
	pSpriteBack->addChild(m_pCurBalanceLabel);


	CCLabelTTF * m_pCfmPwdLabel = CCLabelTTF::create("", g_FontName->_string, 12, getRectFrom3GRect(rtCfmPwdLabel).size);
	m_pCfmPwdLabel->setPosition(Vec2(getPointFrom3GRect(rtCfmPwdLabel, size.height)));
	m_pCfmPwdLabel->setColor(Color3B::BLACK);
	pSpriteBack->addChild(m_pCfmPwdLabel);

	CCLabelTTF *m_pTitleLabel = CCLabelTTF::create("", g_FontName->_string, 18, getRectFrom3GRect(rtTitleLabel).size);
	m_pTitleLabel->setPosition(Vec2(getPointFrom3GRect(rtTitleLabel, size.height)));
	m_pTitleLabel->setColor(Color3B::BLACK);
	pSpriteBack->addChild(m_pTitleLabel);

	CCLabelTTF *m_pEmailLabel = CCLabelTTF::create("", g_FontName->_string, 12, getRectFrom3GRect(rtEmailLabel).size);
	m_pEmailLabel->setPosition(Vec2(getPointFrom3GRect(rtEmailLabel, size.height)));
	m_pEmailLabel->setColor(Color3B::BLACK);
	pSpriteBack->addChild(m_pEmailLabel);

	CCLabelTTF *m_pUserPwdLabel = CCLabelTTF::create("", g_FontName->_string, 14, getRectFrom3GRect(rtUserPwdLabel).size);
	m_pUserPwdLabel->setPosition(Vec2(getPointFrom3GRect(rtUserPwdLabel, size.height)));
	m_pUserPwdLabel->setColor(Color3B::BLACK);
	pSpriteBack->addChild(m_pUserPwdLabel);

	CCLabelTTF *m_pAdapterLabel = CCLabelTTF::create("", g_FontName->_string, 12, getRectFrom3GRect(rtAdapterLabel).size);
	m_pAdapterLabel->setPosition(Vec2(getPointFrom3GRect(rtAdapterLabel, size.height)));
    m_pAdapterLabel->setColor(Color3B::BLACK);
	pSpriteBack->addChild(m_pAdapterLabel);

	m_pChaImgIndexLabel = CCLabelTTF::create("", g_FontName->_string, 12, getRectFrom3GRect(rtChaImgIndexLabel).size);
	m_pChaImgIndexLabel->setPosition(Vec2(getPointFrom3GRect(rtChaImgIndexLabel, size.height)));
	
	pSpriteBack->addChild(m_pChaImgIndexLabel);

	m_pUserNameLabel->setString(strUserName_e->_string);
	m_pUserPwdLabel->setString(strUserPwd_e->_string);
	m_pCfmPwdLabel->setString(strCfmPwd_e->_string);
	m_pEmailLabel->setString(strEmail_e->_string);
	m_pTitleLabel->setString(strTitle_e->_string);

	CCString *strIndexLabel = new CCString();
	strIndexLabel->initWithFormat(strChaImgIndex_e->getCString(), m_nChaImgNumber + 1, MAX_CHA_IMAGE_COUNT);
	m_pChaImgIndexLabel->setString(strIndexLabel->_string);

	m_pChaImgIndexLabel->setString(strUserName_e->_string);
	m_pAdapterLabel->setString(strAdapter_e->_string);
    m_pChaImgIndexLabel->setColor(Color3B::BLACK);
    
	CCString* strBalance = new CCString();
	strBalance->initWithFormat(strCurBalance_e->getCString(), 10000);
	m_pCurBalanceLabel->setString(strBalance->_string);

}

void AccountScene::registerUser() 
{
	std::vector<std::string> headers;

	const char *strUserName = username->getText();
	const char *strEmail = useremail->getText();
	const char *strPassword = password->getText();
	const char *strConfirmPassword = confirmPassword->getText();

	if (!strUserName || strlen(strUserName) == 0) {
		MessageBox("Please enter username", "Notice");
		return;
	}
	if (!strEmail || strlen(strEmail) == 0) {
		MessageBox("Please enter email address", "Notice");
		return;
	}

	if (!strPassword || strlen(strPassword) == 0) {
		MessageBox("Please enter a password.", "Notice");
		return;
	}
	if (!strConfirmPassword || strlen(strConfirmPassword) == 0) {
		MessageBox("Please confirm your password.", "Notice");
		return;
	}
	if (strcmp(strPassword, strConfirmPassword) != 0)
	{
		MessageBox("Password doesn't match.", "Notice");
		return;
	}

	headers.push_back("Content-Type: application/json; charset=utf-8");
	//Creating a URL
	HttpRequest *request = new HttpRequest();
	request->setUrl(REGISTER_URL);
	request->setRequestType(HttpRequest::Type::POST);
	//request->setHeaders(headers);

	CCString *str = CCString::createWithFormat("name=%s&email=%s&password=%s&role=user", strUserName, strEmail, strPassword);
	const char* postData = str->getCString();
	//const char* postData = "email=GREATROYALONE@OUTLOOK.COM&name=Extensions&password=213123&role=user";
	request->setRequestData(postData, strlen(postData));
	request->setResponseCallback(this, httpresponse_selector(AccountScene::onHttpRequestCompleted));
	HttpClient::getInstance()->send(request);
	request->release();
}

void AccountScene::onHttpRequestCompleted(cocos2d::network::HttpClient *sender, cocos2d::network::HttpResponse *response) {
    if (!response) {
        return;
    }
    int statusCode = response->getResponseCode();
    char statusString[64] = {};
    sprintf(statusString, "HTTP Status Code: %d, tag = %s", statusCode,
            response->getHttpRequest()->getTag());

    switch (statusCode) {
        case 409:
            MessageBox("Email already exists. Please try again", "Notice");
            break;
        case 422:
            MessageBox("Input Valid Email Address", "Notice");
            break;

    }
    // A connection failure
    if (!response->isSucceed())
    {
		MessageBox("Failed in creating account", "Notice");
		return;
	}

	MessageBox("Succeed in creating account", "Notice");
	App->changeSceneWithState(TGAME_LOGIN);
}


void AccountScene::menuCallbackHandler(Ref * pSender)
{
	CallFunc * callFunc = NULL;
	int tag = ((MenuItem*)pSender)->getTag();
	int nTemp;
	CCString * chaImg = new CCString();
 
	switch (tag)
	{
        case kMenuCreate:
			registerUser();
            break;
        case kMenuCancel:
			App->changeSceneWithState(TGAME_LOGIN);
            break;
		case kMenuNext:
			nTemp = m_nChaImgNumber;
			if (m_nChaImgNumber == MAX_CHA_IMAGE_COUNT - 1)
				m_nChaImgNumber = 0;
			else
				m_nChaImgNumber++;
			
			chaImg->initWithFormat("%d / %d", m_nChaImgNumber + 1, MAX_CHA_IMAGE_COUNT );
			m_pChaImgIndexLabel->setString(chaImg->_string);
			m_pChaImgIndexLabel->setVisible(false);
			m_pCharactImage[m_nChaImgNumber]->setVisible(true);
			break;
		case kMenuPrev:
			nTemp = m_nChaImgNumber;
			if (m_nChaImgNumber == MAX_CHA_IMAGE_COUNT - 1)
				m_nChaImgNumber = 0;
			else
				m_nChaImgNumber--;
			
			chaImg->initWithFormat("%d / %d", m_nChaImgNumber + 1, MAX_CHA_IMAGE_COUNT);
			m_pChaImgIndexLabel->setString(chaImg->_string);
			m_pChaImgIndexLabel->setVisible(false);
			m_pCharactImage[m_nChaImgNumber]->setVisible(true);
            break;
	}

}



void AccountScene::editBoxEditingDidBegin(cocos2d::ui::EditBox* editBox)
{
}

void AccountScene::editBoxEditingDidEnd(cocos2d::ui::EditBox* editBox)
{
    
}

void AccountScene::editBoxTextChanged(cocos2d::ui::EditBox* editBox, const std::string& text)
{
    
}

void AccountScene::editBoxReturn(ui::EditBox* editBox)
{
    
}

void AccountScene::initTextFields()
{

    username = EditBox::create(CCSize(rtUserNameCtrl.size.width,rtUserNameCtrl.size.height), Scale9Sprite::create());
    username->setPosition(getPointFrom3GRect(rtUserNameCtrl));
    
    username->setMaxLength(40);
    username->setFontSize(16);
    username->setColor(Color3B::WHITE);
    username->setInputMode(ui::EditBox::InputMode::ANY);
    username->setPlaceHolder("");
    username->setDelegate(this);//Open client
    username->setFontColor(Color3B::BLACK);//Sets the text color
	username->setReturnType(ui::EditBox::KeyboardReturnType::DONE);
    pSpriteBack->addChild(username);

    
    useremail = EditBox::create(CCSize(rtEmailAddrCtrl.size.width,rtEmailAddrCtrl.size.height), Scale9Sprite::create());
    useremail->setPosition(getPointFrom3GRect(rtEmailAddrCtrl));
   
    useremail->setMaxLength(100);
    useremail->setFontSize(15);
    useremail->setInputMode(ui::EditBox::InputMode::EMAIL_ADDRESS);
    useremail->setPlaceHolder("");
    username->setColor(Color3B::WHITE);
    useremail->setDelegate(this);//Open client
    useremail->setFontColor(Color3B::BLACK);//Sets the text color
	useremail->setReturnType(ui::EditBox::KeyboardReturnType::DONE);
	//useremail->setInputFlag(cocos2d::ui::EditBox::InputFlag::SENSITIVE);

    pSpriteBack->addChild(useremail);
    
    password = EditBox::create(CCSize(rtUserPwdCtrl.size.width, rtUserPwdCtrl.size.height), Scale9Sprite::create());
    password->setPosition(getPointFrom3GRect(rtUserPwdCtrl));
    password->setInputMode(ui::EditBox::InputMode::SINGLE_LINE);

    password->setMaxLength(20);
    password->setFontSize(12);
    password->setColor(Color3B::WHITE);
    password->setPlaceHolder("");
    password->setDelegate(this);//Open client
    password->setFontColor(Color3B::BLACK);//Sets the text color
	password->setReturnType(ui::EditBox::KeyboardReturnType::DONE);
	password->setInputFlag(ui::EditBox::InputFlag::PASSWORD);
    pSpriteBack->addChild(password);
    
    confirmPassword = EditBox::create(CCSize(rtCfmPwdCtrl.size.width, rtCfmPwdCtrl.size.height), Scale9Sprite::create());
    confirmPassword->setPosition(getPointFrom3GRect(rtCfmPwdCtrl));
    confirmPassword->setInputMode(ui::EditBox::InputMode::SINGLE_LINE);
    confirmPassword->setInputFlag(ui::EditBox::InputFlag::PASSWORD);
	
    confirmPassword->setMaxLength(20);
    confirmPassword->setFontSize(12);
    confirmPassword->setColor(Color3B::WHITE);
    confirmPassword->setPlaceHolder("");
    confirmPassword->setDelegate(this);//Open client
	confirmPassword->setReturnType(ui::EditBox::KeyboardReturnType::DONE);
    confirmPassword->setFontColor(Color3B::BLACK);//Sets the text color
    pSpriteBack->addChild(confirmPassword);
}


