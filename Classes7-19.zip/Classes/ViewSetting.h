#ifndef __VIEWSETTING_H__
#define __VIEWSETTING_H__

#include "cocos2d.h"
#include "Global.h"
#include "AppDelegate.h"

using namespace cocos2d;
class ViewSetting : public cocos2d::Layer

{
public:
    virtual bool init();
	void drawImages();
	void drawButtons();
	void drawLabels();
	void menuCallbackHandler(Ref * pSender);
	static Scene* createScene();

	void onVibration();
	void onBlockChat();
	void onFriendStatus();
	void onSound();

	ViewSetting() {};
	~ViewSetting();
	CREATE_FUNC(ViewSetting);
private:

	MenuItemToggle* soundToggle , *vibrationToggle, *blockChatToggle, *friendStateToggle;
    CCSprite *pSpriteBack;
};

#endif




